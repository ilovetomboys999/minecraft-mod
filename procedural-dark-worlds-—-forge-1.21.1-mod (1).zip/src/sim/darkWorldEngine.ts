export type MaterialId =
  | 'stone'
  | 'dirt'
  | 'grass'
  | 'wood'
  | 'leaves'
  | 'sand'
  | 'glass'
  | 'metal'
  | 'crystal'
  | 'water'
  | 'ice'
  | 'snow'
  | 'nether'
  | 'end'
  | 'organic'
  | 'decorative'
  | 'bricks'
  | 'concrete';

export type WorldSizeId = 'small' | 'medium' | 'large' | 'huge';

export const WORLD_SIZES: Record<WorldSizeId, { label: string; side: number }> = {
  small: { label: 'Small', side: 512 },
  medium: { label: 'Medium', side: 1024 },
  large: { label: 'Large', side: 2048 },
  huge: { label: 'Huge', side: 4096 },
};

export interface BiomeTheme {
  id: string;
  name: string;
  affinities: Partial<Record<MaterialId, number>>;
  hueShift: number;
  baseHeight: number;
  amplitude: number;
  ridgeWeight: number;
  treeDensity: number;
  crystalDensity: number;
  structureDensity: number;
  fluidKind: 'water' | 'lava' | 'ice';
}

export const BIOME_THEMES: BiomeTheme[] = [
  {
    id: 'dark_highlands',
    name: 'Dark Highlands',
    affinities: { stone: 1.0, metal: 0.35, bricks: 0.25 },
    hueShift: -8,
    baseHeight: 76,
    amplitude: 26,
    ridgeWeight: 0.65,
    treeDensity: 0.01,
    crystalDensity: 0.08,
    structureDensity: 0.04,
    fluidKind: 'water',
  },
  {
    id: 'dark_forest',
    name: 'Dark Forest',
    affinities: { wood: 1.0, leaves: 0.9, organic: 0.5 },
    hueShift: 14,
    baseHeight: 68,
    amplitude: 12,
    ridgeWeight: 0.2,
    treeDensity: 0.22,
    crystalDensity: 0.03,
    structureDensity: 0.03,
    fluidKind: 'water',
  },
  {
    id: 'dark_desert',
    name: 'Dark Desert',
    affinities: { sand: 1.0, decorative: 0.25 },
    hueShift: 22,
    baseHeight: 67,
    amplitude: 15,
    ridgeWeight: 0.35,
    treeDensity: 0.005,
    crystalDensity: 0.06,
    structureDensity: 0.05,
    fluidKind: 'water',
  },
  {
    id: 'frozen_darkness',
    name: 'Frozen Darkness',
    affinities: { ice: 1.0, snow: 0.95 },
    hueShift: -18,
    baseHeight: 70,
    amplitude: 18,
    ridgeWeight: 0.45,
    treeDensity: 0.02,
    crystalDensity: 0.14,
    structureDensity: 0.03,
    fluidKind: 'ice',
  },
  {
    id: 'crystal_fields',
    name: 'Crystal Fields',
    affinities: { crystal: 1.0, glass: 0.9, end: 0.45 },
    hueShift: 32,
    baseHeight: 69,
    amplitude: 16,
    ridgeWeight: 0.5,
    treeDensity: 0.02,
    crystalDensity: 0.28,
    structureDensity: 0.04,
    fluidKind: 'water',
  },
  {
    id: 'dark_plains',
    name: 'Dark Plains',
    affinities: { dirt: 0.95, grass: 1.0 },
    hueShift: 6,
    baseHeight: 66,
    amplitude: 7,
    ridgeWeight: 0.1,
    treeDensity: 0.05,
    crystalDensity: 0.03,
    structureDensity: 0.04,
    fluidKind: 'water',
  },
  {
    id: 'abyssal_region',
    name: 'Abyssal Region',
    affinities: { water: 1.0, ice: 0.35 },
    hueShift: -26,
    baseHeight: 57,
    amplitude: 9,
    ridgeWeight: 0.25,
    treeDensity: 0.01,
    crystalDensity: 0.09,
    structureDensity: 0.03,
    fluidKind: 'water',
  },
  {
    id: 'dark_city',
    name: 'Dark City',
    affinities: { bricks: 1.0, concrete: 1.0, metal: 0.85, decorative: 0.4 },
    hueShift: -12,
    baseHeight: 68,
    amplitude: 6,
    ridgeWeight: 0.15,
    treeDensity: 0.01,
    crystalDensity: 0.04,
    structureDensity: 0.22,
    fluidKind: 'water',
  },
  {
    id: 'infernal_wastes',
    name: 'Infernal Wastes',
    affinities: { nether: 1.0, metal: 0.3 },
    hueShift: -35,
    baseHeight: 71,
    amplitude: 20,
    ridgeWeight: 0.55,
    treeDensity: 0.01,
    crystalDensity: 0.11,
    structureDensity: 0.06,
    fluidKind: 'lava',
  },
  {
    id: 'overgrown_depths',
    name: 'Overgrown Depths',
    affinities: { organic: 1.0, leaves: 0.65, grass: 0.55 },
    hueShift: 20,
    baseHeight: 67,
    amplitude: 13,
    ridgeWeight: 0.25,
    treeDensity: 0.18,
    crystalDensity: 0.08,
    structureDensity: 0.04,
    fluidKind: 'water',
  },
];

export interface ChestItemEntry {
  id: string;
  label: string;
  archetype: string;
  roleTitle: string;
  count: number;
  containerPos: string;
  dialogue: string;
}

export interface RoomPreset {
  id: string;
  name: string;
  summary: string;
  breachRoof: boolean;
  doorOpening: boolean;
  composition: Partial<Record<MaterialId, number>>;
  chestItems: ChestItemEntry[];
}

export const ROOM_PRESETS: RoomPreset[] = [
  {
    id: 'stone_armory',
    name: 'Stone Keep & Armory',
    summary: 'Cobblestone bastion with iron grating, oak rafters, and amethyst enchanting corner.',
    breachRoof: false,
    doorOpening: true,
    composition: { stone: 0.46, bricks: 0.24, metal: 0.18, wood: 0.07, crystal: 0.05 },
    chestItems: [
      { id: 'minecraft:iron_sword', label: 'Iron Sword', archetype: 'blade_knight', roleTitle: 'Vanguard', count: 2, containerPos: '12, 65, -8', dialogue: 'My edge remembers the anvil before the Fountain struck.' },
      { id: 'minecraft:shield', label: 'Shield', archetype: 'blade_knight', roleTitle: 'Vanguard', count: 1, containerPos: '12, 65, -8', dialogue: 'Stand behind me when the umbral winds rise.' },
      { id: 'minecraft:cooked_beef', label: 'Steak', archetype: 'feastkeeper', roleTitle: 'Provisioner', count: 14, containerPos: '14, 65, -8', dialogue: 'Warm rations still hold their flavor in the dark.' },
      { id: 'minecraft:amethyst_shard', label: 'Amethyst Shard', archetype: 'lapidary', roleTitle: 'Gemwright', count: 6, containerPos: '10, 66, -11', dialogue: 'Every crystal here hums at the Fountain frequency.' },
      { id: 'minecraft:redstone', label: 'Redstone Dust', archetype: 'tinker_automaton', roleTitle: 'Mechanist', count: 20, containerPos: '15, 65, -10', dialogue: 'Circuits sleep until the dark current wakes them.' },
    ],
  },
  {
    id: 'glass_observatory',
    name: 'Crystal Library & Observatory',
    summary: 'Stained glass dome over bookshelves, quartz pillars, and snow-cooled conduit.',
    breachRoof: false,
    doorOpening: false,
    composition: { glass: 0.38, crystal: 0.24, wood: 0.22, ice: 0.1, concrete: 0.06 },
    chestItems: [
      { id: 'minecraft:enchanted_book', label: 'Enchanted Book', archetype: 'archivist', roleTitle: 'Lorekeeper', count: 4, containerPos: '-24, 72, 19', dialogue: 'Margins once filled with ink now glow with prophecy.' },
      { id: 'minecraft:writable_book', label: 'Book and Quill', archetype: 'archivist', roleTitle: 'Lorekeeper', count: 2, containerPos: '-24, 72, 19', dialogue: 'Every chapter writes itself while you explore.' },
      { id: 'minecraft:potion', label: 'Potion of Night Vision', archetype: 'alchemist', roleTitle: 'Brewer', count: 3, containerPos: '-21, 72, 22', dialogue: 'Distilled under starlight; sharper still in shadow.' },
      { id: 'minecraft:diamond', label: 'Diamond', archetype: 'lapidary', roleTitle: 'Gemwright', count: 5, containerPos: '-26, 72, 18', dialogue: 'Light refracts differently inside a finite realm.' },
      { id: 'minecraft:purple_wool', label: 'Purple Wool', archetype: 'bard_tailor', roleTitle: 'Weaver', count: 12, containerPos: '-22, 72, 16', dialogue: 'We wove tapestries from the cushions of the study.' },
    ],
  },
  {
    id: 'nether_forge',
    name: 'Nether Crucible Vault',
    summary: 'Blackstone foundry lined with copper blocks, magma vents, and gilded bricks.',
    breachRoof: false,
    doorOpening: true,
    composition: { nether: 0.52, metal: 0.28, stone: 0.12, bricks: 0.08 },
    chestItems: [
      { id: 'minecraft:netherite_scrap', label: 'Netherite Scrap', archetype: 'ember_smith', roleTitle: 'Forgemaster', count: 3, containerPos: '104, 48, 31', dialogue: 'Forged in older fire; tempered anew by dark energy.' },
      { id: 'minecraft:blaze_rod', label: 'Blaze Rod', archetype: 'ember_smith', roleTitle: 'Forgemaster', count: 5, containerPos: '104, 48, 31', dialogue: 'Sparks keep the boundary fog at bay.' },
      { id: 'minecraft:gold_ingot', label: 'Gold Ingot', archetype: 'lapidary', roleTitle: 'Gemwright', count: 18, containerPos: '106, 48, 31', dialogue: 'Soft metal, loud voice in the plaza market.' },
      { id: 'minecraft:hopper', label: 'Hopper', archetype: 'tinker_automaton', roleTitle: 'Mechanist', count: 2, containerPos: '107, 48, 29', dialogue: 'Everything passes through me sooner or later.' },
    ],
  },
  {
    id: 'botanical_greenhouse',
    name: 'Overgrown Timber Atrium',
    summary: 'Oak log greenhouse packed with leaves, moss, water channels, and sand planters.',
    breachRoof: false,
    doorOpening: true,
    composition: { wood: 0.32, leaves: 0.28, organic: 0.2, water: 0.12, sand: 0.08 },
    chestItems: [
      { id: 'minecraft:golden_apple', label: 'Golden Apple', archetype: 'feastkeeper', roleTitle: 'Provisioner', count: 2, containerPos: '-8, 64, 44', dialogue: 'Harvested just before the atrium sank into twilight.' },
      { id: 'minecraft:bread', label: 'Bread', archetype: 'feastkeeper', roleTitle: 'Provisioner', count: 16, containerPos: '-8, 64, 44', dialogue: 'Fresh from the greenhouse pantry.' },
      { id: 'minecraft:music_disc_otherside', label: 'Music Disc', archetype: 'bard_tailor', roleTitle: 'Weaver', count: 1, containerPos: '-5, 64, 42', dialogue: 'Listen closely—the Fountain hums in the same key.' },
      { id: 'minecraft:splash_potion', label: 'Splash Potion', archetype: 'alchemist', roleTitle: 'Brewer', count: 4, containerPos: '-6, 64, 46', dialogue: 'Dew gathered off the canopy leaves.' },
    ],
  },
  {
    id: 'open_courtyard',
    name: 'Unsealed Courtyard (Breach Test)',
    summary: 'Missing ceiling section exposing interior air to open sky—tests flood-fill rejection.',
    breachRoof: true,
    doorOpening: true,
    composition: { grass: 0.45, stone: 0.35, wood: 0.2 },
    chestItems: [
      { id: 'minecraft:iron_pickaxe', label: 'Iron Pickaxe', archetype: 'tinker_automaton', roleTitle: 'Mechanist', count: 1, containerPos: '0, 64, 0', dialogue: 'Seal the roof before striking the earth!' },
    ],
  },
];

export interface FloodFillResult {
  valid: boolean;
  failureReason: string | null;
  volume: number;
  bounds: { min: [number, number, number]; max: [number, number, number] };
  openings: number;
  visitedSlices: number[][];
}

/**
 * Runs a real 3D BFS flood-fill over a 16x8x16 voxel room model.
 */
export function runFloodFillSimulation(
  breachRoof: boolean,
  doorOpening: boolean,
  permittedOpenings: number
): FloodFillResult {
  const W = 16;
  const H = 8;
  const D = 16;

  // Build 3D voxel room: 1 = solid wall/floor/ceiling, 0 = air
  const grid = new Uint8Array(W * H * D);
  const idx = (x: number, y: number, z: number) => (y * D + z) * W + x;

  for (let y = 0; y < H; y++) {
    for (let z = 0; z < D; z++) {
      for (let x = 0; x < W; x++) {
        const isWall =
          x === 1 || x === W - 2 || z === 1 || z === D - 2 || y === 0 || y === H - 1;
        const outside = x === 0 || x === W - 1 || z === 0 || z === D - 1;
        if (outside) {
          grid[idx(x, y, z)] = 0;
        } else if (isWall) {
          grid[idx(x, y, z)] = 1;
        } else {
          grid[idx(x, y, z)] = 0;
        }
      }
    }
  }

  // Optional 1x2 doorway on south wall (z = D - 2)
  if (doorOpening) {
    grid[idx(7, 1, D - 2)] = 0;
    grid[idx(7, 2, D - 2)] = 0;
  }

  // Optional wide roof breach (4x4 open sky hole)
  if (breachRoof) {
    for (let x = 6; x <= 10; x++) {
      for (let z = 6; z <= 10; z++) {
        grid[idx(x, H - 1, z)] = 0;
      }
    }
  }

  // BFS from fountain origin (8, 1, 8)
  const visited = new Uint8Array(W * H * D);
  const queue: number[] = [idx(8, 1, 8)];
  visited[idx(8, 1, 8)] = 1;
  let volume = 0;
  let openings = 0;
  let head = 0;
  const dirs = [
    [1, 0, 0],
    [-1, 0, 0],
    [0, 1, 0],
    [0, -1, 0],
    [0, 0, 1],
    [0, 0, -1],
  ];

  while (head < queue.length) {
    const cur = queue[head++];
    const x = cur % W;
    const y = Math.floor(cur / (W * D));
    const z = Math.floor((cur % (W * D)) / W);

    // Horizon / sky check
    if (x === 0 || x === W - 1 || z === 0 || z === D - 1 || y === H - 1) {
      openings++;
      continue;
    }

    volume++;
    for (const [dx, dy, dz] of dirs) {
      const nx = x + dx;
      const ny = y + dy;
      const nz = z + dz;
      if (nx < 0 || nx >= W || ny < 0 || ny >= H || nz < 0 || nz >= D) continue;
      const nIdx = idx(nx, ny, nz);
      if (visited[nIdx] || grid[nIdx] === 1) continue;
      visited[nIdx] = 1;
      queue.push(nIdx);
    }
  }

  // Capture mid-height slice (y = 2) for visualization
  const slice: number[][] = [];
  for (let z = 0; z < D; z++) {
    const row: number[] = [];
    for (let x = 0; x < W; x++) {
      const cell = idx(x, 2, z);
      if (x === 8 && z === 8) row.push(3); // Fountain
      else if (grid[cell] === 1) row.push(1); // Wall
      else if (visited[cell] === 1) row.push(2); // Flood-filled interior
      else row.push(0); // Exterior
    }
    slice.push(row);
  }

  if (breachRoof || openings > permittedOpenings) {
    return {
      valid: false,
      failureReason: `Rejected: ${openings} exterior sky/horizon leaks exceed permitted opening limit (${permittedOpenings}).`,
      volume,
      bounds: { min: [2, 1, 2], max: [13, 6, 13] },
      openings,
      visitedSlices: slice,
    };
  }

  return {
    valid: true,
    failureReason: null,
    volume,
    bounds: { min: [2, 1, 2], max: [13, 6, 13] },
    openings,
    visitedSlices: slice,
  };
}

export function selectDarkBiomes(composition: Partial<Record<MaterialId, number>>, maxBiomes = 4) {
  const significant = Object.values(composition).filter((v) => (v ?? 0) >= 0.05).length;
  const targetCount = Math.max(1, Math.min(maxBiomes, significant));

  const scored = BIOME_THEMES.map((theme) => {
    let score = 0;
    for (const [mat, val] of Object.entries(composition)) {
      const aff = theme.affinities[mat as MaterialId] ?? 0;
      score += (val ?? 0) * aff;
    }
    return { theme, score };
  })
    .filter((s) => s.score > 0.04)
    .sort((a, b) => b.score - a.score);

  const chosen = scored.slice(0, targetCount);
  if (chosen.length === 0) {
    return [{ theme: BIOME_THEMES[0], weight: 1 }];
  }
  const sum = chosen.reduce((acc, c) => acc + c.score, 0);
  return chosen.map((c) => ({ theme: c.theme, weight: c.score / sum }));
}

export function computeHueFromComposition(seed: number, composition: Partial<Record<MaterialId, number>>): number {
  const sorted = Object.entries(composition).sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0));
  const dominant = (sorted[0]?.[0] as MaterialId) || 'stone';
  const anchorMap: Record<MaterialId, number> = {
    stone: 265,
    concrete: 265,
    wood: 148,
    organic: 148,
    grass: 148,
    leaves: 155,
    sand: 36,
    ice: 195,
    water: 195,
    snow: 205,
    nether: 350,
    glass: 295,
    crystal: 295,
    metal: 212,
    end: 278,
    bricks: 325,
    decorative: 315,
    dirt: 118,
  };
  const anchor = anchorMap[dominant] ?? 265;
  const jitter = (((seed * 9301 + 49297) % 233280) / 233280 - 0.5) * 38;
  return ((anchor + jitter) % 360 + 360) % 360;
}

// Fast deterministic 2D Simplex-style noise for terrain canvas preview
function hash2(seed: number, x: number, y: number): number {
  let h = (seed ^ Math.imul(x, 374761393) ^ Math.imul(y, 668265263)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}

function valueNoise(seed: number, x: number, y: number): number {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = hash2(seed, xi, yi);
  const b = hash2(seed, xi + 1, yi);
  const c = hash2(seed, xi, yi + 1);
  const d = hash2(seed, xi + 1, yi + 1);
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v;
}

export function fbm2(seed: number, x: number, y: number, octaves = 3): number {
  let sum = 0;
  let amp = 0.5;
  let freq = 1;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += amp * (valueNoise(seed + i * 1013, x * freq, y * freq) * 2 - 1);
    norm += amp;
    amp *= 0.5;
    freq *= 2.05;
  }
  return sum / norm;
}

export function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  const hue = ((h % 360) + 360) % 360;
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((hue / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0, g = 0, b = 0;
  if (hue < 60) [r, g, b] = [c, x, 0];
  else if (hue < 120) [r, g, b] = [x, c, 0];
  else if (hue < 180) [r, g, b] = [0, c, x];
  else if (hue < 240) [r, g, b] = [0, x, c];
  else if (hue < 300) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}
