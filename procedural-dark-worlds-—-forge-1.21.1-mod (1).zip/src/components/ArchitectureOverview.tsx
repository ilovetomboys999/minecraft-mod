import React from 'react';

const MODULES = [
  {
    index: '01',
    title: 'Dark Fountain Activation & Server Validation',
    packagePath: 'com.darkworld.block · com.darkworld.network · com.darkworld.client',
    summary:
      'Pressing the configurable Z key (RegisterKeyMappingsEvent) while holding a darkworld:pointed_items item sends a C2S RequestFountainScanPacket over Forge 1.21.1 SimpleChannel. The server verifies item tags, reach, permissions, existing fountain clearance, and instance overlap before opening DarkWorldConfigScreen.',
  },
  {
    index: '02',
    title: 'Non-Destructive 3D Flood-Fill Detection',
    packagePath: 'com.darkworld.analysis.EnclosedSpaceDetector',
    summary:
      'Runs a breadth-first 3D air traversal bounded by configurable distance (48), volume (27–24,576), and exterior leak cluster limits (DarkWorldConfig). Captures interior bounds, boundary BlockStates, and container positions without modifying a single Overworld block.',
  },
  {
    index: '03',
    title: 'Tag-First Material Analyzer & Exception Registry',
    packagePath: 'com.darkworld.analysis.MaterialAnalyzer · BlockExceptionRegistry',
    summary:
      'Classifies room blocks across 18 MaterialCategory values using priority layering: datapack JSON overrides (darkworld/exceptions/*.json), darkworld:materials/* tags, vanilla/Forge 1.21.1 tags, and block properties. Supports dual weighted categories and excludes inventories from terrain ratios.',
  },
  {
    index: '04',
    title: 'Up to 4 Coherent Data-Driven Biomes',
    packagePath: 'com.darkworld.world.biome.DarkBiomeRegistry',
    summary:
      'Loads 10 extensible biome themes from data/darkworld/darkworld/biomes/*.json. Selects 1 to 4 biomes proportional to detected material diversity and arranges them into contiguous, domain-warped Simplex noise regions.',
  },
  {
    index: '05',
    title: 'Finite Isolated Worlds in darkworld:dark_world',
    packagePath: 'com.darkworld.world.DarkWorldManagerSavedData · DarkWorldBoundaryHandler',
    summary:
      'Allocates each created Dark World an isolated grid cell spaced 8,192 blocks apart inside a single registered custom dimension. Supports Small (512), Medium (1024), Large (2048), and Huge (4096) bounds with server-side edge pushback, placement locks, and boundary fog.',
  },
  {
    index: '06',
    title: 'Per-Instance Hue Identity & Inventory Darkners',
    packagePath: 'com.darkworld.world.DarkWorldHue · com.darkworld.darkner',
    summary:
      'Each Dark World persists a deterministic primary/secondary hue driving RegisterColorHandlersEvent block/item tints, particles, and ComputeFogColor. Room chests, barrels, furnaces, and shulkers spawn named DarknerEntity NPCs scaled to item variety with RPG dialogue boxes.',
  },
];

export const ArchitectureOverview: React.FC = () => {
  return (
    <div className="mx-auto max-w-[1320px] px-6 py-8">
      <div className="mb-8 border-b border-slate-800/80 pb-6">
        <h1 className="font-display text-2xl font-semibold text-slate-50">
          Forge 1.21.1 Architecture &amp; Build Guide
        </h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          Target environment: Minecraft Java Edition 1.21.1 · Minecraft Forge 52.0.16 · Java 21 ·
          ForgeGradle 6 · Official Mojang mappings.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {MODULES.map((m) => (
          <article
            key={m.index}
            className="rounded-lg border border-slate-800/90 bg-[#10131c] p-6"
          >
            <div className="text-xs font-mono text-slate-400">{m.packagePath}</div>
            <h2 className="mt-2 font-display text-lg font-semibold text-slate-100">
              {m.index}. {m.title}
            </h2>
            <p className="mt-2.5 text-sm leading-relaxed text-slate-300">{m.summary}</p>
          </article>
        ))}
      </div>

      <section className="mt-8 rounded-lg border border-slate-800/90 bg-[#10131c] p-6">
        <h2 className="font-display text-lg font-semibold text-slate-100">
          Local Gradle Setup Instructions
        </h2>
        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">
          <div className="rounded border border-slate-800 bg-[#080a10] p-4">
            <div className="text-xs font-medium text-slate-200">1. Download &amp; Extract</div>
            <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
              Use the top-right Download Mod button to export the complete{' '}
              <span className="font-mono text-slate-300">forge-mod/</span> archive and extract it
              locally with Java 21 installed.
            </p>
          </div>
          <div className="rounded border border-slate-800 bg-[#080a10] p-4">
            <div className="text-xs font-medium text-slate-200">2. Launch Client</div>
            <pre className="mt-2 overflow-x-auto font-mono text-xs text-slate-300">
              gradle runClient
            </pre>
            <p className="mt-1.5 text-xs text-slate-400">
              Or generate a wrapper first with <span className="font-mono">gradle wrapper</span>.
            </p>
          </div>
          <div className="rounded border border-slate-800 bg-[#080a10] p-4">
            <div className="text-xs font-medium text-slate-200">3. Build Mod JAR</div>
            <pre className="mt-2 overflow-x-auto font-mono text-xs text-slate-300">
              ./gradlew build
            </pre>
            <p className="mt-1.5 text-xs text-slate-400">
              Outputs <span className="font-mono">darkworld-1.0.0.jar</span> inside{' '}
              <span className="font-mono">build/libs/</span>.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
