import React, { useEffect, useMemo, useState } from 'react';
import { Check, Copy, FileCode2, FolderTree, Search } from 'lucide-react';

interface ModFileEntry {
  path: string;
  category: string;
  size: number;
  isBinary: boolean;
}

export const ModCodeBrowser: React.FC = () => {
  const [files, setFiles] = useState<ModFileEntry[]>([]);
  const [loadingList, setLoadingList] = useState(true);
  const [selectedPath, setSelectedPath] = useState<string>('src/main/java/com/darkworld/DarkWorldMod.java');
  const [fileContent, setFileContent] = useState<string>('');
  const [binaryDataUrl, setBinaryDataUrl] = useState<string | null>(null);
  const [loadingFile, setLoadingFile] = useState(false);
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch('/api/mod-files')
      .then((res) => res.json())
      .then((data) => {
        setFiles(data.files || []);
        setLoadingList(false);
      })
      .catch(() => setLoadingList(false));
  }, []);

  useEffect(() => {
    if (!selectedPath) return;
    setLoadingFile(true);
    fetch(`/api/mod-file?path=${encodeURIComponent(selectedPath)}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.isBinary) {
          setBinaryDataUrl(data.dataUrl || null);
          setFileContent('');
        } else {
          setBinaryDataUrl(null);
          setFileContent(data.content || '');
        }
        setLoadingFile(false);
      })
      .catch(() => setLoadingFile(false));
  }, [selectedPath]);

  const categories = useMemo(() => {
    const unique = Array.from(new Set(files.map((f) => f.category)));
    return ['All', ...unique];
  }, [files]);

  const filteredFiles = useMemo(() => {
    const q = query.trim().toLowerCase();
    return files.filter((f) => {
      if (activeCategory !== 'All' && f.category !== activeCategory) return false;
      if (!q) return true;
      return f.path.toLowerCase().includes(q) || f.category.toLowerCase().includes(q);
    });
  }, [files, query, activeCategory]);

  const copyContent = async () => {
    if (!fileContent) return;
    await navigator.clipboard.writeText(fileContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  return (
    <div className="mx-auto max-w-[1320px] px-6 py-8">
      <div className="mb-6 flex flex-col gap-4 border-b border-slate-800/80 pb-5 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold text-slate-50">
            Forge 1.21.1 Mod Source Explorer
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            {files.length} files in <span className="font-mono text-slate-300">forge-mod/</span> ·
            Java 21 · ForgeGradle 6 · Forge 52.0.16
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter files..."
              className="w-56 rounded border border-slate-800 bg-[#080a10] py-1.5 pl-8 pr-3 text-xs text-slate-200 placeholder:text-slate-500 focus:border-slate-500 focus:outline-none"
            />
          </div>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-1.5">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`whitespace-nowrap shrink-0 rounded px-2.5 py-1 text-xs font-medium transition-colors ${
              activeCategory === cat
                ? 'bg-slate-100 text-slate-950'
                : 'border border-slate-800 bg-[#10131c] text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* File List */}
        <aside className="max-h-[640px] overflow-y-auto rounded-lg border border-slate-800/90 bg-[#10131c] p-2 lg:col-span-4">
          {loadingList ? (
            <div className="p-4 text-xs text-slate-400">Loading mod files...</div>
          ) : filteredFiles.length === 0 ? (
            <div className="p-4 text-xs text-slate-400">No matching files.</div>
          ) : (
            <div className="space-y-0.5">
              {filteredFiles.map((file) => {
                const active = file.path === selectedPath;
                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedPath(file.path)}
                    className={`flex w-full items-center justify-between rounded px-2.5 py-2 text-left text-xs transition-colors ${
                      active
                        ? 'bg-slate-800 text-white'
                        : 'text-slate-300 hover:bg-slate-900/70'
                    }`}
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      <FileCode2 className="h-3.5 w-3.5 shrink-0 text-slate-500" />
                      <span className="truncate font-mono text-[11px]">{file.path}</span>
                    </span>
                    <span className="ml-2 shrink-0 font-mono text-[10px] tabular-nums text-slate-500">
                      {file.size}B
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </aside>

        {/* File Viewer */}
        <section className="flex flex-col overflow-hidden rounded-lg border border-slate-800/90 bg-[#080a10] lg:col-span-8">
          <div className="flex items-center justify-between border-b border-slate-800/90 bg-[#10131c] px-4 py-2.5">
            <div className="flex min-w-0 items-center gap-2 font-mono text-xs text-slate-200">
              <FolderTree className="h-3.5 w-3.5 shrink-0 text-slate-400" />
              <span className="truncate">{selectedPath}</span>
            </div>
            {!binaryDataUrl && (
              <button
                onClick={copyContent}
                className="flex shrink-0 items-center gap-1.5 rounded border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs font-medium text-slate-200 hover:border-slate-500"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            )}
          </div>

          <div className="max-h-[590px] overflow-auto p-4">
            {loadingFile ? (
              <div className="font-mono text-xs text-slate-400">Reading file...</div>
            ) : binaryDataUrl ? (
              <div className="flex flex-col items-center justify-center py-12">
                <img
                  src={binaryDataUrl}
                  alt={selectedPath}
                  className="h-32 w-32 rounded border border-slate-800 [image-rendering:pixelated]"
                />
                <span className="mt-3 font-mono text-xs text-slate-400">
                  Generated PNG Texture Asset ({selectedPath})
                </span>
              </div>
            ) : selectedPath.endsWith('.jar') ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <span className="font-mono text-xs text-slate-300">
                  Binary Gradle Wrapper Archive ({selectedPath})
                </span>
                <span className="mt-1.5 text-xs text-slate-500">
                  Included in the mod download so ./gradlew build works out of the box.
                </span>
              </div>
            ) : (
              <pre className="font-mono text-xs leading-relaxed text-slate-200">
                <code>{fileContent}</code>
              </pre>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};
