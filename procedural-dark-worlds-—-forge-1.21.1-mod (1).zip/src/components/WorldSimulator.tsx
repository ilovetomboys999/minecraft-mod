import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  BIOME_THEMES,
  ChestItemEntry,
  computeHueFromComposition,
  fbm2,
  hslToRgb,
  MaterialId,
  ROOM_PRESETS,
  runFloodFillSimulation,
  selectDarkBiomes,
  WORLD_SIZES,
  WorldSizeId,
} from '../sim/darkWorldEngine';

const EXTRA_CHEST_ITEMS: Omit<ChestItemEntry, 'count' | 'containerPos'>[] = [
  {
    id: 'minecraft:enchanted_book',
    label: 'Enchanted Book',
    archetype: 'archivist',
    roleTitle: 'Lorekeeper',
    dialogue: 'Margins once filled with ink now glow with prophecy.',
  },
  {
    id: 'minecraft:diamond',
    label: 'Diamond',
    archetype: 'lapidary',
    roleTitle: 'Gemwright',
    dialogue: 'Light refracts differently inside a finite realm.',
  },
  {
    id: 'minecraft:potion',
    label: 'Potion of Swiftness',
    archetype: 'alchemist',
    roleTitle: 'Brewer',
    dialogue: 'Distilled under starlight; sharper still in shadow.',
  },
  {
    id: 'minecraft:redstone',
    label: 'Redstone Dust',
    archetype: 'tinker_automaton',
    roleTitle: 'Mechanist',
    dialogue: 'Circuits sleep until the dark current wakes them.',
  },
  {
    id: 'minecraft:golden_apple',
    label: 'Golden Apple',
    archetype: 'feastkeeper',
    roleTitle: 'Provisioner',
    dialogue: 'Harvested just before the atrium sank into twilight.',
  },
  {
    id: 'minecraft:iron_sword',
    label: 'Iron Sword',
    archetype: 'blade_knight',
    roleTitle: 'Vanguard',
    dialogue: 'My edge remembers the anvil before the Fountain struck.',
  },
];

interface HoverInfo {
  wx: number;
  wz: number;
  elevation: number;
  biomeName: string;
  edgeDist: number;
}

export const WorldSimulator: React.FC = () => {
  const [presetId, setPresetId] = useState<string>(ROOM_PRESETS[0].id);
  const preset = useMemo(
    () => ROOM_PRESETS.find((p) => p.id === presetId) ?? ROOM_PRESETS[0],
    [presetId]
  );

  const [breachRoof, setBreachRoof] = useState<boolean>(preset.breachRoof);
  const [doorOpening, setDoorOpening] = useState<boolean>(preset.doorOpening);
  const [worldSize, setWorldSize] = useState<WorldSizeId>('large');
  const [seed, setSeed] = useState<number>(482917);
  const [hueOverride, setHueOverride] = useState<number>(() =>
    Math.round(computeHueFromComposition(482917, preset.composition))
  );
  const [chestItems, setChestItems] = useState<ChestItemEntry[]>(preset.chestItems);
  const [selectedDarknerIdx, setSelectedDarknerIdx] = useState<number>(0);
  const [hoverInfo, setHoverInfo] = useState<HoverInfo | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const selectPreset = (id: string) => {
    const next = ROOM_PRESETS.find((p) => p.id === id) ?? ROOM_PRESETS[0];
    setPresetId(id);
    setBreachRoof(next.breachRoof);
    setDoorOpening(next.doorOpening);
    setChestItems(next.chestItems);
    setSelectedDarknerIdx(0);
    setHueOverride(Math.round(computeHueFromComposition(seed, next.composition)));
  };

  const floodFill = useMemo(
    () => runFloodFillSimulation(breachRoof, doorOpening, 18),
    [breachRoof, doorOpening]
  );

  const selectedBiomes = useMemo(
    () => selectDarkBiomes(preset.composition, 4),
    [preset.composition]
  );

  const sortedMaterials = useMemo(
    () =>
      Object.entries(preset.composition)
        .filter(([, val]) => (val ?? 0) > 0)
        .sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0)) as [MaterialId, number][],
    [preset.composition]
  );

  // Darkner population scaling proportional to distinct item types
  const darknerRoster = useMemo(() => {
    const uniqueTypes = chestItems.length;
    const totalCount = chestItems.reduce((sum, item) => sum + item.count, 0);
    const budget = Math.min(48, Math.max(4, uniqueTypes * 2 + Math.floor(Math.sqrt(totalCount))));
    return chestItems.map((item, idx) => {
      const share = Math.max(1, Math.min(4, Math.round(budget / Math.max(1, uniqueTypes))));
      return {
        ...item,
        spawnCount: share,
        accentRgb: hslToRgb((hueOverride + idx * 37) % 360, 0.72, 0.62),
      };
    });
  }, [chestItems, hueOverride]);

  const totalDarkners = useMemo(
    () => darknerRoster.reduce((acc, d) => acc + d.spawnCount, 0),
    [darknerRoster]
  );

  const activeDarkner = darknerRoster[selectedDarknerIdx] ?? darknerRoster[0];

  // Render finite procedural Dark World biome + elevation canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const sizePx = 360;
    const img = ctx.createImageData(sizePx, sizePx);
    const sideBlocks = WORLD_SIZES[worldSize].side;
    const half = sideBlocks / 2;

    for (let py = 0; py < sizePx; py++) {
      for (let px = 0; px < sizePx; px++) {
        const wx = ((px / sizePx) - 0.5) * sideBlocks;
        const wz = ((py / sizePx) - 0.5) * sideBlocks;
        const edgeDist = Math.min(half - Math.abs(wx), half - Math.abs(wz));
        const offset = (py * sizePx + px) * 4;

        if (!floodFill.valid) {
          // Dimmed unsealed preview
          img.data[offset] = 18;
          img.data[offset + 1] = 20;
          img.data[offset + 2] = 28;
          img.data[offset + 3] = 255;
          continue;
        }

        // Domain warp coordinates
        const warpX = wx + fbm2(seed + 17, wx * 0.0025, wz * 0.0025, 2) * 85;
        const warpZ = wz + fbm2(seed + 43, wx * 0.0025 + 31, wz * 0.0025 + 17, 2) * 85;

        let bestIdx = 0;
        let bestScore = -999;
        for (let i = 0; i < selectedBiomes.length; i++) {
          const b = selectedBiomes[i];
          const field = fbm2(seed + (i + 1) * 9187, warpX * 0.0024, warpZ * 0.0024, 3);
          const score = field * 0.5 + 0.5 + b.weight * 0.85;
          if (score > bestScore) {
            bestScore = score;
            bestIdx = i;
          }
        }

        const biome = selectedBiomes[bestIdx]?.theme ?? BIOME_THEMES[0];
        const elev = fbm2(seed + 71, warpX * 0.0045, warpZ * 0.0045, 3);
        const ridge = 1 - Math.abs(fbm2(seed + 313, warpX * 0.007, warpZ * 0.007, 2));
        const height = biome.baseHeight + elev * biome.amplitude + (ridge - 0.4) * biome.amplitude * biome.ridgeWeight;

        const isFluid = height < 62;
        const hue = (hueOverride + biome.hueShift + 360) % 360;
        const sat = isFluid ? 0.65 : 0.55;
        const light = isFluid
          ? 0.24
          : Math.max(0.18, Math.min(0.68, 0.28 + ((height - 58) / 48) * 0.36));
        let [r, g, bCol] = hslToRgb(hue, sat, light);

        // Contour lines every 6 blocks of height
        if (!isFluid && Math.abs(Math.round(height) % 6) === 0) {
          r = Math.max(0, r - 18);
          g = Math.max(0, g - 18);
          bCol = Math.max(0, bCol - 18);
        }

        // Finite edge fog vignette
        const borderBand = sideBlocks * 0.035;
        if (edgeDist < borderBand) {
          const t = Math.max(0, edgeDist / borderBand);
          r = Math.round(r * t + 8 * (1 - t));
          g = Math.round(g * t + 10 * (1 - t));
          bCol = Math.round(bCol * t + 16 * (1 - t));
        }

        img.data[offset] = r;
        img.data[offset + 1] = g;
        img.data[offset + 2] = bCol;
        img.data[offset + 3] = 255;
      }
    }

    ctx.putImageData(img, 0, 0);

    if (floodFill.valid) {
      // Draw central Arrival Plaza + Return Fountain marker
      const center = sizePx / 2;
      ctx.strokeStyle = 'rgba(255,255,255,0.85)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(center - 6, center - 6, 12, 12);

      const [pr, pg, pb] = hslToRgb((hueOverride + 40) % 360, 0.9, 0.72);
      ctx.fillStyle = `rgb(${pr},${pg},${pb})`;
      ctx.beginPath();
      ctx.arc(center, center, 3.5, 0, Math.PI * 2);
      ctx.fill();

      // Draw Darkner spawn markers around plaza
      darknerRoster.forEach((d, i) => {
        const angle = (i / Math.max(1, darknerRoster.length)) * Math.PI * 2;
        const rad = 14 + (i % 3) * 6;
        ctx.fillStyle = `rgb(${d.accentRgb[0]},${d.accentRgb[1]},${d.accentRgb[2]})`;
        ctx.fillRect(center + Math.cos(angle) * rad - 2, center + Math.sin(angle) * rad - 2, 4, 4);
      });
    }
  }, [floodFill.valid, worldSize, seed, hueOverride, selectedBiomes, darknerRoster]);

  const handleMapMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width;
    const ny = (e.clientY - rect.top) / rect.height;
    const side = WORLD_SIZES[worldSize].side;
    const half = side / 2;
    const wx = Math.round((nx - 0.5) * side);
    const wz = Math.round((ny - 0.5) * side);
    const edgeDist = Math.max(0, Math.round(Math.min(half - Math.abs(wx), half - Math.abs(wz))));

    const warpX = wx + fbm2(seed + 17, wx * 0.0025, wz * 0.0025, 2) * 85;
    const warpZ = wz + fbm2(seed + 43, wx * 0.0025 + 31, wz * 0.0025 + 17, 2) * 85;

    let bestIdx = 0;
    let bestScore = -999;
    for (let i = 0; i < selectedBiomes.length; i++) {
      const b = selectedBiomes[i];
      const field = fbm2(seed + (i + 1) * 9187, warpX * 0.0024, warpZ * 0.0024, 3);
      const score = field * 0.5 + 0.5 + b.weight * 0.85;
      if (score > bestScore) {
        bestScore = score;
        bestIdx = i;
      }
    }
    const biome = selectedBiomes[bestIdx]?.theme ?? BIOME_THEMES[0];
    const elev = fbm2(seed + 71, warpX * 0.0045, warpZ * 0.0045, 3);
    const elevation = Math.round(biome.baseHeight + elev * biome.amplitude);

    setHoverInfo({ wx, wz, elevation, biomeName: biome.name, edgeDist });
  };

  const addExtraChestItem = () => {
    const nextCandidate = EXTRA_CHEST_ITEMS.find(
      (candidate) => !chestItems.some((existing) => existing.id === candidate.id)
    );
    if (!nextCandidate) return;
    setChestItems((prev) => [
      ...prev,
      {
        ...nextCandidate,
        count: 3,
        containerPos: `${12 + prev.length * 2}, 65, -${6 + prev.length}`,
      },
    ]);
  };

  const removeChestItem = (id: string) => {
    setChestItems((prev) => (prev.length > 1 ? prev.filter((item) => item.id !== id) : prev));
    setSelectedDarknerIdx(0);
  };

  const [primaryR, primaryG, primaryB] = hslToRgb(hueOverride, 0.76, 0.58);
  const [secondaryR, secondaryG, secondaryB] = hslToRgb((hueOverride + 48) % 360, 0.78, 0.64);
  const accentCss = `rgb(${primaryR}, ${primaryG}, ${primaryB})`;
  const secondaryCss = `rgb(${secondaryR}, ${secondaryG}, ${secondaryB})`;

  return (
    <div className="mx-auto max-w-[1320px] px-6 py-8">
      {/* Intro & Room Preset Selector */}
      <div className="mb-8 flex flex-col gap-4 border-b border-slate-800/80 pb-6 lg:flex-row lg:items-end lg:justify-between">
        <div className="max-w-2xl">
          <h1 className="font-display text-3xl font-semibold tracking-tight text-slate-50 [text-wrap:balance]">
            Dark Fountain &amp; World Generation Workbench
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-slate-400">
            Test the Forge 1.21.1 mod pipeline interactively: run the 3D enclosed-space flood fill,
            inspect material-driven biome selection, tune per-world hue identity, and preview
            inventory-born Darkner populations.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {ROOM_PRESETS.map((p) => {
            const active = p.id === presetId;
            return (
              <button
                key={p.id}
                onClick={() => selectPreset(p.id)}
                className={`whitespace-nowrap shrink-0 rounded-md border px-3 py-2 text-xs font-medium transition-colors ${
                  active
                    ? 'border-slate-300 bg-slate-100 text-slate-950'
                    : 'border-slate-800 bg-slate-900/70 text-slate-300 hover:border-slate-700 hover:text-white'
                }`}
              >
                {p.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Two-Zone Sandbox Layout */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
        {/* Left Interactive Stage (7 cols) */}
        <div className="flex flex-col gap-8 lg:col-span-7">
          {/* Stage 1: Finite Dark World Terrain & Hue Map */}
          <section className="rounded-lg border border-slate-800/90 bg-[#10131c] p-6">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-display text-lg font-semibold text-slate-100">
                  01. Finite Dark World Map &amp; Hue Identity
                </h2>
                <p className="mt-0.5 text-xs text-slate-400">
                  {WORLD_SIZES[worldSize].label} Instance ({WORLD_SIZES[worldSize].side} ×{' '}
                  {WORLD_SIZES[worldSize].side} blocks) · Domain-warped Simplex terrain ·{' '}
                  {selectedBiomes.length} active biome{selectedBiomes.length > 1 ? 's' : ''}
                </p>
              </div>
              <div className="flex items-center gap-3 text-xs font-mono tabular-nums text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span
                    className="inline-block h-3 w-3 rounded-sm border border-white/20"
                    style={{ backgroundColor: accentCss }}
                  />
                  Primary {hueOverride}°
                </span>
                <span className="flex items-center gap-1.5">
                  <span
                    className="inline-block h-3 w-3 rounded-sm border border-white/20"
                    style={{ backgroundColor: secondaryCss }}
                  />
                  Secondary {(hueOverride + 48) % 360}°
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6 md:grid-cols-12">
              <div className="md:col-span-7">
                <div className="relative overflow-hidden rounded-md border border-slate-800 bg-[#080a10]">
                  <canvas
                    ref={canvasRef}
                    width={360}
                    height={360}
                    onMouseMove={handleMapMove}
                    onMouseLeave={() => setHoverInfo(null)}
                    className="block aspect-square w-full cursor-crosshair"
                  />
                  {!floodFill.valid && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/85 p-6 text-center">
                      <p className="font-display text-base font-semibold text-rose-400">
                        Dark Fountain Blocked
                      </p>
                      <p className="mt-2 max-w-xs text-xs leading-relaxed text-slate-300">
                        {floodFill.failureReason}
                      </p>
                    </div>
                  )}
                </div>
                <div className="mt-2.5 flex items-center justify-between text-xs font-mono tabular-nums text-slate-400">
                  {hoverInfo && floodFill.valid ? (
                    <>
                      <span>
                        XZ ({hoverInfo.wx}, {hoverInfo.wz}) · Y {hoverInfo.elevation}
                      </span>
                      <span>
                        {hoverInfo.biomeName} · Edge {hoverInfo.edgeDist}m
                      </span>
                    </>
                  ) : (
                    <span>Hover over map to inspect terrain height &amp; biome region</span>
                  )}
                </div>
              </div>

              {/* Enclosed Space 3D BFS Slice */}
              <div className="flex flex-col justify-between md:col-span-5">
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">
                    02. 3D Flood-Fill Room Slice (Y = +1)
                  </h3>
                  <p className="mt-1 text-xs text-slate-400">
                    {preset.summary}
                  </p>

                  <div className="mt-4 grid grid-cols-16 gap-0.5 rounded-md border border-slate-800 bg-[#080a10] p-2">
                    {floodFill.visitedSlices.flatMap((row, z) =>
                      row.map((cell, x) => {
                        let bg = '#111520'; // exterior
                        if (cell === 1) bg = '#475569'; // wall
                        else if (cell === 2) bg = floodFill.valid ? 'rgba(99, 102, 241, 0.45)' : 'rgba(244, 63, 94, 0.35)';
                        else if (cell === 3) bg = accentCss;
                        return (
                          <div
                            key={`${x}-${z}`}
                            className="aspect-square rounded-[1px]"
                            style={{ backgroundColor: bg }}
                            title={
                              cell === 3
                                ? 'Dark Fountain Origin'
                                : cell === 1
                                ? 'Boundary Wall'
                                : cell === 2
                                ? 'Flood-Filled Interior Air'
                                : 'Exterior Air'
                            }
                          />
                        );
                      })
                    )}
                  </div>
                </div>

                <div className="mt-4 space-y-2 border-t border-slate-800/80 pt-4 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Validation State</span>
                    <span
                      className={`font-mono font-medium ${
                        floodFill.valid ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {floodFill.valid ? 'ENCLOSED · READY' : 'UNSEALED · REJECTED'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between font-mono tabular-nums text-slate-300">
                    <span className="font-sans text-slate-400">Interior Air Volume</span>
                    <span>{floodFill.volume.toLocaleString()} blocks</span>
                  </div>
                  <div className="flex items-center justify-between font-mono tabular-nums text-slate-300">
                    <span className="font-sans text-slate-400">Exterior Leaks</span>
                    <span>{floodFill.openings} / 18 max</span>
                  </div>
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={() => setBreachRoof((v) => !v)}
                      className={`flex-1 whitespace-nowrap rounded border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                        breachRoof
                          ? 'border-rose-500/60 bg-rose-950/50 text-rose-200'
                          : 'border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-600'
                      }`}
                    >
                      {breachRoof ? 'Seal Roof Breach' : 'Carve Roof Breach'}
                    </button>
                    <button
                      onClick={() => setDoorOpening((v) => !v)}
                      className={`flex-1 whitespace-nowrap rounded border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                        doorOpening
                          ? 'border-amber-500/50 bg-amber-950/30 text-amber-200'
                          : 'border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-600'
                      }`}
                    >
                      {doorOpening ? 'Close Doorway' : 'Open Doorway'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Stage 2: Inventory-Born Darkner RPG Roster */}
          <section className="rounded-lg border border-slate-800/90 bg-[#10131c] p-6">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-display text-lg font-semibold text-slate-100">
                  03. Inventory-Born Darkner Population
                </h2>
                <p className="mt-0.5 text-xs text-slate-400">
                  {chestItems.length} distinct item types · {totalDarkners} total Darkners generated
                  for this instance
                </p>
              </div>
              <button
                onClick={addExtraChestItem}
                disabled={chestItems.length >= EXTRA_CHEST_ITEMS.length}
                className="whitespace-nowrap shrink-0 rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:border-slate-500 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Add Chest Item Type
              </button>
            </div>

            <div className="grid grid-cols-1 gap-6 md:grid-cols-12">
              <div className="divide-y divide-slate-800/80 border border-slate-800/80 rounded-md md:col-span-6">
                {darknerRoster.map((d, idx) => {
                  const selected = idx === selectedDarknerIdx;
                  return (
                    <div
                      key={d.id}
                      onClick={() => setSelectedDarknerIdx(idx)}
                      className={`flex cursor-pointer items-center justify-between px-3.5 py-2.5 text-xs transition-colors ${
                        selected ? 'bg-slate-800/70 text-white' : 'hover:bg-slate-900/60 text-slate-300'
                      }`}
                    >
                      <div className="min-w-0 pr-2">
                        <div className="truncate font-medium">
                          {d.label} {d.roleTitle}
                        </div>
                        <div className="truncate font-mono text-[11px] text-slate-400">
                          {d.id} · ({d.containerPos})
                        </div>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <span className="font-mono tabular-nums text-slate-300">
                          ×{d.spawnCount}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            removeChestItem(d.id);
                          }}
                          className="text-slate-500 hover:text-rose-400"
                          title="Remove item type"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Deltarune-style RPG Dialogue Frame Preview */}
              <div className="flex flex-col justify-between rounded-md border-2 border-slate-200 bg-[#06070b] p-5 md:col-span-6">
                {activeDarkner ? (
                  <>
                    <div>
                      <div
                        className="font-mono text-xs font-semibold tracking-wide"
                        style={{
                          color: `rgb(${activeDarkner.accentRgb[0]}, ${activeDarkner.accentRgb[1]}, ${activeDarkner.accentRgb[2]})`,
                        }}
                      >
                        * {activeDarkner.label} {activeDarkner.roleTitle} [{activeDarkner.roleTitle}]
                      </div>
                      <p className="mt-3 font-mono text-sm leading-relaxed text-slate-100">
                        * &ldquo;{activeDarkner.dialogue}&rdquo;
                      </p>
                    </div>
                    <div className="mt-5 border-t border-slate-800 pt-3 font-mono text-[11px] text-slate-400">
                      <div>Origin Item: {activeDarkner.id} (stack {activeDarkner.count})</div>
                      <div>Source Chest: ({activeDarkner.containerPos})</div>
                    </div>
                  </>
                ) : null}
              </div>
            </div>
          </section>
        </div>

        {/* Right Control & Configuration Deck (5 cols) */}
        <div className="flex flex-col gap-6 lg:col-span-5">
          {/* Dark Fountain Pre-Generation Configuration */}
          <section className="rounded-lg border border-slate-800/90 bg-[#10131c] p-6">
            <h2 className="font-display text-lg font-semibold text-slate-100">
              Dark Fountain Configuration
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              Mirrors the in-game <span className="font-mono text-slate-300">DarkWorldConfigScreen</span>{' '}
              opened when pressing <span className="font-mono text-slate-300">Z</span> with a{' '}
              <span className="font-mono text-slate-300">darkworld:pointed_items</span> item.
            </p>

            {/* World Size Selector */}
            <div className="mt-5">
              <label className="block text-xs font-medium text-slate-300">
                Finite World Size
              </label>
              <div className="mt-2 grid grid-cols-4 gap-1.5 rounded-md border border-slate-800 bg-[#080a10] p-1">
                {(Object.keys(WORLD_SIZES) as WorldSizeId[]).map((id) => {
                  const active = id === worldSize;
                  return (
                    <button
                      key={id}
                      onClick={() => setWorldSize(id)}
                      className={`whitespace-nowrap rounded py-1.5 text-xs font-medium transition-colors ${
                        active
                          ? 'bg-slate-100 text-slate-950'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {WORLD_SIZES[id].label}
                    </button>
                  );
                })}
              </div>
              <div className="mt-1.5 flex justify-between font-mono text-[11px] tabular-nums text-slate-400">
                <span>Bounds: {WORLD_SIZES[worldSize].side} × {WORLD_SIZES[worldSize].side}</span>
                <span>Grid Stride: 8,192 blocks</span>
              </div>
            </div>

            {/* Hue Identity Slider */}
            <div className="mt-5">
              <div className="flex items-center justify-between text-xs">
                <label htmlFor="hue-slider" className="font-medium text-slate-300">
                  World Base Hue
                </label>
                <span className="font-mono tabular-nums text-slate-200">{hueOverride}°</span>
              </div>
              <input
                id="hue-slider"
                type="range"
                min={0}
                max={359}
                value={hueOverride}
                onChange={(e) => setHueOverride(Number(e.target.value))}
                className="mt-2 w-full accent-slate-100"
              />
            </div>

            {/* Seed Control */}
            <div className="mt-5 flex items-end gap-2">
              <div className="flex-1">
                <label htmlFor="seed-input" className="block text-xs font-medium text-slate-300">
                  Deterministic World Seed
                </label>
                <input
                  id="seed-input"
                  type="number"
                  value={seed}
                  onChange={(e) => setSeed(Number(e.target.value) || 1)}
                  className="mt-1.5 w-full rounded border border-slate-800 bg-[#080a10] px-3 py-1.5 font-mono text-xs tabular-nums text-slate-200 focus:border-slate-500 focus:outline-none"
                />
              </div>
              <button
                onClick={() => {
                  const nextSeed = Math.floor(Math.random() * 900000) + 100000;
                  setSeed(nextSeed);
                  setHueOverride(Math.round(computeHueFromComposition(nextSeed, preset.composition)));
                }}
                className="whitespace-nowrap rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-500"
              >
                New Seed
              </button>
            </div>
          </section>

          {/* Material Composition Analysis */}
          <section className="rounded-lg border border-slate-800/90 bg-[#10131c] p-6">
            <h2 className="font-display text-lg font-semibold text-slate-100">
              Analyzed Room Materials
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              Tag-first classification excluding inventory containers from terrain ratios.
            </p>
            <div className="mt-4 space-y-3">
              {sortedMaterials.map(([mat, weight]) => (
                <div key={mat}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span className="capitalize text-slate-200">{mat}</span>
                    <span className="font-mono tabular-nums text-slate-300">
                      {Math.round(weight * 100)}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full rounded-full transition-all duration-200"
                      style={{
                        width: `${Math.round(weight * 100)}%`,
                        backgroundColor: accentCss,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Selected Biome Themes (Max 4) */}
          <section className="rounded-lg border border-slate-800/90 bg-[#10131c] p-6">
            <h2 className="font-display text-lg font-semibold text-slate-100">
              Selected Dark Biomes ({selectedBiomes.length} / 4 Max)
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              Biome count scales strictly with detected material diversity.
            </p>
            <div className="mt-4 divide-y divide-slate-800/80 border-t border-slate-800/80">
              {selectedBiomes.map(({ theme, weight }) => {
                const [br, bg, bb] = hslToRgb((hueOverride + theme.hueShift + 360) % 360, 0.72, 0.58);
                return (
                  <div key={theme.id} className="flex items-center justify-between py-2.5 text-xs">
                    <div className="flex items-center gap-2.5">
                      <span
                        className="h-2.5 w-2.5 rounded-sm"
                        style={{ backgroundColor: `rgb(${br},${bg},${bb})` }}
                      />
                      <span className="font-medium text-slate-200">{theme.name}</span>
                    </div>
                    <span className="font-mono tabular-nums text-slate-400">
                      {Math.round(weight * 100)}% area · base Y={theme.baseHeight}
                    </span>
                  </div>
                );
              })}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
