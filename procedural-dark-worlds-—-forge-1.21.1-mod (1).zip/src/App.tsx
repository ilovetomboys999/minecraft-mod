import { useState } from 'react';
import { Download } from 'lucide-react';
import { WorldSimulator } from './components/WorldSimulator';
import { ModCodeBrowser } from './components/ModCodeBrowser';
import { ArchitectureOverview } from './components/ArchitectureOverview';

type TabId = 'simulator' | 'source' | 'architecture';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('simulator');

  return (
    <div className="min-h-screen bg-[#0b0d13] text-slate-100">
      <header className="border-b border-slate-800/80 bg-[#0b0d13]/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-[1320px] items-center justify-between gap-8 px-6 py-4">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('simulator');
            }}
            className="font-display text-lg font-semibold tracking-tight text-slate-50 whitespace-nowrap shrink-0"
          >
            Procedural Dark Worlds
          </a>

          <nav className="flex items-center gap-6 text-sm font-medium text-slate-400">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`whitespace-nowrap shrink-0 border-b-2 py-1 transition-colors ${
                activeTab === 'simulator'
                  ? 'border-slate-100 text-slate-50'
                  : 'border-transparent hover:text-slate-200'
              }`}
            >
              Simulator
            </button>
            <button
              onClick={() => setActiveTab('source')}
              className={`whitespace-nowrap shrink-0 border-b-2 py-1 transition-colors ${
                activeTab === 'source'
                  ? 'border-slate-100 text-slate-50'
                  : 'border-transparent hover:text-slate-200'
              }`}
            >
              Mod Source
            </button>
            <button
              onClick={() => setActiveTab('architecture')}
              className={`whitespace-nowrap shrink-0 border-b-2 py-1 transition-colors ${
                activeTab === 'architecture'
                  ? 'border-slate-100 text-slate-50'
                  : 'border-transparent hover:text-slate-200'
              }`}
            >
              Architecture
            </button>
          </nav>

          <div className="flex items-center shrink-0">
            <a
              href="/api/download-mod"
              download="procedural-dark-worlds-forge-1.21.1.zip"
              className="inline-flex items-center gap-2 rounded-md bg-slate-100 px-4 py-2 text-xs font-semibold text-slate-950 transition-colors hover:bg-white whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              Download Mod (.zip)
            </a>
          </div>
        </div>
      </header>

      <main>
        {activeTab === 'simulator' && <WorldSimulator />}
        {activeTab === 'source' && <ModCodeBrowser />}
        {activeTab === 'architecture' && <ArchitectureOverview />}
      </main>
    </div>
  );
}
