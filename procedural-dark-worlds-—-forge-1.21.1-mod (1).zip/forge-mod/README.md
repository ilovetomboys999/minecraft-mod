# Procedural Dark Worlds (Minecraft Forge 1.21.1)

A modular, data-driven Minecraft Forge 1.21.1 mod inspired by Deltarune's Dark Fountains and RPG presentation.

## Requirements
- **Minecraft:** 1.21.1
- **Minecraft Forge:** 52.0.16+
- **Java:** 21
- **Gradle:** 8.8+

## Quick Start
1. Ensure Java 21 is active (`java -version`).
2. Run `./gradlew runClient` (or `gradle runClient` if using a system Gradle installation) to launch Minecraft Forge 1.21.1.
3. Build a distributable mod JAR with `./gradlew build` (output in `build/libs/`).

## Core Systems
- **Dark Fountain & Tag Activation (`darkworld:pointed_items`)**: Hold any tagged pointed weapon/tool and press `Z` (rebindable in Controls) while looking at a block inside an enclosed room.
- **3D Flood Fill Enclosed-Space Detector**: Non-destructively validates volume, bounding box, openings/leaks, and inventory containers with configurable safety caps (`config/darkworld-common.toml`).
- **Tag-First Material Analyzer & Exception Registry**: Classifies room blocks across 18 categories using datapack overrides (`data/*/darkworld/exceptions/*.json`), `darkworld:materials/*` tags, vanilla/Forge 1.21.1 tags, and block properties.
- **Up to 4 Coherent Biomes & Finite Worlds**: Selects 1–4 biomes proportional to material diversity (`data/*/darkworld/biomes/*.json`) and generates deterministic domain-warped Simplex terrain in isolated `Small (512)`, `Medium (1024)`, `Large (2048)`, or `Huge (4096)` instances inside `darkworld:dark_world`.
- **Per-Instance Hue Identity**: Dynamically tints Dark World turf, foliage, crystals, particles, fountain plumes, and void fog via `RegisterColorHandlersEvent` and `ViewportEvent.ComputeFogColor`.
- **Inventory-Born Darkners**: Inspects chests, barrels, furnaces, shulkers, and hoppers inside the room to populate the Dark World with named RPG Darkners tied to their source items and chest coordinates.
