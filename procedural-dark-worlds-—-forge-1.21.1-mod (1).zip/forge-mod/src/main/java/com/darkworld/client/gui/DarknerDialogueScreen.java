package com.darkworld.client.gui;

import com.darkworld.darkner.DarknerArchetype;
import com.darkworld.network.OpenDarknerDialoguePacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Deltarune-inspired RPG dialogue box for interacting with inventory-born Darkners.
 */
public class DarknerDialogueScreen extends Screen {
    private final OpenDarknerDialoguePacket data;

    public DarknerDialogueScreen(OpenDarknerDialoguePacket data) {
        super(Component.literal(data.name));
        this.data = data;
    }

    @Override
    protected void init() {
        int boxW = Math.min(380, this.width - 32);
        int boxH = 112;
        int left = (this.width - boxW) / 2;
        int top = this.height - boxH - 24;

        this.addRenderableWidget(Button.builder(Component.literal("Farewell"), btn -> this.onClose())
                .bounds(left + boxW - 92, top + boxH - 28, 76, 18)
                .build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int boxW = Math.min(380, this.width - 32);
        int boxH = 112;
        int left = (this.width - boxW) / 2;
        int top = this.height - boxH - 24;
        int accent = 0xFF000000 | data.accentRgb;

        graphics.fill(left, top, left + boxW, top + boxH, 0xF406070B);
        graphics.renderOutline(left, top, boxW, boxH, 0xFFFFFFFF);
        graphics.renderOutline(left + 2, top + 2, boxW - 4, boxH - 4, accent);

        DarknerArchetype archetype = DarknerArchetype.byId(data.archetypeId);
        graphics.drawString(this.font, "* " + data.name + "  [" + archetype.getRoleTitle() + "]", left + 14, top + 14, accent, false);
        graphics.drawString(this.font, "* \"The Dark Fountain reshaped us when light faded.\"", left + 14, top + 34, 0xFFFFFFFF, false);
        graphics.drawString(this.font, "* Origin: " + data.sourceItemId, left + 14, top + 52, 0xFFB8C2D9, false);
        graphics.drawString(this.font, "* Container: (" + data.originPos.toShortString() + ")", left + 14, top + 66, 0xFF8C96AD, false);

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
