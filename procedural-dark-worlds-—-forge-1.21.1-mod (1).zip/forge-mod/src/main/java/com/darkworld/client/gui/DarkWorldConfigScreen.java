package com.darkworld.client.gui;

import com.darkworld.analysis.MaterialCategory;
import com.darkworld.darkner.InventoryAnalyzer;
import com.darkworld.network.ConfirmFountainActivationPacket;
import com.darkworld.network.ModNetwork;
import com.darkworld.network.OpenDarkWorldConfigPacket;
import com.darkworld.world.DarkWorldHue;
import com.darkworld.world.DarkWorldSize;
import com.darkworld.world.biome.DarkBiomeRegistry;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.network.PacketDistributor;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Deltarune-inspired pre-generation Dark World configuration menu.
 * Allows adjusting world name, finite size, hue angle, and reviewing room composition & Darkners.
 */
public class DarkWorldConfigScreen extends Screen {
    private final OpenDarkWorldConfigPacket data;
    private EditBox nameBox;
    private DarkWorldSize selectedSize = DarkWorldSize.LARGE;
    private float selectedHue;
    private Button sizeButton;
    private Button hueShiftButton;

    public DarkWorldConfigScreen(OpenDarkWorldConfigPacket data) {
        super(Component.translatable("screen.darkworld.config.title"));
        this.data = data;
        this.selectedHue = data.proposedHue.baseHue();
    }

    @Override
    protected void init() {
        int panelW = Math.min(420, this.width - 32);
        int panelH = Math.min(268, this.height - 28);
        int left = (this.width - panelW) / 2;
        int top = (this.height - panelH) / 2;

        this.nameBox = new EditBox(this.font, left + 16, top + 34, panelW - 32, 20, Component.literal("World Name"));
        this.nameBox.setMaxLength(40);
        this.nameBox.setValue("Fountain Realm");
        this.addRenderableWidget(this.nameBox);

        this.sizeButton = Button.builder(
                Component.literal("Size: " + selectedSize.getDisplayName().getString() + " (" + selectedSize.getSideLength() + "x" + selectedSize.getSideLength() + ")"),
                btn -> {
                    DarkWorldSize[] sizes = DarkWorldSize.values();
                    selectedSize = sizes[(selectedSize.ordinal() + 1) % sizes.length];
                    btn.setMessage(Component.literal("Size: " + selectedSize.getDisplayName().getString() + " (" + selectedSize.getSideLength() + "x" + selectedSize.getSideLength() + ")"));
                }
        ).bounds(left + 16, top + 62, (panelW - 40) / 2, 20).build();
        this.addRenderableWidget(this.sizeButton);

        this.hueShiftButton = Button.builder(
                Component.literal("Hue: " + Math.round(selectedHue) + " deg"),
                btn -> {
                    selectedHue = DarkWorldHue.normalizeHue(selectedHue + 30.0F);
                    btn.setMessage(Component.literal("Hue: " + Math.round(selectedHue) + " deg"));
                }
        ).bounds(left + 24 + (panelW - 40) / 2, top + 62, (panelW - 40) / 2, 20).build();
        this.addRenderableWidget(this.hueShiftButton);

        this.addRenderableWidget(Button.builder(
                Component.translatable("screen.darkworld.config.confirm"),
                btn -> confirmAndActivate()
        ).bounds(left + 16, top + panelH - 30, (panelW - 40) / 2, 20).build());

        this.addRenderableWidget(Button.builder(
                Component.translatable("screen.darkworld.config.cancel"),
                btn -> this.onClose()
        ).bounds(left + 24 + (panelW - 40) / 2, top + panelH - 30, (panelW - 40) / 2, 20).build());
    }

    private void confirmAndActivate() {
        DarkWorldHue finalHue = new DarkWorldHue(
                selectedHue,
                data.proposedHue.saturation(),
                data.proposedHue.brightness(),
                DarkWorldHue.normalizeHue(selectedHue + 48.0F)
        );
        ModNetwork.CHANNEL.send(
                new ConfirmFountainActivationPacket(
                        data.fountainPos,
                        nameBox.getValue(),
                        selectedSize,
                        data.proposedSeed,
                        finalHue,
                        data.biomes
                ),
                PacketDistributor.SERVER.noArg()
        );
        this.onClose();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);

        int panelW = Math.min(420, this.width - 32);
        int panelH = Math.min(268, this.height - 28);
        int left = (this.width - panelW) / 2;
        int top = (this.height - panelH) / 2;

        int accentRgb = DarkWorldHue.hsvToRgb(selectedHue, data.proposedHue.saturation(), Math.min(0.95F, data.proposedHue.brightness() + 0.15F));
        int borderColor = 0xFF000000 | accentRgb;

        // Crisp Deltarune-inspired dark frame with hue-accented double border
        graphics.fill(left, top, left + panelW, top + panelH, 0xF0080A10);
        graphics.renderOutline(left, top, panelW, panelH, borderColor);
        graphics.renderOutline(left + 3, top + 3, panelW - 6, panelH - 6, 0xFFFFFFFF);

        graphics.drawString(this.font, this.title, left + 16, top + 14, 0xFFFFFFFF, false);
        graphics.fill(left + panelW - 36, top + 12, left + panelW - 16, top + 24, borderColor);

        int y = top + 92;
        graphics.drawString(this.font,
                String.format("Enclosed Volume: %d blocks  |  Openings: %d  |  Item Types: %d",
                        data.interiorVolume, data.detectedOpenings, data.uniqueItemTypes),
                left + 16, y, 0xFFB8C0D4, false);
        y += 16;

        // Top material ratios
        graphics.drawString(this.font, "Detected Materials:", left + 16, y, borderColor, false);
        y += 12;
        List<Map.Entry<MaterialCategory, Double>> topMats = data.materials.entrySet().stream()
                .sorted(Map.Entry.<MaterialCategory, Double>comparingByValue().reversed())
                .limit(4)
                .toList();
        StringBuilder matLine = new StringBuilder();
        for (int i = 0; i < topMats.size(); i++) {
            var e = topMats.get(i);
            if (i > 0) matLine.append("  |  ");
            matLine.append(e.getKey().getId().toUpperCase()).append(" ").append(Math.round(e.getValue() * 100)).append("%");
        }
        graphics.drawString(this.font, matLine.toString(), left + 16, y, 0xFFE6EAF5, false);
        y += 18;

        // Selected biomes (max 4)
        graphics.drawString(this.font, "Generated Biomes (" + data.biomes.size() + "/4):", left + 16, y, borderColor, false);
        y += 12;
        for (DarkBiomeRegistry.SelectedBiome sb : data.biomes) {
            String biomeName = DarkBiomeRegistry.INSTANCE.getTheme(sb.biomeId()).displayName();
            graphics.drawString(this.font, String.format(" - %s (%d%%)", biomeName, Math.round(sb.weight() * 100)),
                    left + 16, y, 0xFFDCE3F2, false);
            y += 11;
        }

        y += 6;
        int totalDarkners = data.darknerBlueprints.stream().mapToInt(InventoryAnalyzer.DarknerBlueprint::count).sum();
        graphics.drawString(this.font, "Manifested Darkners: " + totalDarkners + " inhabitants", left + 16, y, borderColor, false);

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
