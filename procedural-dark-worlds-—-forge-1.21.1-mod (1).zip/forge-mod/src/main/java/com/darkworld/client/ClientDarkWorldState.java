package com.darkworld.client;

import com.darkworld.network.SyncDarkWorldStatePacket;
import com.darkworld.world.DarkWorldHue;
import com.darkworld.world.DarkWorldSize;
import net.minecraft.client.Minecraft;

public class ClientDarkWorldState {
    private static boolean active = false;
    private static String instanceId = "";
    private static String worldName = "";
    private static DarkWorldSize size = DarkWorldSize.LARGE;
    private static int centerX = 0;
    private static int centerZ = 0;
    private static DarkWorldHue hue = new DarkWorldHue(265.0F, 0.72F, 0.62F, 305.0F);

    public static void update(SyncDarkWorldStatePacket packet) {
        active = packet.active;
        instanceId = packet.instanceId;
        worldName = packet.worldName;
        size = packet.size;
        centerX = packet.centerX;
        centerZ = packet.centerZ;
        hue = packet.hue;

        Minecraft mc = Minecraft.getInstance();
        if (mc.levelRenderer != null) {
            mc.levelRenderer.allChanged();
        }
    }

    public static boolean isActive() { return active; }
    public static String getInstanceId() { return instanceId; }
    public static String getWorldName() { return worldName; }
    public static DarkWorldSize getSize() { return size; }
    public static int getCenterX() { return centerX; }
    public static int getCenterZ() { return centerZ; }
    public static DarkWorldHue getHue() { return hue; }

    public static double distanceToEdge(double x, double z) {
        int half = size.getHalfSize();
        double dx = Math.min(x - (centerX - half), (centerX + half) - x);
        double dz = Math.min(z - (centerZ - half), (centerZ + half) - z);
        return Math.min(dx, dz);
    }
}
