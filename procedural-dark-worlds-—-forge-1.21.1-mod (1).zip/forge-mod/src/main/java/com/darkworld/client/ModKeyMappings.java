package com.darkworld.client;

import com.darkworld.DarkWorldMod;
import com.darkworld.network.ModNetwork;
import com.darkworld.network.RequestFountainScanPacket;
import com.darkworld.registry.ModTags;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = DarkWorldMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModKeyMappings {
    public static final KeyMapping ACTIVATE_FOUNTAIN_KEY = new KeyMapping(
            "key.darkworld.activate_fountain",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_Z,
            "key.categories.darkworld"
    );

    @SubscribeEvent
    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(ACTIVATE_FOUNTAIN_KEY);
    }

    @Mod.EventBusSubscriber(modid = DarkWorldMod.MOD_ID, value = Dist.CLIENT)
    public static class ClientKeyTick {
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null || mc.screen != null) return;

            while (ACTIVATE_FOUNTAIN_KEY.consumeClick()) {
                if (!mc.player.getMainHandItem().is(ModTags.Items.POINTED_ITEMS)) {
                    continue;
                }
                HitResult hit = mc.hitResult;
                if (hit != null && hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult blockHit) {
                    ModNetwork.CHANNEL.send(
                            new RequestFountainScanPacket(blockHit.getBlockPos()),
                            PacketDistributor.SERVER.noArg()
                    );
                }
            }
        }
    }
}
