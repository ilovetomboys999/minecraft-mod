package com.darkworld.client.particle;

import com.darkworld.client.ClientDarkWorldState;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

public class DarkPlumeParticle extends TextureSheetParticle {
    private final SpriteSet sprites;

    protected DarkPlumeParticle(ClientLevel level, double x, double y, double z,
                                double xd, double yd, double zd, SpriteSet sprites) {
        super(level, x, y, z, xd, yd, zd);
        this.sprites = sprites;
        this.lifetime = 35 + level.random.nextInt(25);
        this.quadSize = 0.18F + level.random.nextFloat() * 0.14F;
        this.gravity = -0.02F;

        int rgb = ClientDarkWorldState.isActive()
                ? ClientDarkWorldState.getHue().getSecondaryRgb()
                : 0x7A42F5;
        this.rCol = ((rgb >> 16) & 0xFF) / 255.0F;
        this.gCol = ((rgb >> 8) & 0xFF) / 255.0F;
        this.bCol = (rgb & 0xFF) / 255.0F;
        this.alpha = 0.85F;
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        this.setSpriteFromAge(sprites);
        this.alpha = Math.max(0.0F, 1.0F - ((float) this.age / (float) this.lifetime));
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xd, double yd, double zd) {
            return new DarkPlumeParticle(level, x, y, z, xd, yd, zd, sprites);
        }
    }
}
