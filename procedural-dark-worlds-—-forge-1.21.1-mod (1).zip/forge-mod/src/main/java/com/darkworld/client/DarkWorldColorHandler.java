package com.darkworld.client;

import com.darkworld.DarkWorldMod;
import com.darkworld.block.DarkFountainBlockEntity;
import com.darkworld.client.particle.DarkPlumeParticle;
import com.darkworld.registry.ModBlocks;
import com.darkworld.registry.ModEntities;
import com.darkworld.registry.ModParticles;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class DarkWorldColorHandler {

    @Mod.EventBusSubscriber(modid = DarkWorldMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBusClientEvents {
        @SubscribeEvent
        public static void onBlockColors(RegisterColorHandlersEvent.Block event) {
            event.register((state, level, pos, tintIndex) -> {
                if (pos != null && level != null && level.getBlockEntity(pos) instanceof DarkFountainBlockEntity be) {
                    return be.getHueRgb();
                }
                return ClientDarkWorldState.isActive() ? ClientDarkWorldState.getHue().getPrimaryRgb() : 0x7A42F5;
            }, ModBlocks.DARK_FOUNTAIN.get(), ModBlocks.DARK_PORTAL_BEAM.get());

            event.register((state, level, pos, tintIndex) -> {
                if (!ClientDarkWorldState.isActive()) return 0x3C6E71;
                float shift = pos != null ? ((pos.getX() + pos.getZ()) & 15) * 1.2F : 0.0F;
                return ClientDarkWorldState.getHue().getTurfRgb(shift);
            }, ModBlocks.DARK_TURF.get(), ModBlocks.DARK_SOIL.get());

            event.register((state, level, pos, tintIndex) -> {
                if (!ClientDarkWorldState.isActive()) return 0x7E42B8;
                float shift = pos != null ? ((pos.getX() - pos.getZ()) & 15) * 1.4F : 0.0F;
                return ClientDarkWorldState.getHue().getFoliageRgb(shift);
            }, ModBlocks.DARK_LEAVES.get());

            event.register((state, level, pos, tintIndex) -> {
                if (!ClientDarkWorldState.isActive()) return 0x4ED8E6;
                return ClientDarkWorldState.getHue().getCrystalRgb();
            }, ModBlocks.DARK_CRYSTAL.get(), ModBlocks.DARK_PILLAR.get());
        }

        @SubscribeEvent
        public static void onItemColors(RegisterColorHandlersEvent.Item event) {
            event.register((stack, tintIndex) -> ClientDarkWorldState.isActive()
                            ? ClientDarkWorldState.getHue().getTurfRgb(0.0F)
                            : 0x3C6E71,
                    ModBlocks.DARK_TURF.get());
            event.register((stack, tintIndex) -> ClientDarkWorldState.isActive()
                            ? ClientDarkWorldState.getHue().getFoliageRgb(0.0F)
                            : 0x7E42B8,
                    ModBlocks.DARK_LEAVES.get());
            event.register((stack, tintIndex) -> ClientDarkWorldState.isActive()
                            ? ClientDarkWorldState.getHue().getCrystalRgb()
                            : 0x4ED8E6,
                    ModBlocks.DARK_CRYSTAL.get());
        }

        @SubscribeEvent
        public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ModEntities.DARKNER.get(), DarknerRenderer::new);
        }

        @SubscribeEvent
        public static void onRegisterParticles(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(ModParticles.DARK_FOUNTAIN_PLUME.get(), DarkPlumeParticle.Provider::new);
            event.registerSpriteSet(ModParticles.DARK_SPARK.get(), DarkPlumeParticle.Provider::new);
        }
    }

    @Mod.EventBusSubscriber(modid = DarkWorldMod.MOD_ID, value = Dist.CLIENT)
    public static class ForgeBusClientEvents {
        @SubscribeEvent
        public static void onComputeFogColor(ViewportEvent.ComputeFogColor event) {
            if (!ClientDarkWorldState.isActive()) return;
            int fog = ClientDarkWorldState.getHue().getFogRgb();
            float r = ((fog >> 16) & 0xFF) / 255.0F;
            float g = ((fog >> 8) & 0xFF) / 255.0F;
            float b = (fog & 0xFF) / 255.0F;
            event.setRed(r);
            event.setGreen(g);
            event.setBlue(b);
        }

        @SubscribeEvent
        public static void onRenderFog(ViewportEvent.RenderFog event) {
            if (!ClientDarkWorldState.isActive()) return;
            var camPos = event.getCamera().getPosition();
            double edgeDist = ClientDarkWorldState.distanceToEdge(camPos.x, camPos.z);
            if (edgeDist < 28.0D) {
                float factor = (float) Math.max(0.15D, edgeDist / 28.0D);
                event.setNearPlaneDistance(2.0F * factor);
                event.setFarPlaneDistance(16.0F + 64.0F * factor);
                event.setCanceled(true);
            }
        }
    }
}
