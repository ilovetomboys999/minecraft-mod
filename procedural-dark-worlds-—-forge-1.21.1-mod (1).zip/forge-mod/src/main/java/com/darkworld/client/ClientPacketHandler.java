package com.darkworld.client;

import com.darkworld.client.gui.DarkWorldConfigScreen;
import com.darkworld.client.gui.DarknerDialogueScreen;
import com.darkworld.network.OpenDarkWorldConfigPacket;
import com.darkworld.network.OpenDarknerDialoguePacket;
import net.minecraft.client.Minecraft;

public class ClientPacketHandler {
    public static void openConfigScreen(OpenDarkWorldConfigPacket packet) {
        Minecraft.getInstance().setScreen(new DarkWorldConfigScreen(packet));
    }

    public static void openDarknerDialogue(OpenDarknerDialoguePacket packet) {
        Minecraft.getInstance().setScreen(new DarknerDialogueScreen(packet));
    }
}
