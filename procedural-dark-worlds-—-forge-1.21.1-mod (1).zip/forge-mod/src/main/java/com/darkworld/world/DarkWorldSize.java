package com.darkworld.world;

import net.minecraft.network.chat.Component;

public enum DarkWorldSize {
    SMALL("small", 512),
    MEDIUM("medium", 1024),
    LARGE("large", 2048),
    HUGE("huge", 4096);

    private final String id;
    private final int sideLength;

    DarkWorldSize(String id, int sideLength) {
        this.id = id;
        this.sideLength = sideLength;
    }

    public String getId() {
        return id;
    }

    public int getSideLength() {
        return sideLength;
    }

    public int getHalfSize() {
        return sideLength / 2;
    }

    public Component getDisplayName() {
        return Component.translatable("size.darkworld." + id);
    }

    public static DarkWorldSize byId(String id) {
        for (DarkWorldSize size : values()) {
            if (size.id.equalsIgnoreCase(id)) return size;
        }
        return LARGE;
    }
}
