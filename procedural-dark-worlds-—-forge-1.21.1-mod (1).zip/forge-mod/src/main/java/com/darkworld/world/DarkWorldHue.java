package com.darkworld.world;

import com.darkworld.analysis.MaterialCategory;
import net.minecraft.nbt.CompoundTag;

import java.util.Random;

/**
 * Persistent color identity for a Dark World instance.
 * Provides consistent, vibrant yet moody dark-world palettes without global texture replacement.
 */
public record DarkWorldHue(
        float baseHue,       // 0.0 - 360.0
        float saturation,    // 0.35 - 0.95
        float brightness,    // 0.35 - 0.85
        float secondaryHue   // 0.0 - 360.0
) {
    public static DarkWorldHue fromSeedAndMaterial(long seed, MaterialCategory dominant) {
        Random rng = new Random(seed ^ 0x5DEECE66DL);
        float anchorHue = switch (dominant) {
            case STONE, CONCRETE -> 265.0F;     // Deep Violet
            case WOOD, ORGANIC, GRASS -> 148.0F; // Emerald / Teal-Green
            case SAND -> 36.0F;                  // Amber / Gold
            case ICE, WATER -> 195.0F;           // Cyan / Deep Azure
            case NETHER -> 350.0F;               // Crimson
            case GLASS, CRYSTAL -> 295.0F;       // Magenta-Violet
            case METAL -> 212.0F;                // Steel Cobalt
            case END -> 278.0F;                  // Royal Indigo
            default -> rng.nextFloat() * 360.0F;
        };
        float jitter = (rng.nextFloat() - 0.5F) * 44.0F;
        float base = normalizeHue(anchorHue + jitter);
        float sat = 0.58F + rng.nextFloat() * 0.28F;
        float val = 0.52F + rng.nextFloat() * 0.24F;
        float secondaryOffset = (rng.nextBoolean() ? 1.0F : -1.0F) * (35.0F + rng.nextFloat() * 55.0F);
        float secondary = normalizeHue(base + secondaryOffset);
        return new DarkWorldHue(base, sat, val, secondary);
    }

    public int getPrimaryRgb() {
        return hsvToRgb(baseHue, saturation, brightness);
    }

    public int getSecondaryRgb() {
        return hsvToRgb(secondaryHue, Math.min(1.0F, saturation * 0.92F), Math.min(1.0F, brightness * 1.1F));
    }

    public int getTurfRgb(float biomeHueShift) {
        return hsvToRgb(normalizeHue(baseHue + biomeHueShift), saturation * 0.82F, brightness * 0.88F);
    }

    public int getFoliageRgb(float biomeHueShift) {
        return hsvToRgb(normalizeHue(secondaryHue + biomeHueShift), Math.min(1.0F, saturation * 0.95F), brightness * 0.98F);
    }

    public int getCrystalRgb() {
        return hsvToRgb(normalizeHue(secondaryHue + 18.0F), Math.min(1.0F, saturation + 0.1F), Math.min(1.0F, brightness + 0.22F));
    }

    public int getFogRgb() {
        return hsvToRgb(baseHue, saturation * 0.65F, Math.max(0.08F, brightness * 0.22F));
    }

    public CompoundTag toTag() {
        CompoundTag tag = new CompoundTag();
        tag.putFloat("BaseHue", baseHue);
        tag.putFloat("Saturation", saturation);
        tag.putFloat("Brightness", brightness);
        tag.putFloat("SecondaryHue", secondaryHue);
        return tag;
    }

    public static DarkWorldHue fromTag(CompoundTag tag) {
        return new DarkWorldHue(
                tag.getFloat("BaseHue"),
                tag.getFloat("Saturation"),
                tag.getFloat("Brightness"),
                tag.getFloat("SecondaryHue")
        );
    }

    public static float normalizeHue(float h) {
        float mod = h % 360.0F;
        return mod < 0 ? mod + 360.0F : mod;
    }

    public static int hsvToRgb(float hueDeg, float sat, float val) {
        float h = normalizeHue(hueDeg) / 60.0F;
        int i = (int) Math.floor(h) % 6;
        float f = h - (float) Math.floor(h);
        float p = val * (1.0F - sat);
        float q = val * (1.0F - f * sat);
        float t = val * (1.0F - (1.0F - f) * sat);
        float r, g, b;
        switch (i) {
            case 0 -> { r = val; g = t; b = p; }
            case 1 -> { r = q; g = val; b = p; }
            case 2 -> { r = p; g = val; b = t; }
            case 3 -> { r = p; g = q; b = val; }
            case 4 -> { r = t; g = p; b = val; }
            default -> { r = val; g = p; b = q; }
        }
        int ri = Math.max(0, Math.min(255, Math.round(r * 255.0F)));
        int gi = Math.max(0, Math.min(255, Math.round(g * 255.0F)));
        int bi = Math.max(0, Math.min(255, Math.round(b * 255.0F)));
        return (ri << 16) | (gi << 8) | bi;
    }
}
