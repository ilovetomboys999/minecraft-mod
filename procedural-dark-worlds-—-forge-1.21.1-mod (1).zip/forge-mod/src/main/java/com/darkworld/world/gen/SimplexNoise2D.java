package com.darkworld.world.gen;

/**
 * Deterministic, seedable Simplex & Fractal Brownian Motion (fBm) noise
 * with domain warping and ridged multifractal terrain helpers.
 */
public final class SimplexNoise2D {
    private static final double F2 = 0.5 * (Math.sqrt(3.0) - 1.0);
    private static final double G2 = (3.0 - Math.sqrt(3.0)) / 6.0;
    private static final int[][] GRAD2 = {
            {1, 1}, {-1, 1}, {1, -1}, {-1, -1},
            {1, 0}, {-1, 0}, {0, 1}, {0, -1}
    };

    private SimplexNoise2D() {}

    public static double noise(long seed, double x, double z) {
        double s = (x + z) * F2;
        int i = fastFloor(x + s);
        int j = fastFloor(z + s);
        double t = (i + j) * G2;
        double x0 = x - (i - t);
        double z0 = z - (j - t);

        int i1, j1;
        if (x0 > z0) {
            i1 = 1; j1 = 0;
        } else {
            i1 = 0; j1 = 1;
        }

        double x1 = x0 - i1 + G2;
        double z1 = z0 - j1 + G2;
        double x2 = x0 - 1.0 + 2.0 * G2;
        double z2 = z0 - 1.0 + 2.0 * G2;

        double n0 = corner(seed, i, j, x0, z0);
        double n1 = corner(seed, i + i1, j + j1, x1, z1);
        double n2 = corner(seed, i + 1, j + 1, x2, z2);

        return 70.0 * (n0 + n1 + n2);
    }

    public static double fbm(long seed, double x, double z, int octaves, double lacunarity, double gain) {
        double sum = 0.0;
        double amp = 1.0;
        double freq = 1.0;
        double norm = 0.0;
        for (int o = 0; o < octaves; o++) {
            sum += amp * noise(seed + o * 1013L, x * freq, z * freq);
            norm += amp;
            amp *= gain;
            freq *= lacunarity;
        }
        return sum / norm;
    }

    public static double ridgedFbm(long seed, double x, double z, int octaves) {
        double sum = 0.0;
        double amp = 0.5;
        double freq = 1.0;
        double norm = 0.0;
        for (int o = 0; o < octaves; o++) {
            double v = 1.0 - Math.abs(noise(seed + o * 2027L, x * freq, z * freq));
            v = v * v;
            sum += v * amp;
            norm += amp;
            amp *= 0.5;
            freq *= 2.05;
        }
        return sum / norm;
    }

    public static double[] domainWarp(long seed, double x, double z, double scale, double strength) {
        double wx = fbm(seed ^ 0x9E3779B97F4A7C15L, x * scale, z * scale, 3, 2.0, 0.5);
        double wz = fbm(seed ^ 0xC2B2AE3D27D4EB4FL, x * scale + 52.3, z * scale + 19.7, 3, 2.0, 0.5);
        return new double[]{x + wx * strength, z + wz * strength};
    }

    private static double corner(long seed, int i, int j, double x, double z) {
        double t = 0.5 - x * x - z * z;
        if (t < 0) return 0.0;
        t *= t;
        int hash = hash2(seed, i, j) & 7;
        int[] g = GRAD2[hash];
        return t * t * (g[0] * x + g[1] * z);
    }

    private static int hash2(long seed, int i, int j) {
        long h = seed ^ (i * 374761393L) ^ (j * 668265263L);
        h = (h ^ (h >>> 13)) * 1274126177L;
        return (int) (h ^ (h >>> 16));
    }

    private static int fastFloor(double v) {
        int i = (int) v;
        return v < i ? i - 1 : i;
    }
}
