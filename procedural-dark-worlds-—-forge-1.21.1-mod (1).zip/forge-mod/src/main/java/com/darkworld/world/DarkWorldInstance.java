package com.darkworld.world;

import com.darkworld.analysis.MaterialCategory;
import com.darkworld.darkner.InventoryAnalyzer;
import com.darkworld.world.biome.DarkBiomeRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class DarkWorldInstance {
    private final String instanceId;
    private final String worldName;
    private final long seed;
    private final DarkWorldSize size;
    private final int centerX;
    private final int centerZ;
    private final ResourceLocation overworldDimension;
    private final BlockPos fountainOriginPos;
    private final DarkWorldHue hue;
    private final List<DarkBiomeRegistry.SelectedBiome> biomes;
    private final Map<MaterialCategory, Double> materialComposition;
    private final List<InventoryAnalyzer.DarknerBlueprint> darknerBlueprints;
    private boolean darknersSpawned;

    public DarkWorldInstance(
            String instanceId,
            String worldName,
            long seed,
            DarkWorldSize size,
            int centerX,
            int centerZ,
            ResourceLocation overworldDimension,
            BlockPos fountainOriginPos,
            DarkWorldHue hue,
            List<DarkBiomeRegistry.SelectedBiome> biomes,
            Map<MaterialCategory, Double> materialComposition,
            List<InventoryAnalyzer.DarknerBlueprint> darknerBlueprints,
            boolean darknersSpawned
    ) {
        this.instanceId = instanceId;
        this.worldName = worldName;
        this.seed = seed;
        this.size = size;
        this.centerX = centerX;
        this.centerZ = centerZ;
        this.overworldDimension = overworldDimension;
        this.fountainOriginPos = fountainOriginPos;
        this.hue = hue;
        this.biomes = biomes;
        this.materialComposition = materialComposition;
        this.darknerBlueprints = darknerBlueprints;
        this.darknersSpawned = darknersSpawned;
    }

    public String getInstanceId() { return instanceId; }
    public String getWorldName() { return worldName; }
    public long getSeed() { return seed; }
    public DarkWorldSize getSize() { return size; }
    public int getCenterX() { return centerX; }
    public int getCenterZ() { return centerZ; }
    public ResourceLocation getOverworldDimension() { return overworldDimension; }
    public BlockPos getFountainOriginPos() { return fountainOriginPos; }
    public DarkWorldHue getHue() { return hue; }
    public List<DarkBiomeRegistry.SelectedBiome> getBiomes() { return biomes; }
    public Map<MaterialCategory, Double> getMaterialComposition() { return materialComposition; }
    public List<InventoryAnalyzer.DarknerBlueprint> getDarknerBlueprints() { return darknerBlueprints; }
    public boolean isDarknersSpawned() { return darknersSpawned; }
    public void setDarknersSpawned(boolean spawned) { this.darknersSpawned = spawned; }

    public int getMinX() { return centerX - size.getHalfSize(); }
    public int getMaxX() { return centerX + size.getHalfSize() - 1; }
    public int getMinZ() { return centerZ - size.getHalfSize(); }
    public int getMaxZ() { return centerZ + size.getHalfSize() - 1; }

    public boolean contains(double x, double z) {
        return x >= getMinX() && x <= getMaxX() + 1.0D && z >= getMinZ() && z <= getMaxZ() + 1.0D;
    }

    public boolean containsBlock(int x, int z) {
        return x >= getMinX() && x <= getMaxX() && z >= getMinZ() && z <= getMaxZ();
    }

    public double distanceToBoundary(double x, double z) {
        double dx = Math.min(x - getMinX(), (getMaxX() + 1.0D) - x);
        double dz = Math.min(z - getMinZ(), (getMaxZ() + 1.0D) - z);
        return Math.min(dx, dz);
    }

    public CompoundTag toTag() {
        CompoundTag tag = new CompoundTag();
        tag.putString("Id", instanceId);
        tag.putString("Name", worldName);
        tag.putLong("Seed", seed);
        tag.putString("Size", size.getId());
        tag.putInt("CenterX", centerX);
        tag.putInt("CenterZ", centerZ);
        tag.putString("OriginDim", overworldDimension.toString());
        tag.putLong("OriginPos", fountainOriginPos.asLong());
        tag.put("Hue", hue.toTag());
        tag.putBoolean("DarknersSpawned", darknersSpawned);

        ListTag biomeList = new ListTag();
        for (DarkBiomeRegistry.SelectedBiome b : biomes) {
            CompoundTag bt = new CompoundTag();
            bt.putString("Id", b.biomeId().toString());
            bt.putDouble("Weight", b.weight());
            biomeList.add(bt);
        }
        tag.put("Biomes", biomeList);

        CompoundTag matTag = new CompoundTag();
        for (Map.Entry<MaterialCategory, Double> e : materialComposition.entrySet()) {
            matTag.putDouble(e.getKey().getId(), e.getValue());
        }
        tag.put("Materials", matTag);

        ListTag darknerList = new ListTag();
        for (InventoryAnalyzer.DarknerBlueprint bp : darknerBlueprints) {
            darknerList.add(bp.toTag());
        }
        tag.put("Darkners", darknerList);

        return tag;
    }

    public static DarkWorldInstance fromTag(CompoundTag tag) {
        List<DarkBiomeRegistry.SelectedBiome> biomes = new ArrayList<>();
        ListTag biomeList = tag.getList("Biomes", Tag.TAG_COMPOUND);
        for (int i = 0; i < biomeList.size(); i++) {
            CompoundTag bt = biomeList.getCompound(i);
            biomes.add(new DarkBiomeRegistry.SelectedBiome(
                    ResourceLocation.parse(bt.getString("Id")),
                    bt.getDouble("Weight")
            ));
        }

        Map<MaterialCategory, Double> mats = new EnumMap<>(MaterialCategory.class);
        CompoundTag matTag = tag.getCompound("Materials");
        for (String key : matTag.getAllKeys()) {
            MaterialCategory cat = MaterialCategory.byId(key);
            if (cat != null) mats.put(cat, matTag.getDouble(key));
        }

        List<InventoryAnalyzer.DarknerBlueprint> darkners = new ArrayList<>();
        ListTag dList = tag.getList("Darkners", Tag.TAG_COMPOUND);
        for (int i = 0; i < dList.size(); i++) {
            darkners.add(InventoryAnalyzer.DarknerBlueprint.fromTag(dList.getCompound(i)));
        }

        return new DarkWorldInstance(
                tag.getString("Id"),
                tag.getString("Name"),
                tag.getLong("Seed"),
                DarkWorldSize.byId(tag.getString("Size")),
                tag.getInt("CenterX"),
                tag.getInt("CenterZ"),
                ResourceLocation.parse(tag.getString("OriginDim")),
                BlockPos.of(tag.getLong("OriginPos")),
                DarkWorldHue.fromTag(tag.getCompound("Hue")),
                biomes,
                mats,
                darkners,
                tag.getBoolean("DarknersSpawned")
        );
    }
}
