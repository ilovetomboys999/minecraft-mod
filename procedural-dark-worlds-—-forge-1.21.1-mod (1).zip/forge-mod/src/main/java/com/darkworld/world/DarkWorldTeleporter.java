package com.darkworld.world;

import com.darkworld.block.DarkFountainBlock;
import com.darkworld.block.DarkFountainBlockEntity;
import com.darkworld.darkner.DarknerEntity;
import com.darkworld.darkner.InventoryAnalyzer;
import com.darkworld.registry.ModBlocks;
import com.darkworld.registry.ModEntities;
import com.darkworld.registry.ModItems;
import com.darkworld.registry.ModSounds;
import com.darkworld.registry.ModWorldGen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Random;

/**
 * Handles player transitions between Overworld fountains and isolated Dark World instances,
 * building the arrival Fountain Plaza and spawning inventory-derived Darkner citizens.
 */
public class DarkWorldTeleporter {

    public static void enterDarkWorld(ServerPlayer player, DarkWorldInstance instance) {
        MinecraftServer server = player.serverLevel().getServer();
        ServerLevel darkLevel = server.getLevel(ModWorldGen.DARK_WORLD_DIMENSION);
        if (darkLevel == null) return;

        int cx = instance.getCenterX();
        int cz = instance.getCenterZ();
        int plazaY = 70;

        buildArrivalPlaza(darkLevel, cx, plazaY, cz, instance);
        spawnDarknersIfNeeded(darkLevel, instance, cx, plazaY + 1, cz, server);

        if (!player.getInventory().contains(new ItemStack(ModItems.FOUNTAIN_SEAL.get()))) {
            player.getInventory().add(new ItemStack(ModItems.FOUNTAIN_SEAL.get()));
        }

        player.teleportTo(darkLevel, cx + 3.5D, plazaY + 1.0D, cz + 0.5D, player.getYRot(), player.getXRot());
        darkLevel.playSound(null, cx, plazaY + 1, cz, ModSounds.DARK_WORLD_ENTER.get(), SoundSource.AMBIENT, 1.0F, 1.0F);
        DarkWorldBoundaryHandler.syncPlayerDarkWorld(player);
    }

    public static void returnToOrigin(ServerPlayer player) {
        MinecraftServer server = player.serverLevel().getServer();
        DarkWorldManagerSavedData data = DarkWorldManagerSavedData.get(server);
        DarkWorldInstance instance = data.findByBlockXZ(player.blockPosition().getX(), player.blockPosition().getZ());

        ResourceKey<Level> targetDim = instance != null
                ? ResourceKey.create(Registries.DIMENSION, instance.getOverworldDimension())
                : Level.OVERWORLD;
        ServerLevel targetLevel = server.getLevel(targetDim);
        if (targetLevel == null) targetLevel = server.getLevel(Level.OVERWORLD);
        if (targetLevel == null) return;

        BlockPos returnPos = instance != null ? instance.getFountainOriginPos().above() : targetLevel.getSharedSpawnPos();
        player.teleportTo(targetLevel, returnPos.getX() + 1.5D, returnPos.getY(), returnPos.getZ() + 0.5D, player.getYRot(), player.getXRot());
        DarkWorldBoundaryHandler.syncPlayerDarkWorld(player);
    }

    private static void buildArrivalPlaza(ServerLevel level, int cx, int y, int cz, DarkWorldInstance instance) {
        BlockState floor = ModBlocks.DARK_BRICK.get().defaultBlockState();
        BlockState trim = ModBlocks.DARK_PILLAR.get().defaultBlockState();

        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                if (dx * dx + dz * dz <= 38) {
                    level.setBlock(new BlockPos(cx + dx, y, cz + dz), floor, 3);
                    for (int clearY = 1; clearY <= 6; clearY++) {
                        level.removeBlock(new BlockPos(cx + dx, y + clearY, cz + dz), false);
                    }
                }
            }
        }

        // Corner pillars around plaza
        int[][] corners = {{-4, -4}, {4, -4}, {-4, 4}, {4, 4}};
        for (int[] c : corners) {
            for (int h = 1; h <= 4; h++) {
                level.setBlock(new BlockPos(cx + c[0], y + h, cz + c[1]), trim, 3);
            }
        }

        // Central Return Fountain
        BlockPos fountainPos = new BlockPos(cx, y + 1, cz);
        level.setBlock(fountainPos, ModBlocks.DARK_FOUNTAIN.get().defaultBlockState()
                .setValue(DarkFountainBlock.ACTIVE, true)
                .setValue(DarkFountainBlock.RETURN_ANCHOR, true), 3);
        if (level.getBlockEntity(fountainPos) instanceof DarkFountainBlockEntity be) {
            be.setInstanceId(instance.getInstanceId());
            be.setHueRgb(instance.getHue().getPrimaryRgb());
        }
        for (int h = 2; h <= 8; h++) {
            level.setBlock(fountainPos.above(h), ModBlocks.DARK_PORTAL_BEAM.get().defaultBlockState(), 3);
        }
    }

    private static void spawnDarknersIfNeeded(ServerLevel level, DarkWorldInstance instance, int cx, int y, int cz, MinecraftServer server) {
        if (instance.isDarknersSpawned()) return;

        Random rng = new Random(instance.getSeed() ^ 0xA5A5A5A5L);
        int worldTint = instance.getHue().getSecondaryRgb();

        for (InventoryAnalyzer.DarknerBlueprint bp : instance.getDarknerBlueprints()) {
            for (int i = 0; i < bp.count(); i++) {
                double angle = rng.nextDouble() * Math.PI * 2.0D;
                double radius = 6.5D + rng.nextDouble() * 14.0D;
                int sx = (int) Math.round(cx + Math.cos(angle) * radius);
                int sz = (int) Math.round(cz + Math.sin(angle) * radius);

                DarknerEntity darkner = ModEntities.DARKNER.get().create(level);
                if (darkner == null) continue;

                darkner.moveTo(sx + 0.5D, y + 2.0D, sz + 0.5D, rng.nextFloat() * 360.0F, 0.0F);
                darkner.configure(
                        bp.displayName(),
                        bp.archetype(),
                        bp.sourceItemId().toString(),
                        bp.sourceContainerPos(),
                        blendTint(bp.archetype().getDefaultAccentRgb(), worldTint),
                        instance.getInstanceId()
                );
                level.addFreshEntity(darkner);
            }
        }

        instance.setDarknersSpawned(true);
        DarkWorldManagerSavedData.get(server).setDirty();
    }

    private static int blendTint(int a, int b) {
        int r = (((a >> 16) & 0xFF) + ((b >> 16) & 0xFF)) / 2;
        int g = (((a >> 8) & 0xFF) + ((b >> 8) & 0xFF)) / 2;
        int bl = ((a & 0xFF) + (b & 0xFF)) / 2;
        return (r << 16) | (g << 8) | bl;
    }
}
