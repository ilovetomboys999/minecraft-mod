package com.darkworld.world;

import com.darkworld.DarkWorldMod;
import com.darkworld.network.ModNetwork;
import com.darkworld.network.SyncDarkWorldStatePacket;
import com.darkworld.registry.ModParticles;
import com.darkworld.registry.ModWorldGen;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/**
 * Enforces per-instance finite world boundaries inside darkworld:dark_world
 * and syncs active Dark World hue/biome metadata to clients.
 */
@Mod.EventBusSubscriber(modid = DarkWorldMod.MOD_ID)
public class DarkWorldBoundaryHandler {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (!player.level().dimension().equals(ModWorldGen.DARK_WORLD_DIMENSION)) return;

        ServerLevel level = player.serverLevel();
        DarkWorldManagerSavedData data = DarkWorldManagerSavedData.get(level.getServer());
        DarkWorldInstance instance = data.findByBlockXZ(player.blockPosition().getX(), player.blockPosition().getZ());
        if (instance == null) {
            instance = data.findNearestInstance(player.getX(), player.getZ());
            if (instance == null) return;
            // Clamp player back inside nearest valid instance
            teleportInsideBounds(player, instance);
            return;
        }

        double distToEdge = instance.distanceToBoundary(player.getX(), player.getZ());
        if (distToEdge < 10.0D && level.getGameTime() % 5 == 0) {
            level.sendParticles(
                    player,
                    ModParticles.DARK_SPARK.get(),
                    false,
                    player.getX() + (level.random.nextDouble() - 0.5) * 4.0,
                    player.getY() + 1.0 + level.random.nextDouble() * 2.0,
                    player.getZ() + (level.random.nextDouble() - 0.5) * 4.0,
                    4, 0.4, 0.8, 0.4, 0.02
            );
        }

        if (distToEdge < 1.5D) {
            double clampedX = Math.max(instance.getMinX() + 2.0D, Math.min(instance.getMaxX() - 1.0D, player.getX()));
            double clampedZ = Math.max(instance.getMinZ() + 2.0D, Math.min(instance.getMaxZ() - 1.0D, player.getZ()));
            Vec3 push = new Vec3(instance.getCenterX() - player.getX(), 0, instance.getCenterZ() - player.getZ()).normalize().scale(0.45);
            player.setDeltaMovement(push.x, player.getDeltaMovement().y, push.z);
            player.teleportTo(clampedX, player.getY(), clampedZ);
            player.displayClientMessage(Component.translatable("message.darkworld.boundary_reached"), true);
        }
    }

    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!level.dimension().equals(ModWorldGen.DARK_WORLD_DIMENSION)) return;
        DarkWorldManagerSavedData data = DarkWorldManagerSavedData.get(level.getServer());
        if (data.findByBlockXZ(event.getPos().getX(), event.getPos().getZ()) == null) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        syncPlayerDarkWorld(player);
    }

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        syncPlayerDarkWorld(player);
    }

    public static void syncPlayerDarkWorld(ServerPlayer player) {
        if (!player.level().dimension().equals(ModWorldGen.DARK_WORLD_DIMENSION)) {
            ModNetwork.CHANNEL.send(SyncDarkWorldStatePacket.clear(), PacketDistributor.PLAYER.with(player));
            return;
        }
        DarkWorldManagerSavedData data = DarkWorldManagerSavedData.get(player.serverLevel().getServer());
        DarkWorldInstance instance = data.findByBlockXZ(player.blockPosition().getX(), player.blockPosition().getZ());
        if (instance != null) {
            ModNetwork.CHANNEL.send(SyncDarkWorldStatePacket.fromInstance(instance), PacketDistributor.PLAYER.with(player));
        }
    }

    private static void teleportInsideBounds(Entity entity, DarkWorldInstance instance) {
        double clampedX = Math.max(instance.getMinX() + 4.0D, Math.min(instance.getMaxX() - 4.0D, entity.getX()));
        double clampedZ = Math.max(instance.getMinZ() + 4.0D, Math.min(instance.getMaxZ() - 4.0D, entity.getZ()));
        entity.teleportTo(clampedX, Math.max(72.0D, entity.getY()), clampedZ);
    }
}
