package com.darkworld.world.biome;

import com.darkworld.analysis.MaterialCategory;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Map;

public record DarkBiomeTheme(
        ResourceLocation id,
        String displayName,
        Map<MaterialCategory, Double> materialAffinities,
        float hueShift,
        int baseHeight,
        float heightAmplitude,
        float ridgeWeight,
        ResourceLocation surfaceBlock,
        ResourceLocation subsurfaceBlock,
        ResourceLocation deepBlock,
        ResourceLocation fluidBlock,
        float treeDensity,
        float crystalDensity,
        float structureDensity,
        boolean hasCaves
) {
    public BlockState resolveSurface() {
        return resolveBlock(surfaceBlock, Blocks.DEEPSLATE.defaultBlockState());
    }

    public BlockState resolveSubsurface() {
        return resolveBlock(subsurfaceBlock, Blocks.BLACKSTONE.defaultBlockState());
    }

    public BlockState resolveDeep() {
        return resolveBlock(deepBlock, Blocks.DEEPSLATE.defaultBlockState());
    }

    public BlockState resolveFluid() {
        return resolveBlock(fluidBlock, Blocks.WATER.defaultBlockState());
    }

    private static BlockState resolveBlock(ResourceLocation id, BlockState fallback) {
        Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
        return block != null && block != Blocks.AIR ? block.defaultBlockState() : fallback;
    }
}
