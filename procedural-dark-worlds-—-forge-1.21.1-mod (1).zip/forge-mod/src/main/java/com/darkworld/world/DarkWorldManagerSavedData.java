package com.darkworld.world;

import com.darkworld.config.DarkWorldConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Persists all created Dark World instances and allocates isolated non-overlapping
 * grid regions within the shared darkworld:dark_world dimension.
 */
public class DarkWorldManagerSavedData extends SavedData {
    private static final String DATA_NAME = "darkworld_instances";
    private static final Factory<DarkWorldManagerSavedData> FACTORY =
            new Factory<>(DarkWorldManagerSavedData::new, DarkWorldManagerSavedData::load);

    private final Map<String, DarkWorldInstance> instancesById = new LinkedHashMap<>();
    private int nextSlotIndex = 0;

    public static DarkWorldManagerSavedData get(MinecraftServer server) {
        ServerLevel overworld = server.getLevel(Level.OVERWORLD);
        if (overworld == null) {
            throw new IllegalStateException("Overworld ServerLevel not available");
        }
        return overworld.getDataStorage().computeIfAbsent(FACTORY, DATA_NAME);
    }

    public static DarkWorldManagerSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        DarkWorldManagerSavedData data = new DarkWorldManagerSavedData();
        data.nextSlotIndex = tag.getInt("NextSlot");
        ListTag list = tag.getList("Instances", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            DarkWorldInstance instance = DarkWorldInstance.fromTag(list.getCompound(i));
            data.instancesById.put(instance.getInstanceId(), instance);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putInt("NextSlot", nextSlotIndex);
        ListTag list = new ListTag();
        for (DarkWorldInstance instance : instancesById.values()) {
            list.add(instance.toTag());
        }
        tag.put("Instances", list);
        return tag;
    }

    public int[] allocateNextGridCenter() {
        int slot = nextSlotIndex++;
        int stride = DarkWorldConfig.INSTANCE_GRID_SPACING.get();
        // Spiral / grid layout on positive X/Z quadrant offset from origin
        int gridX = slot % 16;
        int gridZ = slot / 16;
        setDirty();
        return new int[]{gridX * stride, gridZ * stride};
    }

    public void registerInstance(DarkWorldInstance instance) {
        instancesById.put(instance.getInstanceId(), instance);
        setDirty();
    }

    public DarkWorldInstance getById(String id) {
        return instancesById.get(id);
    }

    public DarkWorldInstance findByBlockXZ(int x, int z) {
        for (DarkWorldInstance instance : instancesById.values()) {
            if (instance.containsBlock(x, z)) {
                return instance;
            }
        }
        return null;
    }

    public DarkWorldInstance findNearestInstance(double x, double z) {
        DarkWorldInstance best = null;
        double bestDistSq = Double.MAX_VALUE;
        for (DarkWorldInstance instance : instancesById.values()) {
            double dx = x - instance.getCenterX();
            double dz = z - instance.getCenterZ();
            double d = dx * dx + dz * dz;
            if (d < bestDistSq) {
                bestDistSq = d;
                best = instance;
            }
        }
        return best;
    }

    public boolean hasNearbyOverworldFountain(ResourceLocation dim, BlockPos pos, int minDistance) {
        for (DarkWorldInstance instance : instancesById.values()) {
            if (instance.getOverworldDimension().equals(dim)) {
                if (instance.getFountainOriginPos().closerThan(pos, minDistance)) {
                    return true;
                }
            }
        }
        return false;
    }

    public Collection<DarkWorldInstance> allInstances() {
        return instancesById.values();
    }
}
