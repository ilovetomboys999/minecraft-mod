package com.darkworld.world.biome;

import com.darkworld.DarkWorldMod;
import com.darkworld.analysis.MaterialCategory;
import com.darkworld.config.DarkWorldConfig;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Loads biome theme definitions from data/<namespace>/darkworld/biomes/*.json
 * and selects 1 to 4 coherent biomes proportional to detected room material diversity.
 */
public class DarkBiomeRegistry extends SimpleJsonResourceReloadListener {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final DarkBiomeRegistry INSTANCE = new DarkBiomeRegistry();

    public record SelectedBiome(ResourceLocation biomeId, double weight) {}

    private final Map<ResourceLocation, DarkBiomeTheme> themes = new LinkedHashMap<>();

    private DarkBiomeRegistry() {
        super(GSON, "darkworld/biomes");
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> objects, ResourceManager resourceManager, ProfilerFiller profiler) {
        themes.clear();
        for (Map.Entry<ResourceLocation, JsonElement> entry : objects.entrySet()) {
            try {
                JsonObject obj = entry.getValue().getAsJsonObject();
                Map<MaterialCategory, Double> affinities = new EnumMap<>(MaterialCategory.class);
                JsonObject affObj = obj.getAsJsonObject("material_affinities");
                for (String key : affObj.keySet()) {
                    MaterialCategory cat = MaterialCategory.byId(key);
                    if (cat != null) {
                        affinities.put(cat, affObj.get(key).getAsDouble());
                    }
                }
                DarkBiomeTheme theme = new DarkBiomeTheme(
                        entry.getKey(),
                        obj.get("display_name").getAsString(),
                        affinities,
                        obj.has("hue_shift") ? obj.get("hue_shift").getAsFloat() : 0.0F,
                        obj.has("base_height") ? obj.get("base_height").getAsInt() : 66,
                        obj.has("height_amplitude") ? obj.get("height_amplitude").getAsFloat() : 14.0F,
                        obj.has("ridge_weight") ? obj.get("ridge_weight").getAsFloat() : 0.25F,
                        ResourceLocation.parse(obj.get("surface_block").getAsString()),
                        ResourceLocation.parse(obj.get("subsurface_block").getAsString()),
                        ResourceLocation.parse(obj.get("deep_block").getAsString()),
                        obj.has("fluid_block") ? ResourceLocation.parse(obj.get("fluid_block").getAsString()) : ResourceLocation.withDefaultNamespace("water"),
                        obj.has("tree_density") ? obj.get("tree_density").getAsFloat() : 0.05F,
                        obj.has("crystal_density") ? obj.get("crystal_density").getAsFloat() : 0.04F,
                        obj.has("structure_density") ? obj.get("structure_density").getAsFloat() : 0.02F,
                        !obj.has("has_caves") || obj.get("has_caves").getAsBoolean()
                );
                themes.put(entry.getKey(), theme);
            } catch (Exception ex) {
                DarkWorldMod.LOGGER.error("Failed loading Dark Biome theme {}", entry.getKey(), ex);
            }
        }
        DarkWorldMod.LOGGER.info("Loaded {} Dark World biome themes.", themes.size());
    }

    public DarkBiomeTheme getTheme(ResourceLocation id) {
        DarkBiomeTheme theme = themes.get(id);
        if (theme != null) return theme;
        return themes.values().stream().findFirst().orElse(fallbackTheme());
    }

    public List<SelectedBiome> selectBiomes(Map<MaterialCategory, Double> composition) {
        int maxBiomes = DarkWorldConfig.MAX_BIOMES_PER_WORLD.get();

        // Count meaningful materials (>= 5% of room boundary) to bound biome count
        long significantMaterials = composition.values().stream().filter(w -> w >= 0.05D).count();
        int targetBiomeCount = (int) Math.max(1, Math.min(maxBiomes, significantMaterials));

        List<ScoredTheme> scored = new ArrayList<>();
        for (DarkBiomeTheme theme : themes.values()) {
            double score = 0.0;
            for (Map.Entry<MaterialCategory, Double> mat : composition.entrySet()) {
                double affinity = theme.materialAffinities().getOrDefault(mat.getKey(), 0.0);
                score += mat.getValue() * affinity;
            }
            if (score > 0.04D) {
                scored.add(new ScoredTheme(theme.id(), score));
            }
        }

        if (scored.isEmpty()) {
            return List.of(new SelectedBiome(ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "dark_highlands"), 1.0D));
        }

        scored.sort(Comparator.comparingDouble(ScoredTheme::score).reversed());
        int count = Math.min(targetBiomeCount, scored.size());
        List<ScoredTheme> top = scored.subList(0, count);
        double totalScore = top.stream().mapToDouble(ScoredTheme::score).sum();

        List<SelectedBiome> result = new ArrayList<>();
        for (ScoredTheme s : top) {
            result.add(new SelectedBiome(s.id(), s.score() / totalScore));
        }
        return result;
    }

    private static DarkBiomeTheme fallbackTheme() {
        return new DarkBiomeTheme(
                ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "dark_highlands"),
                "Dark Highlands",
                Map.of(MaterialCategory.STONE, 1.0D),
                0.0F, 72, 22.0F, 0.5F,
                ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "dark_stone"),
                ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "dark_stone"),
                ResourceLocation.withDefaultNamespace("deepslate"),
                ResourceLocation.withDefaultNamespace("water"),
                0.01F, 0.06F, 0.03F, true
        );
    }

    private record ScoredTheme(ResourceLocation id, double score) {}
}
