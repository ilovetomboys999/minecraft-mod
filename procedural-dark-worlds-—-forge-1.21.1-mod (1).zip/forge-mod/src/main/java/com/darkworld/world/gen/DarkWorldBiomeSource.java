package com.darkworld.world.gen;

import com.darkworld.config.DarkWorldConfig;
import com.darkworld.world.DarkWorldInstance;
import com.darkworld.world.biome.DarkBiomeRegistry;
import com.darkworld.world.biome.DarkBiomeTheme;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.Holder;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.biome.Climate;

import java.util.List;
import java.util.stream.Stream;

/**
 * Custom BiomeSource providing Minecraft's base biome holder while computing
 * contiguous, domain-warped Dark World biome blends for each finite instance.
 */
public class DarkWorldBiomeSource extends BiomeSource {
    public static final MapCodec<DarkWorldBiomeSource> CODEC = RecordCodecBuilder.mapCodec(instance ->
            instance.group(
                    Biome.CODEC.fieldOf("base_biome").forGetter(src -> src.baseBiome)
            ).apply(instance, DarkWorldBiomeSource::new)
    );

    private final Holder<Biome> baseBiome;

    public DarkWorldBiomeSource(Holder<Biome> baseBiome) {
        this.baseBiome = baseBiome;
    }

    @Override
    protected MapCodec<? extends BiomeSource> codec() {
        return CODEC;
    }

    @Override
    protected Stream<Holder<Biome>> collectPossibleBiomes() {
        return Stream.of(baseBiome);
    }

    @Override
    public Holder<Biome> getNoiseBiome(int quartX, int quartY, int quartZ, Climate.Sampler sampler) {
        return baseBiome;
    }

    public record BiomeSample(DarkBiomeTheme primary, DarkBiomeTheme secondary, double blendAlpha) {}

    public static BiomeSample sampleDarkBiome(DarkWorldInstance instance, int blockX, int blockZ) {
        List<DarkBiomeRegistry.SelectedBiome> selected = instance.getBiomes();
        if (selected.isEmpty()) {
            DarkBiomeTheme def = DarkBiomeRegistry.INSTANCE.getTheme(null);
            return new BiomeSample(def, def, 0.0D);
        }
        if (selected.size() == 1) {
            DarkBiomeTheme only = DarkBiomeRegistry.INSTANCE.getTheme(selected.get(0).biomeId());
            return new BiomeSample(only, only, 0.0D);
        }

        double scale = DarkWorldConfig.BIOME_NOISE_SCALE.get();
        double[] warped = SimplexNoise2D.domainWarp(instance.getSeed(), blockX, blockZ, scale * 1.4D, 56.0D);

        double bestScore = -Double.MAX_VALUE;
        double secondScore = -Double.MAX_VALUE;
        int bestIdx = 0;
        int secondIdx = 0;

        for (int i = 0; i < selected.size(); i++) {
            DarkBiomeRegistry.SelectedBiome sb = selected.get(i);
            long layerSeed = instance.getSeed() + (i + 1) * 918723L;
            double field = SimplexNoise2D.fbm(layerSeed, warped[0] * scale, warped[1] * scale, 3, 2.0, 0.5);
            // Weight bias ensures dominant source material covers proportionally larger coherent regions
            double weighted = (field * 0.5 + 0.5) + sb.weight() * 0.85D;
            if (weighted > bestScore) {
                secondScore = bestScore;
                secondIdx = bestIdx;
                bestScore = weighted;
                bestIdx = i;
            } else if (weighted > secondScore) {
                secondScore = weighted;
                secondIdx = i;
            }
        }

        DarkBiomeTheme primary = DarkBiomeRegistry.INSTANCE.getTheme(selected.get(bestIdx).biomeId());
        DarkBiomeTheme secondary = DarkBiomeRegistry.INSTANCE.getTheme(selected.get(secondIdx).biomeId());
        double diff = bestScore - secondScore;
        double blend = diff < 0.08D ? (0.5D - (diff / 0.08D) * 0.5D) : 0.0D;
        return new BiomeSample(primary, secondary, blend);
    }
}
