package com.darkworld.world.gen;

import com.darkworld.registry.ModBlocks;
import com.darkworld.world.DarkWorldInstance;
import com.darkworld.world.DarkWorldManagerSavedData;
import com.darkworld.world.biome.DarkBiomeTheme;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Finite, instance-aware procedural ChunkGenerator for darkworld:dark_world.
 * Generates multi-octave domain-warped terrain only within registered DarkWorldInstance bounds.
 */
public class DarkWorldChunkGenerator extends ChunkGenerator {
    public static final MapCodec<DarkWorldChunkGenerator> CODEC = RecordCodecBuilder.mapCodec(instance ->
            instance.group(
                    BiomeSource.CODEC.fieldOf("biome_source").forGetter(ChunkGenerator::getBiomeSource)
            ).apply(instance, DarkWorldChunkGenerator::new)
    );

    private static final int MIN_Y = -64;
    private static final int GEN_DEPTH = 384;
    private static final int SEA_LEVEL = 62;

    public DarkWorldChunkGenerator(BiomeSource biomeSource) {
        super(biomeSource);
    }

    @Override
    protected MapCodec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public void applyCarvers(WorldGenRegion level, long seed, RandomState random, BiomeManager biomeManager,
                             StructureManager structureManager, ChunkAccess chunk, GenerationStep.Carving step) {
        // Caves are integrated directly in fillFromNoise using 3D/layered noise for deterministic instance isolation
    }

    @Override
    public void buildSurface(WorldGenRegion level, StructureManager structureManager, RandomState random, ChunkAccess chunk) {
        DarkWorldInstance instance = resolveInstance(chunk.getPos().getMiddleBlockX(), chunk.getPos().getMiddleBlockZ());
        if (instance == null) return;

        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int lx = 0; lx < 16; lx++) {
            int wx = minX + lx;
            for (int lz = 0; lz < 16; lz++) {
                int wz = minZ + lz;
                if (!instance.containsBlock(wx, wz)) continue;

                DarkWorldBiomeSource.BiomeSample sample = DarkWorldBiomeSource.sampleDarkBiome(instance, wx, wz);
                DarkBiomeTheme theme = sample.primary();

                // Decorate surface features deterministically
                int topY = chunk.getHeight(Heightmap.Types.WORLD_SURFACE_WG, lx, lz);
                if (topY <= SEA_LEVEL + 1 || topY >= 240) continue;

                long colHash = hashColumn(instance.getSeed(), wx, wz);
                double roll = ((colHash & 0xFFFFL) / 65535.0D);

                // Keep central spawn plaza clear for the Return Fountain platform
                double distFromCenterSq = Math.pow(wx - instance.getCenterX(), 2) + Math.pow(wz - instance.getCenterZ(), 2);
                if (distFromCenterSq < 256.0D) continue;

                if (roll < theme.crystalDensity() * 0.25D) {
                    placeCrystalSpire(chunk, pos, lx, topY + 1, lz, (int) (3 + (colHash >> 16) % 5));
                } else if (roll < theme.crystalDensity() * 0.25D + theme.treeDensity() * 0.35D) {
                    placeDarkTree(chunk, pos, lx, topY + 1, lz, (int) (4 + (colHash >> 20) % 4));
                } else if (roll < theme.crystalDensity() * 0.25D + theme.treeDensity() * 0.35D + theme.structureDensity() * 0.08D) {
                    placeMonolithPillar(chunk, pos, lx, topY + 1, lz, (int) (4 + (colHash >> 24) % 6));
                }
            }
        }
    }

    @Override
    public void spawnOriginalMobs(WorldGenRegion level) {
        // Darkners are spawned deterministically on first instance entry via DarkWorldTeleporter
    }

    @Override
    public int getGenDepth() {
        return GEN_DEPTH;
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Blender blender, RandomState random,
                                                      StructureManager structureManager, ChunkAccess chunk) {
        int midX = chunk.getPos().getMiddleBlockX();
        int midZ = chunk.getPos().getMiddleBlockZ();
        DarkWorldInstance instance = resolveInstance(midX, midZ);
        if (instance == null) {
            return CompletableFuture.completedFuture(chunk);
        }

        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int lx = 0; lx < 16; lx++) {
            int wx = minX + lx;
            for (int lz = 0; lz < 16; lz++) {
                int wz = minZ + lz;
                if (!instance.containsBlock(wx, wz)) continue;

                DarkWorldBiomeSource.BiomeSample sample = DarkWorldBiomeSource.sampleDarkBiome(instance, wx, wz);
                int surfaceY = computeColumnHeight(instance, sample, wx, wz);

                BlockState surface = sample.primary().resolveSurface();
                BlockState subsurface = sample.primary().resolveSubsurface();
                BlockState deep = sample.primary().resolveDeep();
                BlockState fluid = sample.primary().resolveFluid();

                // Edge abyssal drop-off near finite instance bounds
                double edgeDist = instance.distanceToBoundary(wx, wz);
                if (edgeDist < 6.0D) {
                    surfaceY = (int) Math.max(MIN_Y + 4, surfaceY - (6.0D - edgeDist) * 4.5D);
                }

                chunk.setBlockState(pos.set(lx, MIN_Y, lz), Blocks.BEDROCK.defaultBlockState(), false);
                for (int y = MIN_Y + 1; y <= surfaceY; y++) {
                    BlockState toPlace;
                    if (y == surfaceY) {
                        toPlace = surface;
                    } else if (y >= surfaceY - 3) {
                        toPlace = subsurface;
                    } else {
                        toPlace = deep;
                    }

                    // Simple deterministic cave carving underground
                    if (sample.primary().hasCaves() && y > MIN_Y + 6 && y < surfaceY - 5) {
                        double caveNoise = Math.abs(SimplexNoise2D.noise(instance.getSeed() ^ 0xCAFEBABEL, wx * 0.045D + y * 0.02D, wz * 0.045D - y * 0.02D));
                        if (caveNoise < 0.075D) {
                            toPlace = Blocks.AIR.defaultBlockState();
                        }
                    }

                    chunk.setBlockState(pos.set(lx, y, lz), toPlace, false);
                }

                if (surfaceY < SEA_LEVEL) {
                    for (int y = surfaceY + 1; y <= SEA_LEVEL; y++) {
                        chunk.setBlockState(pos.set(lx, y, lz), fluid, false);
                    }
                }
            }
        }

        return CompletableFuture.completedFuture(chunk);
    }

    public static int computeColumnHeight(DarkWorldInstance instance, DarkWorldBiomeSource.BiomeSample sample, int wx, int wz) {
        long seed = instance.getSeed();
        double[] warp = SimplexNoise2D.domainWarp(seed, wx, wz, 0.008D, 14.0D);
        double baseNoise = SimplexNoise2D.fbm(seed + 71L, warp[0] * 0.007D, warp[1] * 0.007D, 4, 2.05, 0.5);
        double ridge = SimplexNoise2D.ridgedFbm(seed + 313L, warp[0] * 0.011D, warp[1] * 0.011D, 3);

        DarkBiomeTheme p = sample.primary();
        DarkBiomeTheme s = sample.secondary();
        double alpha = sample.blendAlpha();

        double baseH = p.baseHeight() * (1.0 - alpha) + s.baseHeight() * alpha;
        double amp = p.heightAmplitude() * (1.0 - alpha) + s.heightAmplitude() * alpha;
        double ridgeW = p.ridgeWeight() * (1.0 - alpha) + s.ridgeWeight() * alpha;

        double h = baseH + baseNoise * amp + (ridge - 0.35D) * amp * ridgeW;

        // Flatten spawn plaza cleanly around instance center
        double distFromCenter = Math.hypot(wx - instance.getCenterX(), wz - instance.getCenterZ());
        if (distFromCenter < 18.0D) {
            double t = Math.max(0.0D, Math.min(1.0D, (distFromCenter - 8.0D) / 10.0D));
            h = 70.0D * (1.0D - t) + h * t;
        }
        return (int) Math.max(MIN_Y + 8, Math.min(240, Math.round(h)));
    }

    @Override
    public int getSeaLevel() {
        return SEA_LEVEL;
    }

    @Override
    public int getMinY() {
        return MIN_Y;
    }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState random) {
        DarkWorldInstance instance = resolveInstance(x, z);
        if (instance == null || !instance.containsBlock(x, z)) return MIN_Y;
        DarkWorldBiomeSource.BiomeSample sample = DarkWorldBiomeSource.sampleDarkBiome(instance, x, z);
        return computeColumnHeight(instance, sample, x, z);
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState random) {
        int height = getBaseHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, level, random);
        BlockState[] states = new BlockState[Math.max(1, height - MIN_Y + 1)];
        for (int i = 0; i < states.length; i++) {
            states[i] = ModBlocks.DARK_STONE.get().defaultBlockState();
        }
        return new NoiseColumn(MIN_Y, states);
    }

    @Override
    public void addDebugScreenInfo(List<String> info, RandomState random, BlockPos pos) {
        DarkWorldInstance instance = resolveInstance(pos.getX(), pos.getZ());
        if (instance != null) {
            info.add("DarkWorld: " + instance.getWorldName() + " [" + instance.getSize().getId() + "]");
        } else {
            info.add("DarkWorld: Outer Void");
        }
    }

    private static DarkWorldInstance resolveInstance(int x, int z) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return null;
        return DarkWorldManagerSavedData.get(server).findByBlockXZ(x, z);
    }

    private static void placeCrystalSpire(ChunkAccess chunk, BlockPos.MutableBlockPos pos, int lx, int baseY, int lz, int height) {
        BlockState crystal = ModBlocks.DARK_CRYSTAL.get().defaultBlockState();
        for (int y = 0; y < height; y++) {
            chunk.setBlockState(pos.set(lx, baseY + y, lz), crystal, false);
        }
    }

    private static void placeDarkTree(ChunkAccess chunk, BlockPos.MutableBlockPos pos, int lx, int baseY, int lz, int height) {
        BlockState log = ModBlocks.DARK_LOG.get().defaultBlockState();
        BlockState leaves = ModBlocks.DARK_LEAVES.get().defaultBlockState();
        for (int y = 0; y < height; y++) {
            chunk.setBlockState(pos.set(lx, baseY + y, lz), log, false);
        }
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                int cx = lx + dx;
                int cz = lz + dz;
                if (cx >= 0 && cx < 16 && cz >= 0 && cz < 16) {
                    chunk.setBlockState(pos.set(cx, baseY + height - 1, cz), leaves, false);
                    if (Math.abs(dx) + Math.abs(dz) <= 1) {
                        chunk.setBlockState(pos.set(cx, baseY + height, cz), leaves, false);
                    }
                }
            }
        }
    }

    private static void placeMonolithPillar(ChunkAccess chunk, BlockPos.MutableBlockPos pos, int lx, int baseY, int lz, int height) {
        BlockState pillar = ModBlocks.DARK_PILLAR.get().defaultBlockState();
        BlockState brick = ModBlocks.DARK_BRICK.get().defaultBlockState();
        chunk.setBlockState(pos.set(lx, baseY, lz), brick, false);
        for (int y = 1; y < height; y++) {
            chunk.setBlockState(pos.set(lx, baseY + y, lz), pillar, false);
        }
    }

    private static long hashColumn(long seed, int x, int z) {
        long h = seed ^ (x * 73428767L) ^ (z * 912931L);
        h = (h ^ (h >>> 21)) * 0x9E3779B97F4A7C15L;
        return h ^ (h >>> 27);
    }
}
