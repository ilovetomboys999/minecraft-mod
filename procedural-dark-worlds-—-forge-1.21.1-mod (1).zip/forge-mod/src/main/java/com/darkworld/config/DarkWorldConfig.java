package com.darkworld.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class DarkWorldConfig {
    public static final ForgeConfigSpec SPEC;

    // Enclosed-Space Detection
    public static final ForgeConfigSpec.IntValue MAX_SCAN_DISTANCE;
    public static final ForgeConfigSpec.IntValue MAX_SCAN_VOLUME;
    public static final ForgeConfigSpec.IntValue MIN_ROOM_VOLUME;
    public static final ForgeConfigSpec.IntValue MAX_ROOM_VOLUME;
    public static final ForgeConfigSpec.IntValue PERMITTED_EXTERIOR_OPENINGS;
    public static final ForgeConfigSpec.IntValue MAX_OPENING_WIDTH;

    // World Instances & Generation
    public static final ForgeConfigSpec.IntValue INSTANCE_GRID_SPACING;
    public static final ForgeConfigSpec.IntValue MAX_BIOMES_PER_WORLD;
    public static final ForgeConfigSpec.DoubleValue BIOME_NOISE_SCALE;
    public static final ForgeConfigSpec.IntValue MAX_DARKNERS_PER_WORLD;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.push("enclosed_space_detection");
        MAX_SCAN_DISTANCE = builder
                .comment("Maximum Manhattan/Chebyshev search radius in blocks from the fountain origin.")
                .defineInRange("maxScanDistance", 48, 8, 128);
        MAX_SCAN_VOLUME = builder
                .comment("Hard safety limit on total air blocks visited during 3D flood fill.")
                .defineInRange("maxScanVolume", 32768, 512, 131072);
        MIN_ROOM_VOLUME = builder
                .comment("Minimum enclosed interior air blocks required to open a Dark Fountain.")
                .defineInRange("minRoomVolume", 27, 8, 4096);
        MAX_ROOM_VOLUME = builder
                .comment("Maximum interior air blocks permitted for a single Dark Fountain room.")
                .defineInRange("maxRoomVolume", 24576, 128, 131072);
        PERMITTED_EXTERIOR_OPENINGS = builder
                .comment("Maximum number of boundary openings (doors, windows, vents) that can leak toward exterior air before rejecting the room.")
                .defineInRange("permittedExteriorOpenings", 18, 0, 256);
        MAX_OPENING_WIDTH = builder
                .comment("Maximum contiguous opening width in blocks treated as a minor doorway/window rather than an open sky breach.")
                .defineInRange("maxOpeningWidth", 3, 1, 16);
        builder.pop();

        builder.push("dark_world_instances");
        INSTANCE_GRID_SPACING = builder
                .comment("Grid stride in blocks separating isolated Dark World instances within darkworld:dark_world dimension. Must exceed Huge size (4096).")
                .defineInRange("instanceGridSpacing", 8192, 5120, 32768);
        MAX_BIOMES_PER_WORLD = builder
                .comment("Maximum distinct Dark World biomes generated per instance.")
                .defineInRange("maxBiomesPerWorld", 4, 1, 4);
        BIOME_NOISE_SCALE = builder
                .comment("Scale factor for domain-warped biome region noise.")
                .defineInRange("biomeNoiseScale", 0.0045D, 0.0005D, 0.05D);
        MAX_DARKNERS_PER_WORLD = builder
                .comment("Maximum Darkner entities generated from room inventories per Dark World instance.")
                .defineInRange("maxDarknersPerWorld", 48, 4, 128);
        builder.pop();

        SPEC = builder.build();
    }
}
