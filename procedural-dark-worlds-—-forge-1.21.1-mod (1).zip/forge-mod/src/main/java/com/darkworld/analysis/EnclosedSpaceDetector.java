package com.darkworld.analysis;

import com.darkworld.config.DarkWorldConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/**
 * Non-destructive 3D BFS flood-fill enclosed-space detector.
 * Respects configurable safety limits for distance, volume, and permitted openings.
 */
public class EnclosedSpaceDetector {

    public static EnclosedSpaceResult analyze(Level level, BlockPos targetPos) {
        int maxDist = DarkWorldConfig.MAX_SCAN_DISTANCE.get();
        int maxVolume = DarkWorldConfig.MAX_SCAN_VOLUME.get();
        int minRoomVol = DarkWorldConfig.MIN_ROOM_VOLUME.get();
        int maxRoomVol = DarkWorldConfig.MAX_ROOM_VOLUME.get();
        int maxOpenings = DarkWorldConfig.PERMITTED_EXTERIOR_OPENINGS.get();
        int maxOpeningWidth = DarkWorldConfig.MAX_OPENING_WIDTH.get();

        BlockPos startAir = resolveStartAir(level, targetPos);
        if (startAir == null) {
            return EnclosedSpaceResult.failure(Component.translatable("message.darkworld.no_interior_space"));
        }

        Queue<BlockPos> queue = new ArrayDeque<>();
        Set<BlockPos> visitedAir = new HashSet<>();
        List<BlockPos> interiorPositions = new ArrayList<>();
        Map<BlockPos, BlockState> boundaryStates = new HashMap<>();
        List<BlockPos> inventoryPositions = new ArrayList<>();
        Set<BlockPos> seenInventories = new HashSet<>();
        List<BlockPos> leakCandidates = new ArrayList<>();

        int minX = startAir.getX(), minY = startAir.getY(), minZ = startAir.getZ();
        int maxX = minX, maxY = minY, maxZ = minZ;

        queue.add(startAir);
        visitedAir.add(startAir);

        while (!queue.isEmpty()) {
            BlockPos current = queue.poll();
            interiorPositions.add(current);

            if (current.getX() < minX) minX = current.getX();
            if (current.getY() < minY) minY = current.getY();
            if (current.getZ() < minZ) minZ = current.getZ();
            if (current.getX() > maxX) maxX = current.getX();
            if (current.getY() > maxY) maxY = current.getY();
            if (current.getZ() > maxZ) maxZ = current.getZ();

            if (visitedAir.size() > maxVolume || visitedAir.size() > maxRoomVol) {
                return EnclosedSpaceResult.failure(Component.translatable("message.darkworld.room_too_large"));
            }

            // Check if current air block touches the search horizon or open sky
            int dx = Math.abs(current.getX() - startAir.getX());
            int dy = Math.abs(current.getY() - startAir.getY());
            int dz = Math.abs(current.getZ() - startAir.getZ());
            boolean atHorizon = dx >= maxDist || dy >= maxDist || dz >= maxDist;
            boolean seesOpenSky = level.canSeeSky(current) && isRoofMissingAbove(level, current, maxDist);

            if (atHorizon || seesOpenSky) {
                leakCandidates.add(current);
                if (leakCandidates.size() > maxOpenings) {
                    return EnclosedSpaceResult.failure(Component.translatable("message.darkworld.not_enclosed"));
                }
                continue;
            }

            for (Direction dir : Direction.values()) {
                BlockPos neighbor = current.relative(dir);
                if (visitedAir.contains(neighbor)) continue;

                BlockState state = level.getBlockState(neighbor);
                if (isPassableInterior(level, neighbor, state)) {
                    // Also capture functional/inventory passables like chests/furnaces/slabs/doors
                    BlockEntity be = level.getBlockEntity(neighbor);
                    if (BlockExceptionRegistry.INSTANCE.isInventoryContainer(state, be) && seenInventories.add(neighbor)) {
                        inventoryPositions.add(neighbor);
                    } else if (!state.isAir()) {
                        boundaryStates.put(neighbor, state);
                    }
                    visitedAir.add(neighbor);
                    queue.add(neighbor);
                } else {
                    BlockEntity be = level.getBlockEntity(neighbor);
                    if (BlockExceptionRegistry.INSTANCE.isInventoryContainer(state, be) && seenInventories.add(neighbor)) {
                        inventoryPositions.add(neighbor);
                    }
                    boundaryStates.put(neighbor, state);
                }
            }
        }

        if (interiorPositions.size() < minRoomVol) {
            return EnclosedSpaceResult.failure(Component.translatable("message.darkworld.room_too_small"));
        }

        if (hasWideBreach(leakCandidates, maxOpeningWidth)) {
            return EnclosedSpaceResult.failure(Component.translatable("message.darkworld.opening_too_wide"));
        }

        Map<MaterialCategory, Double> composition = MaterialAnalyzer.analyzeComposition(boundaryStates.values());

        return new EnclosedSpaceResult(
                true,
                Component.empty(),
                new BlockPos(minX, minY, minZ),
                new BlockPos(maxX, maxY, maxZ),
                interiorPositions.size(),
                leakCandidates.size(),
                interiorPositions,
                boundaryStates,
                inventoryPositions,
                composition
        );
    }

    private static BlockPos resolveStartAir(Level level, BlockPos targetPos) {
        if (level.getBlockState(targetPos).isAir()) {
            return targetPos;
        }
        BlockPos above = targetPos.above();
        if (level.getBlockState(above).isAir()) {
            return above;
        }
        for (Direction dir : Direction.values()) {
            BlockPos adj = targetPos.relative(dir);
            if (level.getBlockState(adj).isAir()) {
                return adj;
            }
        }
        return null;
    }

    private static boolean isPassableInterior(Level level, BlockPos pos, BlockState state) {
        if (state.isAir()) return true;
        if (!state.getFluidState().isEmpty()) return false;
        // Thin/non-full blocks like torches, signs, carpets, plants allow air flood fill to pass around them
        return !state.isCollisionShapeFullBlock(level, pos) && !BlockExceptionRegistry.INSTANCE.isStructuralShapeVariant(state);
    }

    private static boolean isRoofMissingAbove(Level level, BlockPos pos, int maxDist) {
        for (int y = 1; y <= Math.min(24, maxDist); y++) {
            BlockPos check = pos.above(y);
            if (check.getY() >= level.getMaxBuildHeight()) return true;
            if (!level.getBlockState(check).isAir()) return false;
        }
        return true;
    }

    private static boolean hasWideBreach(List<BlockPos> leaks, int maxWidth) {
        if (leaks.isEmpty()) return false;
        if (leaks.size() > maxWidth * maxWidth * 2) return true;
        Set<BlockPos> remaining = new HashSet<>(leaks);
        while (!remaining.isEmpty()) {
            BlockPos seed = remaining.iterator().next();
            Queue<BlockPos> clusterQueue = new ArrayDeque<>();
            clusterQueue.add(seed);
            remaining.remove(seed);
            int clusterSize = 0;
            while (!clusterQueue.isEmpty()) {
                BlockPos cur = clusterQueue.poll();
                clusterSize++;
                if (clusterSize > maxWidth * maxWidth) return true;
                for (Direction dir : Direction.values()) {
                    BlockPos next = cur.relative(dir);
                    if (remaining.remove(next)) {
                        clusterQueue.add(next);
                    }
                }
            }
        }
        return false;
    }
}
