package com.darkworld.analysis;

import com.darkworld.DarkWorldMod;
import com.darkworld.registry.ModTags;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.Container;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SpawnerBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashMap;
import java.util.Map;

/**
 * Data-driven registry for block analysis exceptions, inventory markings,
 * excluded blocks, and custom material overrides.
 * Loaded from data/<namespace>/darkworld/exceptions/*.json
 */
public class BlockExceptionRegistry extends SimpleJsonResourceReloadListener {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final BlockExceptionRegistry INSTANCE = new BlockExceptionRegistry();

    public enum ExceptionBehavior {
        EXCLUDE,
        INVENTORY_CONTAINER,
        CUSTOM_CATEGORY,
        PRESERVE_NO_CONVERT
    }

    public record ExceptionRule(
            ExceptionBehavior behavior,
            MaterialCategory primaryCategory,
            MaterialCategory secondaryCategory,
            float secondaryWeight,
            ResourceLocation conversionBlockId
    ) {}

    private final Map<ResourceLocation, ExceptionRule> explicitRules = new HashMap<>();

    private BlockExceptionRegistry() {
        super(GSON, "darkworld/exceptions");
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> objects, ResourceManager resourceManager, ProfilerFiller profiler) {
        explicitRules.clear();
        for (Map.Entry<ResourceLocation, JsonElement> entry : objects.entrySet()) {
            try {
                JsonObject root = entry.getValue().getAsJsonObject();
                if (!root.has("entries") || !root.get("entries").isJsonArray()) {
                    continue;
                }
                for (JsonElement elem : root.getAsJsonArray("entries")) {
                    JsonObject obj = elem.getAsJsonObject();
                    ResourceLocation blockId = ResourceLocation.parse(obj.get("block").getAsString());
                    String behaviorStr = obj.has("behavior") ? obj.get("behavior").getAsString() : "CUSTOM_CATEGORY";
                    ExceptionBehavior behavior = ExceptionBehavior.valueOf(behaviorStr.toUpperCase());
                    MaterialCategory primary = obj.has("category") ? MaterialCategory.byId(obj.get("category").getAsString()) : null;
                    MaterialCategory secondary = obj.has("secondary_category") ? MaterialCategory.byId(obj.get("secondary_category").getAsString()) : null;
                    float secWeight = obj.has("secondary_weight") ? obj.get("secondary_weight").getAsFloat() : 0.35F;
                    ResourceLocation convertId = obj.has("convert_to") ? ResourceLocation.parse(obj.get("convert_to").getAsString()) : null;
                    explicitRules.put(blockId, new ExceptionRule(behavior, primary, secondary, secWeight, convertId));
                }
            } catch (Exception ex) {
                DarkWorldMod.LOGGER.error("Failed parsing Dark World block exception file {}", entry.getKey(), ex);
            }
        }
        DarkWorldMod.LOGGER.info("Loaded {} explicit Dark World block exception rules.", explicitRules.size());
    }

    public ExceptionRule getRule(BlockState state) {
        ResourceLocation id = BuiltInRegistries.BLOCK.getKey(state.getBlock());
        return explicitRules.get(id);
    }

    public boolean isExcludedFromTerrain(BlockState state) {
        ExceptionRule rule = getRule(state);
        if (rule != null && (rule.behavior() == ExceptionBehavior.EXCLUDE || rule.behavior() == ExceptionBehavior.INVENTORY_CONTAINER)) {
            return true;
        }
        if (state.is(ModTags.Blocks.ANALYSIS_EXCLUDED)) {
            return true;
        }
        return isInventoryContainer(state, null);
    }

    public boolean isInventoryContainer(BlockState state, BlockEntity be) {
        ExceptionRule rule = getRule(state);
        if (rule != null && rule.behavior() == ExceptionBehavior.INVENTORY_CONTAINER) {
            return true;
        }
        if (state.is(ModTags.Blocks.INVENTORY_CONTAINERS)) {
            return true;
        }
        Block block = state.getBlock();
        if (block instanceof ChestBlock || block instanceof ShulkerBoxBlock ||
            block instanceof AbstractFurnaceBlock || block instanceof HopperBlock ||
            block instanceof DispenserBlock) {
            return true;
        }
        return be instanceof Container;
    }

    public boolean isFunctionalOrPreserved(BlockState state) {
        ExceptionRule rule = getRule(state);
        if (rule != null && rule.behavior() == ExceptionBehavior.PRESERVE_NO_CONVERT) {
            return true;
        }
        Block block = state.getBlock();
        return block instanceof SpawnerBlock || block instanceof BedBlock ||
               state.is(BlockTags.BEDS) || state.is(BlockTags.DOORS) || state.is(BlockTags.TRAPDOORS);
    }

    public boolean isStructuralShapeVariant(BlockState state) {
        Block block = state.getBlock();
        return block instanceof SlabBlock || block instanceof StairBlock ||
               block instanceof DoorBlock || block instanceof TrapDoorBlock;
    }
}
