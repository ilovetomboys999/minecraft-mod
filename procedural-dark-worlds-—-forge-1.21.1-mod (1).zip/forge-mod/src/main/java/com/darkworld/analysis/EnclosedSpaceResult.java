package com.darkworld.analysis;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;
import java.util.Map;

public record EnclosedSpaceResult(
        boolean valid,
        Component failureReason,
        BlockPos minBound,
        BlockPos maxBound,
        int interiorVolume,
        int detectedOpenings,
        List<BlockPos> interiorPositions,
        Map<BlockPos, BlockState> boundaryStates,
        List<BlockPos> inventoryPositions,
        Map<MaterialCategory, Double> materialComposition
) {
    public static EnclosedSpaceResult failure(Component reason) {
        return new EnclosedSpaceResult(
                false, reason, BlockPos.ZERO, BlockPos.ZERO, 0, 0,
                List.of(), Map.of(), List.of(), Map.of()
        );
    }
}
