package com.darkworld.analysis;

import net.minecraft.network.chat.Component;

public enum MaterialCategory {
    STONE("stone", 0x7A7E8A),
    DIRT("dirt", 0x6F513B),
    GRASS("grass", 0x4EA35A),
    WOOD("wood", 0x8F673D),
    LEAVES("leaves", 0x3D8A4D),
    SAND("sand", 0xD2C186),
    GLASS("glass", 0x8CD6EB),
    METAL("metal", 0xA8B5C4),
    CRYSTAL("crystal", 0xB873F5),
    WATER("water", 0x2F7EE6),
    ICE("ice", 0x99D9FA),
    SNOW("snow", 0xEEF6FA),
    NETHER("nether", 0x8C2A2A),
    END("end", 0xDDD59E),
    ORGANIC("organic", 0x6BBF6B),
    DECORATIVE("decorative", 0xC46CA8),
    BRICKS("bricks", 0x96574C),
    CONCRETE("concrete", 0x626A7D);

    private final String id;
    private final int debugColor;

    MaterialCategory(String id, int debugColor) {
        this.id = id;
        this.debugColor = debugColor;
    }

    public String getId() {
        return id;
    }

    public int getDebugColor() {
        return debugColor;
    }

    public Component getDisplayName() {
        return Component.translatable("material.darkworld." + id);
    }

    public static MaterialCategory byId(String id) {
        for (MaterialCategory cat : values()) {
            if (cat.id.equalsIgnoreCase(id)) {
                return cat;
            }
        }
        return null;
    }
}
