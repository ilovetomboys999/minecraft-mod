package com.darkworld.analysis;

import com.darkworld.registry.ModTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.Tags;

import java.util.EnumMap;
import java.util.Map;

/**
 * Layered, tag-first material analyzer.
 * Priority:
 * 1. Explicit BlockExceptionRegistry JSON rules
 * 2. Mod / datapack darkworld:materials/* block tags
 * 3. Vanilla / Forge 1.21.1 block tags
 * 4. Physical block properties (MapColor, SoundType, FluidState)
 * 5. Safe fallback category
 */
public class MaterialAnalyzer {

    public record Classification(
            MaterialCategory primary,
            MaterialCategory secondary,
            float primaryWeight,
            float secondaryWeight
    ) {
        public static Classification single(MaterialCategory category) {
            return new Classification(category, null, 1.0F, 0.0F);
        }

        public static Classification dual(MaterialCategory primary, MaterialCategory secondary, float secondaryWeight) {
            float w = Math.max(0.05F, Math.min(0.49F, secondaryWeight));
            return new Classification(primary, secondary, 1.0F - w, w);
        }
    }

    public static Map<MaterialCategory, Double> analyzeComposition(Iterable<BlockState> states) {
        Map<MaterialCategory, Double> rawWeights = new EnumMap<>(MaterialCategory.class);
        double total = 0.0;

        for (BlockState state : states) {
            if (state.isAir()) continue;
            if (BlockExceptionRegistry.INSTANCE.isExcludedFromTerrain(state)) continue;

            Classification c = classify(state);
            if (c == null) continue;

            rawWeights.merge(c.primary(), (double) c.primaryWeight(), Double::sum);
            total += c.primaryWeight();
            if (c.secondary() != null && c.secondaryWeight() > 0.0F) {
                rawWeights.merge(c.secondary(), (double) c.secondaryWeight(), Double::sum);
                total += c.secondaryWeight();
            }
        }

        Map<MaterialCategory, Double> normalized = new EnumMap<>(MaterialCategory.class);
        if (total <= 0.0) {
            normalized.put(MaterialCategory.STONE, 1.0);
            return normalized;
        }
        for (Map.Entry<MaterialCategory, Double> entry : rawWeights.entrySet()) {
            normalized.put(entry.getKey(), entry.getValue() / total);
        }
        return normalized;
    }

    public static Classification classify(BlockState state) {
        // 1. Explicit JSON exception override
        BlockExceptionRegistry.ExceptionRule rule = BlockExceptionRegistry.INSTANCE.getRule(state);
        if (rule != null && rule.primaryCategory() != null) {
            if (rule.secondaryCategory() != null) {
                return Classification.dual(rule.primaryCategory(), rule.secondaryCategory(), rule.secondaryWeight());
            }
            return Classification.single(rule.primaryCategory());
        }

        // 2. Mod/datapack explicit material tags
        Classification modTagMatch = checkModTags(state);
        if (modTagMatch != null) return modTagMatch;

        // 3. Vanilla & Forge 1.21.1 block tags
        Classification vanillaTagMatch = checkVanillaAndForgeTags(state);
        if (vanillaTagMatch != null) return vanillaTagMatch;

        // 4. Physical block properties (fluids, sound, map color)
        if (!state.getFluidState().isEmpty()) {
            if (state.is(Blocks.LAVA)) {
                return Classification.single(MaterialCategory.NETHER);
            }
            return Classification.single(MaterialCategory.WATER);
        }

        SoundType sound = state.getSoundType();
        if (sound == SoundType.AMETHYST || sound == SoundType.AMETHYST_CLUSTER) {
            return Classification.single(MaterialCategory.CRYSTAL);
        }
        if (sound == SoundType.GLASS) {
            return Classification.single(MaterialCategory.GLASS);
        }
        if (sound == SoundType.METAL || sound == SoundType.NETHERITE_BLOCK || sound == SoundType.COPPER || sound == SoundType.ANVIL) {
            return Classification.single(MaterialCategory.METAL);
        }
        if (sound == SoundType.WOOD || sound == SoundType.CHERRY_WOOD || sound == SoundType.BAMBOO_WOOD) {
            return Classification.single(MaterialCategory.WOOD);
        }
        if (sound == SoundType.SAND) {
            return Classification.single(MaterialCategory.SAND);
        }
        if (sound == SoundType.SNOW) {
            return Classification.single(MaterialCategory.SNOW);
        }
        if (sound == SoundType.GRASS || sound == SoundType.MOSS) {
            return Classification.single(MaterialCategory.GRASS);
        }

        MapColor color = state.getMapColor(null, null);
        if (color == MapColor.NETHER) {
            return Classification.single(MaterialCategory.NETHER);
        }
        if (color == MapColor.ICE) {
            return Classification.single(MaterialCategory.ICE);
        }
        if (color == MapColor.COLOR_LIGHT_GREEN || color == MapColor.PLANT) {
            return Classification.single(MaterialCategory.ORGANIC);
        }

        // 5. Safe fallback
        if (state.is(BlockTags.MINEABLE_WITH_PICKAXE)) {
            return Classification.single(MaterialCategory.STONE);
        }
        if (state.is(BlockTags.MINEABLE_WITH_SHOVEL)) {
            return Classification.single(MaterialCategory.DIRT);
        }
        if (state.is(BlockTags.MINEABLE_WITH_AXE)) {
            return Classification.single(MaterialCategory.WOOD);
        }
        return Classification.single(MaterialCategory.DECORATIVE);
    }

    private static Classification checkModTags(BlockState state) {
        if (state.is(ModTags.Blocks.MAT_CRYSTAL)) return Classification.single(MaterialCategory.CRYSTAL);
        if (state.is(ModTags.Blocks.MAT_METAL)) return Classification.single(MaterialCategory.METAL);
        if (state.is(ModTags.Blocks.MAT_GLASS)) return Classification.single(MaterialCategory.GLASS);
        if (state.is(ModTags.Blocks.MAT_NETHER)) return Classification.single(MaterialCategory.NETHER);
        if (state.is(ModTags.Blocks.MAT_END)) return Classification.single(MaterialCategory.END);
        if (state.is(ModTags.Blocks.MAT_BRICKS)) return Classification.single(MaterialCategory.BRICKS);
        if (state.is(ModTags.Blocks.MAT_CONCRETE)) return Classification.single(MaterialCategory.CONCRETE);
        if (state.is(ModTags.Blocks.MAT_ICE)) return Classification.single(MaterialCategory.ICE);
        if (state.is(ModTags.Blocks.MAT_SNOW)) return Classification.single(MaterialCategory.SNOW);
        if (state.is(ModTags.Blocks.MAT_SAND)) return Classification.single(MaterialCategory.SAND);
        if (state.is(ModTags.Blocks.MAT_LEAVES)) return Classification.single(MaterialCategory.LEAVES);
        if (state.is(ModTags.Blocks.MAT_WOOD)) return Classification.single(MaterialCategory.WOOD);
        if (state.is(ModTags.Blocks.MAT_GRASS)) return Classification.single(MaterialCategory.GRASS);
        if (state.is(ModTags.Blocks.MAT_DIRT)) return Classification.single(MaterialCategory.DIRT);
        if (state.is(ModTags.Blocks.MAT_ORGANIC)) return Classification.single(MaterialCategory.ORGANIC);
        if (state.is(ModTags.Blocks.MAT_WATER)) return Classification.single(MaterialCategory.WATER);
        if (state.is(ModTags.Blocks.MAT_STONE)) return Classification.single(MaterialCategory.STONE);
        if (state.is(ModTags.Blocks.MAT_DECORATIVE)) return Classification.single(MaterialCategory.DECORATIVE);
        return null;
    }

    private static Classification checkVanillaAndForgeTags(BlockState state) {
        if (state.is(BlockTags.CRYSTAL_SOUND_BLOCKS) || state.is(Tags.Blocks.STORAGE_BLOCKS_AMETHYST)) {
            return Classification.single(MaterialCategory.CRYSTAL);
        }
        if (state.is(Tags.Blocks.GLASS_BLOCKS) || state.is(Tags.Blocks.GLASS_PANES)) {
            return Classification.single(MaterialCategory.GLASS);
        }
        if (state.is(BlockTags.BASE_STONE_NETHER) || state.is(BlockTags.NETHER_CARVER_REPLACEABLES) ||
            state.is(BlockTags.NYLIUM) || state.is(BlockTags.WART_BLOCKS)) {
            return Classification.single(MaterialCategory.NETHER);
        }
        if (state.is(Tags.Blocks.END_STONES) || state.is(Blocks.END_STONE_BRICKS) || state.is(Blocks.PURPUR_BLOCK)) {
            return Classification.single(MaterialCategory.END);
        }
        if (state.is(BlockTags.ICE)) {
            return Classification.single(MaterialCategory.ICE);
        }
        if (state.is(BlockTags.SNOW)) {
            return Classification.single(MaterialCategory.SNOW);
        }
        if (state.is(BlockTags.SAND) || state.is(Tags.Blocks.SANDSTONE_BLOCKS)) {
            return Classification.single(MaterialCategory.SAND);
        }
        if (state.is(BlockTags.LEAVES)) {
            return Classification.single(MaterialCategory.LEAVES);
        }
        if (state.is(BlockTags.LOGS) || state.is(BlockTags.PLANKS) || state.is(BlockTags.WOODEN_SLABS) ||
            state.is(BlockTags.WOODEN_STAIRS) || state.is(BlockTags.WOODEN_FENCES)) {
            return Classification.single(MaterialCategory.WOOD);
        }
        if (state.is(BlockTags.CROPS) || state.is(BlockTags.FLOWERS) || state.is(BlockTags.SAPLINGS) ||
            state.is(BlockTags.CORALS)) {
            return Classification.single(MaterialCategory.ORGANIC);
        }
        if (state.is(BlockTags.TERRACOTTA) || state.is(BlockTags.WOOL) || state.is(BlockTags.CANDLES) ||
            state.is(BlockTags.BANNERS)) {
            return Classification.single(MaterialCategory.DECORATIVE);
        }
        if (state.is(BlockTags.STONE_BRICKS) || state.is(Blocks.BRICKS) || state.is(Blocks.MUD_BRICKS) ||
            state.is(Blocks.DEEPSLATE_BRICKS)) {
            return Classification.dual(MaterialCategory.BRICKS, MaterialCategory.STONE, 0.25F);
        }
        if (state.is(Tags.Blocks.STORAGE_BLOCKS_IRON) || state.is(Tags.Blocks.STORAGE_BLOCKS_GOLD) ||
            state.is(Tags.Blocks.STORAGE_BLOCKS_COPPER) || state.is(Tags.Blocks.ORES)) {
            return Classification.dual(MaterialCategory.METAL, MaterialCategory.STONE, 0.30F);
        }
        if (state.is(BlockTags.DIRT)) {
            if (state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.MOSS_BLOCK) || state.is(Blocks.PODZOL)) {
                return Classification.dual(MaterialCategory.GRASS, MaterialCategory.DIRT, 0.35F);
            }
            return Classification.single(MaterialCategory.DIRT);
        }
        if (state.is(BlockTags.BASE_STONE_OVERWORLD) || state.is(Tags.Blocks.COBBLESTONES) ||
            state.is(Tags.Blocks.STONES)) {
            return Classification.single(MaterialCategory.STONE);
        }
        return null;
    }
}
