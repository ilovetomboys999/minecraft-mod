package com.darkworld.item;

import com.darkworld.registry.ModWorldGen;
import com.darkworld.world.DarkWorldTeleporter;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class FountainSealItem extends Item {
    public FountainSealItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            if (level.dimension().equals(ModWorldGen.DARK_WORLD_DIMENSION)) {
                DarkWorldTeleporter.returnToOrigin(serverPlayer);
            } else {
                serverPlayer.displayClientMessage(Component.translatable("message.darkworld.seal_only_in_dark_world"), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.darkworld.fountain_seal"));
    }
}
