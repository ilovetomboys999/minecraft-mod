package com.darkworld.network;

import com.darkworld.client.ClientPacketHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.network.CustomPayloadEvent;
import net.minecraftforge.fml.loading.FMLEnvironment;

public class OpenDarknerDialoguePacket {
    public final int entityId;
    public final String name;
    public final String archetypeId;
    public final String sourceItemId;
    public final BlockPos originPos;
    public final int accentRgb;

    public OpenDarknerDialoguePacket(int entityId, String name, String archetypeId, String sourceItemId, BlockPos originPos, int accentRgb) {
        this.entityId = entityId;
        this.name = name;
        this.archetypeId = archetypeId;
        this.sourceItemId = sourceItemId;
        this.originPos = originPos;
        this.accentRgb = accentRgb;
    }

    public OpenDarknerDialoguePacket(FriendlyByteBuf buf) {
        this.entityId = buf.readInt();
        this.name = buf.readUtf();
        this.archetypeId = buf.readUtf();
        this.sourceItemId = buf.readUtf();
        this.originPos = buf.readBlockPos();
        this.accentRgb = buf.readInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(entityId);
        buf.writeUtf(name);
        buf.writeUtf(archetypeId);
        buf.writeUtf(sourceItemId);
        buf.writeBlockPos(originPos);
        buf.writeInt(accentRgb);
    }

    public void handle(CustomPayloadEvent.Context context) {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientPacketHandler.openDarknerDialogue(this);
        }
    }
}
