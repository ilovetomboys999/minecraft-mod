package com.darkworld.network;

import com.darkworld.analysis.EnclosedSpaceDetector;
import com.darkworld.analysis.EnclosedSpaceResult;
import com.darkworld.analysis.MaterialCategory;
import com.darkworld.block.DarkFountainBlock;
import com.darkworld.darkner.InventoryAnalyzer;
import com.darkworld.registry.ModBlocks;
import com.darkworld.registry.ModTags;
import com.darkworld.registry.ModWorldGen;
import com.darkworld.world.DarkWorldHue;
import com.darkworld.world.DarkWorldManagerSavedData;
import com.darkworld.world.biome.DarkBiomeRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.network.CustomPayloadEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * C2S packet sent when the player presses Z while aiming at a block with a darkworld:pointed_items item.
 * All validation and enclosed-space analysis runs strictly server-side.
 */
public class RequestFountainScanPacket {
    private final BlockPos targetPos;

    public RequestFountainScanPacket(BlockPos targetPos) {
        this.targetPos = targetPos;
    }

    public RequestFountainScanPacket(FriendlyByteBuf buf) {
        this.targetPos = buf.readBlockPos();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBlockPos(targetPos);
    }

    public void handle(CustomPayloadEvent.Context context) {
        ServerPlayer player = context.getSender();
        if (player == null) return;

        ServerLevel level = player.serverLevel();
        ItemStack held = player.getMainHandItem();

        // 1. Tag validation
        if (held.isEmpty() || !held.is(ModTags.Items.POINTED_ITEMS)) {
            player.displayClientMessage(Component.translatable("message.darkworld.need_pointed_item"), true);
            return;
        }

        // 2. Dimension & reach validation
        if (level.dimension().equals(ModWorldGen.DARK_WORLD_DIMENSION)) {
            player.displayClientMessage(Component.translatable("message.darkworld.cannot_nest_fountain"), true);
            return;
        }
        if (player.blockPosition().distSqr(targetPos) > 64.0D) {
            player.displayClientMessage(Component.translatable("message.darkworld.too_far"), true);
            return;
        }

        // 3. Permission & placement validation
        if (!level.mayInteract(player, targetPos) || !player.mayBuild()) {
            player.displayClientMessage(Component.translatable("message.darkworld.no_permission"), true);
            return;
        }

        BlockPos fountainPos = level.getBlockState(targetPos).is(ModBlocks.DARK_FOUNTAIN.get())
                ? targetPos
                : targetPos.above();

        BlockState existing = level.getBlockState(fountainPos);
        if (existing.getBlock() instanceof DarkFountainBlock && existing.getValue(DarkFountainBlock.ACTIVE)) {
            player.displayClientMessage(Component.translatable("message.darkworld.already_active"), true);
            return;
        }
        if (!existing.isAir() && !(existing.getBlock() instanceof DarkFountainBlock)) {
            player.displayClientMessage(Component.translatable("message.darkworld.position_occupied"), true);
            return;
        }

        // 4. Prevent overlapping Overworld fountains
        DarkWorldManagerSavedData data = DarkWorldManagerSavedData.get(level.getServer());
        if (data.hasNearbyOverworldFountain(level.dimension().location(), fountainPos, 32)) {
            player.displayClientMessage(Component.translatable("message.darkworld.overlapping_fountain"), true);
            return;
        }

        // 5. Non-destructive enclosed-space detection
        EnclosedSpaceResult scan = EnclosedSpaceDetector.analyze(level, fountainPos);
        if (!scan.valid()) {
            player.displayClientMessage(scan.failureReason(), true);
            return;
        }

        // 6. Select up to 4 coherent biomes & analyze room inventories
        List<DarkBiomeRegistry.SelectedBiome> candidateBiomes = DarkBiomeRegistry.INSTANCE.selectBiomes(scan.materialComposition());
        InventoryAnalyzer.InventoryReport invReport = InventoryAnalyzer.analyze(level, scan.inventoryPositions());

        MaterialCategory dominant = scan.materialComposition().entrySet().stream()
                .max(Comparator.comparingDouble(Map.Entry::getValue))
                .map(Map.Entry::getKey)
                .orElse(MaterialCategory.STONE);

        long defaultSeed = level.getSeed() ^ fountainPos.asLong() ^ level.getGameTime();
        DarkWorldHue previewHue = DarkWorldHue.fromSeedAndMaterial(defaultSeed, dominant);

        ModNetwork.CHANNEL.send(
                new OpenDarkWorldConfigPacket(
                        fountainPos,
                        scan.interiorVolume(),
                        scan.detectedOpenings(),
                        defaultSeed,
                        previewHue,
                        scan.materialComposition(),
                        candidateBiomes,
                        invReport.uniqueItemTypes(),
                        invReport.blueprints()
                ),
                PacketDistributor.PLAYER.with(player)
        );
    }
}
