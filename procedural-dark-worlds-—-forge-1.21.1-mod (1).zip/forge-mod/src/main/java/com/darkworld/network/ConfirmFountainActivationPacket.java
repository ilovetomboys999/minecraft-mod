package com.darkworld.network;

import com.darkworld.analysis.EnclosedSpaceDetector;
import com.darkworld.analysis.EnclosedSpaceResult;
import com.darkworld.block.DarkFountainBlock;
import com.darkworld.block.DarkFountainBlockEntity;
import com.darkworld.darkner.InventoryAnalyzer;
import com.darkworld.registry.ModBlocks;
import com.darkworld.registry.ModSounds;
import com.darkworld.registry.ModTags;
import com.darkworld.registry.ModWorldGen;
import com.darkworld.world.DarkWorldHue;
import com.darkworld.world.DarkWorldInstance;
import com.darkworld.world.DarkWorldManagerSavedData;
import com.darkworld.world.DarkWorldSize;
import com.darkworld.world.biome.DarkBiomeRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.network.CustomPayloadEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * C2S confirmation packet from DarkWorldConfigScreen.
 * Re-validates all server preconditions before creating the finite Dark World instance
 * and activating the Dark Fountain.
 */
public class ConfirmFountainActivationPacket {
    private final BlockPos fountainPos;
    private final String worldName;
    private final DarkWorldSize size;
    private final long seed;
    private final float baseHue;
    private final float saturation;
    private final float brightness;
    private final float secondaryHue;
    private final List<DarkBiomeRegistry.SelectedBiome> customBiomes;

    public ConfirmFountainActivationPacket(
            BlockPos fountainPos,
            String worldName,
            DarkWorldSize size,
            long seed,
            DarkWorldHue hue,
            List<DarkBiomeRegistry.SelectedBiome> customBiomes
    ) {
        this.fountainPos = fountainPos;
        this.worldName = worldName;
        this.size = size;
        this.seed = seed;
        this.baseHue = hue.baseHue();
        this.saturation = hue.saturation();
        this.brightness = hue.brightness();
        this.secondaryHue = hue.secondaryHue();
        this.customBiomes = customBiomes;
    }

    public ConfirmFountainActivationPacket(FriendlyByteBuf buf) {
        this.fountainPos = buf.readBlockPos();
        this.worldName = buf.readUtf(48);
        this.size = DarkWorldSize.byId(buf.readUtf(16));
        this.seed = buf.readLong();
        this.baseHue = buf.readFloat();
        this.saturation = buf.readFloat();
        this.brightness = buf.readFloat();
        this.secondaryHue = buf.readFloat();

        int count = Math.min(4, buf.readInt());
        this.customBiomes = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            ResourceLocation id = buf.readResourceLocation();
            double weight = Math.max(0.05D, buf.readDouble());
            this.customBiomes.add(new DarkBiomeRegistry.SelectedBiome(id, weight));
        }
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBlockPos(fountainPos);
        buf.writeUtf(worldName, 48);
        buf.writeUtf(size.getId(), 16);
        buf.writeLong(seed);
        buf.writeFloat(baseHue);
        buf.writeFloat(saturation);
        buf.writeFloat(brightness);
        buf.writeFloat(secondaryHue);

        int count = Math.min(4, customBiomes.size());
        buf.writeInt(count);
        for (int i = 0; i < count; i++) {
            buf.writeResourceLocation(customBiomes.get(i).biomeId());
            buf.writeDouble(customBiomes.get(i).weight());
        }
    }

    public void handle(CustomPayloadEvent.Context context) {
        ServerPlayer player = context.getSender();
        if (player == null) return;

        ServerLevel level = player.serverLevel();
        if (level.dimension().equals(ModWorldGen.DARK_WORLD_DIMENSION)) return;
        if (!player.getMainHandItem().is(ModTags.Items.POINTED_ITEMS)) {
            player.displayClientMessage(Component.translatable("message.darkworld.need_pointed_item"), true);
            return;
        }
        if (!level.mayInteract(player, fountainPos) || player.blockPosition().distSqr(fountainPos) > 81.0D) {
            return;
        }

        DarkWorldManagerSavedData data = DarkWorldManagerSavedData.get(level.getServer());
        if (data.hasNearbyOverworldFountain(level.dimension().location(), fountainPos, 32)) {
            player.displayClientMessage(Component.translatable("message.darkworld.overlapping_fountain"), true);
            return;
        }

        EnclosedSpaceResult scan = EnclosedSpaceDetector.analyze(level, fountainPos);
        if (!scan.valid()) {
            player.displayClientMessage(scan.failureReason(), true);
            return;
        }

        List<DarkBiomeRegistry.SelectedBiome> selectedBiomes = customBiomes.isEmpty()
                ? DarkBiomeRegistry.INSTANCE.selectBiomes(scan.materialComposition())
                : normalizeBiomes(customBiomes);

        InventoryAnalyzer.InventoryReport invReport = InventoryAnalyzer.analyze(level, scan.inventoryPositions());
        int[] gridCenter = data.allocateNextGridCenter();

        DarkWorldHue hue = new DarkWorldHue(
                DarkWorldHue.normalizeHue(baseHue),
                Math.max(0.25F, Math.min(1.0F, saturation)),
                Math.max(0.25F, Math.min(0.95F, brightness)),
                DarkWorldHue.normalizeHue(secondaryHue)
        );

        String cleanName = worldName.isBlank() ? "Dark Fountain #" + (data.allInstances().size() + 1) : worldName.trim();
        String instanceId = UUID.randomUUID().toString();

        DarkWorldInstance instance = new DarkWorldInstance(
                instanceId,
                cleanName,
                seed,
                size,
                gridCenter[0],
                gridCenter[1],
                level.dimension().location(),
                fountainPos,
                hue,
                selectedBiomes,
                scan.materialComposition(),
                invReport.blueprints(),
                false
        );
        data.registerInstance(instance);

        // Place & activate Dark Fountain + vertical energy beam
        BlockState activeState = ModBlocks.DARK_FOUNTAIN.get().defaultBlockState()
                .setValue(DarkFountainBlock.ACTIVE, true)
                .setValue(DarkFountainBlock.RETURN_ANCHOR, false);
        level.setBlock(fountainPos, activeState, 3);
        if (level.getBlockEntity(fountainPos) instanceof DarkFountainBlockEntity be) {
            be.setInstanceId(instanceId);
            be.setHueRgb(hue.getPrimaryRgb());
            be.triggerEruptionAnimation();
        }
        for (int h = 1; h <= 6; h++) {
            BlockPos beamPos = fountainPos.above(h);
            if (level.getBlockState(beamPos).isAir()) {
                level.setBlock(beamPos, ModBlocks.DARK_PORTAL_BEAM.get().defaultBlockState(), 3);
            } else {
                break;
            }
        }

        level.playSound(null, fountainPos, ModSounds.FOUNTAIN_ERUPT.get(), SoundSource.BLOCKS, 1.2F, 0.95F);
        player.displayClientMessage(Component.translatable("message.darkworld.fountain_created", cleanName), false);
    }

    private static List<DarkBiomeRegistry.SelectedBiome> normalizeBiomes(List<DarkBiomeRegistry.SelectedBiome> input) {
        double sum = input.stream().mapToDouble(DarkBiomeRegistry.SelectedBiome::weight).sum();
        if (sum <= 0.0D) return input;
        List<DarkBiomeRegistry.SelectedBiome> out = new ArrayList<>();
        for (DarkBiomeRegistry.SelectedBiome sb : input) {
            out.add(new DarkBiomeRegistry.SelectedBiome(sb.biomeId(), sb.weight() / sum));
        }
        return out;
    }
}
