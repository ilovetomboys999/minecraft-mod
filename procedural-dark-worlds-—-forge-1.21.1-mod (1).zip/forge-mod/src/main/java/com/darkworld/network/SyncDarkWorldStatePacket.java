package com.darkworld.network;

import com.darkworld.client.ClientDarkWorldState;
import com.darkworld.world.DarkWorldHue;
import com.darkworld.world.DarkWorldInstance;
import com.darkworld.world.DarkWorldSize;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.network.CustomPayloadEvent;
import net.minecraftforge.fml.loading.FMLEnvironment;

public class SyncDarkWorldStatePacket {
    public final boolean active;
    public final String instanceId;
    public final String worldName;
    public final DarkWorldSize size;
    public final int centerX;
    public final int centerZ;
    public final DarkWorldHue hue;

    public SyncDarkWorldStatePacket(boolean active, String instanceId, String worldName, DarkWorldSize size,
                                    int centerX, int centerZ, DarkWorldHue hue) {
        this.active = active;
        this.instanceId = instanceId;
        this.worldName = worldName;
        this.size = size;
        this.centerX = centerX;
        this.centerZ = centerZ;
        this.hue = hue;
    }

    public static SyncDarkWorldStatePacket clear() {
        return new SyncDarkWorldStatePacket(false, "", "", DarkWorldSize.LARGE, 0, 0,
                new DarkWorldHue(265.0F, 0.7F, 0.6F, 300.0F));
    }

    public static SyncDarkWorldStatePacket fromInstance(DarkWorldInstance instance) {
        return new SyncDarkWorldStatePacket(
                true,
                instance.getInstanceId(),
                instance.getWorldName(),
                instance.getSize(),
                instance.getCenterX(),
                instance.getCenterZ(),
                instance.getHue()
        );
    }

    public SyncDarkWorldStatePacket(FriendlyByteBuf buf) {
        this.active = buf.readBoolean();
        this.instanceId = buf.readUtf();
        this.worldName = buf.readUtf();
        this.size = DarkWorldSize.byId(buf.readUtf());
        this.centerX = buf.readInt();
        this.centerZ = buf.readInt();
        this.hue = new DarkWorldHue(buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat());
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(active);
        buf.writeUtf(instanceId);
        buf.writeUtf(worldName);
        buf.writeUtf(size.getId());
        buf.writeInt(centerX);
        buf.writeInt(centerZ);
        buf.writeFloat(hue.baseHue());
        buf.writeFloat(hue.saturation());
        buf.writeFloat(hue.brightness());
        buf.writeFloat(hue.secondaryHue());
    }

    public void handle(CustomPayloadEvent.Context context) {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientDarkWorldState.update(this);
        }
    }
}
