package com.darkworld.network;

import com.darkworld.DarkWorldMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.Channel;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.SimpleChannel;

public class ModNetwork {
    private static final int PROTOCOL_VERSION = 1;

    public static final SimpleChannel CHANNEL = ChannelBuilder
            .named(ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "main"))
            .networkProtocolVersion(PROTOCOL_VERSION)
            .clientAcceptedVersions(Channel.VersionTest.exact(PROTOCOL_VERSION))
            .serverAcceptedVersions(Channel.VersionTest.exact(PROTOCOL_VERSION))
            .simpleChannel();

    private static int nextId = 0;

    private static int id() {
        return nextId++;
    }

    public static void register() {
        CHANNEL.messageBuilder(RequestFountainScanPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .encoder(RequestFountainScanPacket::encode)
                .decoder(RequestFountainScanPacket::new)
                .consumerMainThread(RequestFountainScanPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenDarkWorldConfigPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDarkWorldConfigPacket::encode)
                .decoder(OpenDarkWorldConfigPacket::new)
                .consumerMainThread(OpenDarkWorldConfigPacket::handle)
                .add();

        CHANNEL.messageBuilder(ConfirmFountainActivationPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .encoder(ConfirmFountainActivationPacket::encode)
                .decoder(ConfirmFountainActivationPacket::new)
                .consumerMainThread(ConfirmFountainActivationPacket::handle)
                .add();

        CHANNEL.messageBuilder(SyncDarkWorldStatePacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncDarkWorldStatePacket::encode)
                .decoder(SyncDarkWorldStatePacket::new)
                .consumerMainThread(SyncDarkWorldStatePacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenDarknerDialoguePacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDarknerDialoguePacket::encode)
                .decoder(OpenDarknerDialoguePacket::new)
                .consumerMainThread(OpenDarknerDialoguePacket::handle)
                .add();
    }
}
