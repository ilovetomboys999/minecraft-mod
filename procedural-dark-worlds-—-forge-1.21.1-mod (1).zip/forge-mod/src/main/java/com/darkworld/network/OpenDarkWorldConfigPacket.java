package com.darkworld.network;

import com.darkworld.analysis.MaterialCategory;
import com.darkworld.client.ClientPacketHandler;
import com.darkworld.darkner.InventoryAnalyzer;
import com.darkworld.world.DarkWorldHue;
import com.darkworld.world.biome.DarkBiomeRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.network.CustomPayloadEvent;
import net.minecraftforge.fml.loading.FMLEnvironment;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class OpenDarkWorldConfigPacket {
    public final BlockPos fountainPos;
    public final int interiorVolume;
    public final int detectedOpenings;
    public final long proposedSeed;
    public final DarkWorldHue proposedHue;
    public final Map<MaterialCategory, Double> materials;
    public final List<DarkBiomeRegistry.SelectedBiome> biomes;
    public final int uniqueItemTypes;
    public final List<InventoryAnalyzer.DarknerBlueprint> darknerBlueprints;

    public OpenDarkWorldConfigPacket(
            BlockPos fountainPos,
            int interiorVolume,
            int detectedOpenings,
            long proposedSeed,
            DarkWorldHue proposedHue,
            Map<MaterialCategory, Double> materials,
            List<DarkBiomeRegistry.SelectedBiome> biomes,
            int uniqueItemTypes,
            List<InventoryAnalyzer.DarknerBlueprint> darknerBlueprints
    ) {
        this.fountainPos = fountainPos;
        this.interiorVolume = interiorVolume;
        this.detectedOpenings = detectedOpenings;
        this.proposedSeed = proposedSeed;
        this.proposedHue = proposedHue;
        this.materials = materials;
        this.biomes = biomes;
        this.uniqueItemTypes = uniqueItemTypes;
        this.darknerBlueprints = darknerBlueprints;
    }

    public OpenDarkWorldConfigPacket(FriendlyByteBuf buf) {
        this.fountainPos = buf.readBlockPos();
        this.interiorVolume = buf.readInt();
        this.detectedOpenings = buf.readInt();
        this.proposedSeed = buf.readLong();
        this.proposedHue = new DarkWorldHue(buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat());

        int matCount = buf.readInt();
        this.materials = new EnumMap<>(MaterialCategory.class);
        for (int i = 0; i < matCount; i++) {
            MaterialCategory cat = MaterialCategory.byId(buf.readUtf());
            double w = buf.readDouble();
            if (cat != null) this.materials.put(cat, w);
        }

        int biomeCount = buf.readInt();
        this.biomes = new ArrayList<>();
        for (int i = 0; i < biomeCount; i++) {
            this.biomes.add(new DarkBiomeRegistry.SelectedBiome(buf.readResourceLocation(), buf.readDouble()));
        }

        this.uniqueItemTypes = buf.readInt();
        int bpCount = buf.readInt();
        this.darknerBlueprints = new ArrayList<>();
        for (int i = 0; i < bpCount; i++) {
            this.darknerBlueprints.add(InventoryAnalyzer.DarknerBlueprint.fromTag(buf.readNbt()));
        }
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBlockPos(fountainPos);
        buf.writeInt(interiorVolume);
        buf.writeInt(detectedOpenings);
        buf.writeLong(proposedSeed);
        buf.writeFloat(proposedHue.baseHue());
        buf.writeFloat(proposedHue.saturation());
        buf.writeFloat(proposedHue.brightness());
        buf.writeFloat(proposedHue.secondaryHue());

        buf.writeInt(materials.size());
        for (Map.Entry<MaterialCategory, Double> e : materials.entrySet()) {
            buf.writeUtf(e.getKey().getId());
            buf.writeDouble(e.getValue());
        }

        buf.writeInt(biomes.size());
        for (DarkBiomeRegistry.SelectedBiome b : biomes) {
            buf.writeResourceLocation(b.biomeId());
            buf.writeDouble(b.weight());
        }

        buf.writeInt(uniqueItemTypes);
        buf.writeInt(darknerBlueprints.size());
        for (InventoryAnalyzer.DarknerBlueprint bp : darknerBlueprints) {
            buf.writeNbt(bp.toTag());
        }
    }

    public void handle(CustomPayloadEvent.Context context) {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientPacketHandler.openConfigScreen(this);
        }
    }
}
