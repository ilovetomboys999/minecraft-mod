package com.darkworld.darkner;

import com.darkworld.config.DarkWorldConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.Container;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PotionItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.WritableBookItem;
import net.minecraft.world.item.WrittenBookItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.Tags;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Inspects inventories inside an enclosed room without modifying them,
 * deriving Darkner population distribution from item type variety.
 */
public class InventoryAnalyzer {

    public record DarknerBlueprint(
            String displayName,
            DarknerArchetype archetype,
            ResourceLocation sourceItemId,
            BlockPos sourceContainerPos,
            int count
    ) {
        public CompoundTag toTag() {
            CompoundTag tag = new CompoundTag();
            tag.putString("Name", displayName);
            tag.putString("Archetype", archetype.getId());
            tag.putString("Item", sourceItemId.toString());
            tag.putLong("Pos", sourceContainerPos.asLong());
            tag.putInt("Count", count);
            return tag;
        }

        public static DarknerBlueprint fromTag(CompoundTag tag) {
            return new DarknerBlueprint(
                    tag.getString("Name"),
                    DarknerArchetype.byId(tag.getString("Archetype")),
                    ResourceLocation.parse(tag.getString("Item")),
                    BlockPos.of(tag.getLong("Pos")),
                    tag.getInt("Count")
            );
        }
    }

    public record InventoryReport(
            int totalContainersScanned,
            int uniqueItemTypes,
            int totalItemCount,
            List<DarknerBlueprint> blueprints,
            Map<DarknerArchetype, Integer> archetypeCounts
    ) {}

    public static InventoryReport analyze(Level level, List<BlockPos> containerPositions) {
        Map<ResourceLocation, ItemOccurrence> distinctItems = new LinkedHashMap<>();
        int totalItems = 0;

        for (BlockPos pos : containerPositions) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be == null) continue;

            List<ItemStack> stacks = extractReadOnlyStacks(be);
            for (ItemStack stack : stacks) {
                if (stack.isEmpty()) continue;
                totalItems += stack.getCount();
                ResourceLocation itemId = BuiltInRegistries.ITEM.getKey(stack.getItem());
                distinctItems.compute(itemId, (k, existing) -> {
                    if (existing == null) {
                        return new ItemOccurrence(stack.copyWithCount(1), pos, stack.getCount());
                    }
                    existing.totalCount += stack.getCount();
                    return existing;
                });
            }
        }

        int maxPopulation = DarkWorldConfig.MAX_DARKNERS_PER_WORLD.get();
        List<DarknerBlueprint> blueprints = new ArrayList<>();
        Map<DarknerArchetype, Integer> archetypeCounts = new EnumMap<>(DarknerArchetype.class);

        if (distinctItems.isEmpty()) {
            // Empty rooms still manifest a small core of ambient Darkners
            blueprints.add(new DarknerBlueprint(
                    "Echo of the Threshold",
                    DarknerArchetype.WANDERER,
                    ResourceLocation.withDefaultNamespace("air"),
                    BlockPos.ZERO,
                    3
            ));
            archetypeCounts.put(DarknerArchetype.WANDERER, 3);
            return new InventoryReport(containerPositions.size(), 0, 0, blueprints, archetypeCounts);
        }

        // Distribute population proportionally to distinct item varieties
        int budget = Math.min(maxPopulation, Math.max(4, distinctItems.size() * 2 + (int) Math.sqrt(totalItems)));
        int typesRemaining = distinctItems.size();
        int assigned = 0;

        for (Map.Entry<ResourceLocation, ItemOccurrence> entry : distinctItems.entrySet()) {
            if (assigned >= budget) break;
            ItemOccurrence occ = entry.getValue();
            DarknerArchetype archetype = classifyItem(occ.sample);

            int share = Math.max(1, (int) Math.round((double) (budget - assigned) / Math.max(1, typesRemaining)));
            share = Math.min(share, 4);
            if (assigned + share > budget) {
                share = budget - assigned;
            }
            if (share <= 0) break;

            String itemName = occ.sample.getHoverName().getString();
            String darknerName = generateDarknerName(itemName, archetype);
            blueprints.add(new DarknerBlueprint(darknerName, archetype, entry.getKey(), occ.firstPos, share));
            archetypeCounts.merge(archetype, share, Integer::sum);

            assigned += share;
            typesRemaining--;
        }

        return new InventoryReport(containerPositions.size(), distinctItems.size(), totalItems, blueprints, archetypeCounts);
    }

    private static List<ItemStack> extractReadOnlyStacks(BlockEntity be) {
        List<ItemStack> result = new ArrayList<>();
        if (be instanceof Container container) {
            for (int i = 0; i < container.getContainerSize(); i++) {
                ItemStack s = container.getItem(i);
                if (!s.isEmpty()) result.add(s);
            }
            return result;
        }
        be.getCapability(ForgeCapabilities.ITEM_HANDLER).ifPresent(handler -> {
            for (int i = 0; i < handler.getSlots(); i++) {
                ItemStack s = handler.getStackInSlot(i);
                if (!s.isEmpty()) result.add(s);
            }
        });
        return result;
    }

    public static DarknerArchetype classifyItem(ItemStack stack) {
        Item item = stack.getItem();
        if (item instanceof SwordItem || item instanceof BowItem || item instanceof ArmorItem || stack.is(ItemTags.SWORDS) || stack.is(ItemTags.AXES)) {
            return DarknerArchetype.BLADE_KNIGHT;
        }
        if (item.components().has(net.minecraft.core.component.DataComponents.FOOD)) {
            return DarknerArchetype.FEASTKEEPER;
        }
        if (item instanceof EnchantedBookItem || item instanceof WrittenBookItem || item instanceof WritableBookItem || stack.is(ItemTags.BOOKSHELF_BOOKS)) {
            return DarknerArchetype.ARCHIVIST;
        }
        if (item instanceof PotionItem) {
            return DarknerArchetype.ALCHEMIST;
        }
        if (stack.is(Tags.Items.GEMS) || stack.is(Tags.Items.INGOTS) || stack.is(Tags.Items.ORES)) {
            return DarknerArchetype.LAPIDARY;
        }
        if (stack.is(Tags.Items.DUSTS_REDSTONE) || stack.is(ItemTags.RAILS) || item instanceof DiggerItem) {
            return DarknerArchetype.TINKER_AUTOMATON;
        }
        if (stack.is(ItemTags.WOOL) || stack.is(ItemTags.BANNERS) || stack.is(ItemTags.MUSIC_DISCS)) {
            return DarknerArchetype.BARD_TAILOR;
        }
        if (item instanceof BlockItem bi && bi.getBlock().defaultBlockState().is(net.minecraft.tags.BlockTags.BASE_STONE_NETHER)) {
            return DarknerArchetype.EMBER_SMITH;
        }
        return DarknerArchetype.WANDERER;
    }

    private static String generateDarknerName(String itemName, DarknerArchetype archetype) {
        String clean = itemName.replaceAll("[^A-Za-z0-9 ]", "").trim();
        if (clean.length() > 18) {
            clean = clean.substring(0, 18).trim();
        }
        return clean + " " + archetype.getRoleTitle();
    }

    private static class ItemOccurrence {
        final ItemStack sample;
        final BlockPos firstPos;
        int totalCount;

        ItemOccurrence(ItemStack sample, BlockPos firstPos, int totalCount) {
            this.sample = sample;
            this.firstPos = firstPos;
            this.totalCount = totalCount;
        }
    }
}
