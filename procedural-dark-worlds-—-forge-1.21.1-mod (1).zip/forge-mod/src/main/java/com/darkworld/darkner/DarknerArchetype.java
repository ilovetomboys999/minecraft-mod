package com.darkworld.darkner;

import net.minecraft.network.chat.Component;

public enum DarknerArchetype {
    BLADE_KNIGHT("blade_knight", "Vanguard", 0xD94E67),
    FEASTKEEPER("feastkeeper", "Provisioner", 0xE6A145),
    ARCHIVIST("archivist", "Lorekeeper", 0x6A7BE6),
    LAPIDARY("lapidary", "Gemwright", 0x4ECFD9),
    TINKER_AUTOMATON("tinker_automaton", "Mechanist", 0xD96B45),
    ALCHEMIST("alchemist", "Brewer", 0x9C5CE6),
    BARD_TAILOR("bard_tailor", "Weaver", 0xE664B5),
    EMBER_SMITH("ember_smith", "Forgemaster", 0xE65C3A),
    WANDERER("wanderer", "Oddity", 0x8BA3B8);

    private final String id;
    private final String roleTitle;
    private final int defaultAccentRgb;

    DarknerArchetype(String id, String roleTitle, int defaultAccentRgb) {
        this.id = id;
        this.roleTitle = roleTitle;
        this.defaultAccentRgb = defaultAccentRgb;
    }

    public String getId() {
        return id;
    }

    public String getRoleTitle() {
        return roleTitle;
    }

    public int getDefaultAccentRgb() {
        return defaultAccentRgb;
    }

    public Component getDisplayTitle() {
        return Component.translatable("darkner.archetype.darkworld." + id);
    }

    public static DarknerArchetype byId(String id) {
        for (DarknerArchetype a : values()) {
            if (a.id.equalsIgnoreCase(id)) return a;
        }
        return WANDERER;
    }
}
