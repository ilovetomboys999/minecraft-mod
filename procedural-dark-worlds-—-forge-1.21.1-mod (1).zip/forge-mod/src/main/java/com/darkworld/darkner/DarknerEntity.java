package com.darkworld.darkner;

import com.darkworld.network.ModNetwork;
import com.darkworld.network.OpenDarknerDialoguePacket;
import com.darkworld.registry.ModItems;
import com.darkworld.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;

public class DarknerEntity extends PathfinderMob {
    private static final EntityDataAccessor<String> DATA_ARCHETYPE =
            SynchedEntityData.defineId(DarknerEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> DATA_SOURCE_ITEM =
            SynchedEntityData.defineId(DarknerEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> DATA_TINT_RGB =
            SynchedEntityData.defineId(DarknerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<BlockPos> DATA_ORIGIN_CHEST =
            SynchedEntityData.defineId(DarknerEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<String> DATA_INSTANCE_ID =
            SynchedEntityData.defineId(DarknerEntity.class, EntityDataSerializers.STRING);

    public DarknerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.24D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ARCHETYPE, DarknerArchetype.WANDERER.getId());
        builder.define(DATA_SOURCE_ITEM, "minecraft:air");
        builder.define(DATA_TINT_RGB, 0x9C5CE6);
        builder.define(DATA_ORIGIN_CHEST, BlockPos.ZERO);
        builder.define(DATA_INSTANCE_ID, "");
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    public void configure(String name, DarknerArchetype archetype, String sourceItemId, BlockPos originChest, int tintRgb, String instanceId) {
        this.setCustomName(Component.literal(name));
        this.setCustomNameVisible(true);
        this.entityData.set(DATA_ARCHETYPE, archetype.getId());
        this.entityData.set(DATA_SOURCE_ITEM, sourceItemId);
        this.entityData.set(DATA_ORIGIN_CHEST, originChest);
        this.entityData.set(DATA_TINT_RGB, tintRgb);
        this.entityData.set(DATA_INSTANCE_ID, instanceId);
    }

    public DarknerArchetype getArchetype() {
        return DarknerArchetype.byId(this.entityData.get(DATA_ARCHETYPE));
    }

    public String getSourceItemId() {
        return this.entityData.get(DATA_SOURCE_ITEM);
    }

    public int getTintRgb() {
        return this.entityData.get(DATA_TINT_RGB);
    }

    public BlockPos getOriginChestPos() {
        return this.entityData.get(DATA_ORIGIN_CHEST);
    }

    public String getInstanceId() {
        return this.entityData.get(DATA_INSTANCE_ID);
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.level().isClientSide && player instanceof ServerPlayer serverPlayer) {
            this.playSound(ModSounds.DARKNER_CHIME.get(), 0.8F, 0.9F + this.random.nextFloat() * 0.25F);
            ItemStack held = player.getItemInHand(hand);
            if (held.is(ModItems.DARKNER_CHARM.get())) {
                serverPlayer.sendSystemMessage(Component.translatable(
                        "message.darkworld.darkner_inspect",
                        this.getDisplayName(),
                        getSourceItemId(),
                        getOriginChestPos().toShortString()
                ));
            }
            ModNetwork.CHANNEL.send(
                    new OpenDarknerDialoguePacket(
                            this.getId(),
                            this.getDisplayName().getString(),
                            getArchetype().getId(),
                            getSourceItemId(),
                            getOriginChestPos(),
                            getTintRgb()
                    ),
                    PacketDistributor.PLAYER.with(serverPlayer)
            );
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Archetype", getArchetype().getId());
        tag.putString("SourceItem", getSourceItemId());
        tag.putInt("TintRgb", getTintRgb());
        tag.putLong("OriginChest", getOriginChestPos().asLong());
        tag.putString("InstanceId", getInstanceId());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Archetype")) this.entityData.set(DATA_ARCHETYPE, tag.getString("Archetype"));
        if (tag.contains("SourceItem")) this.entityData.set(DATA_SOURCE_ITEM, tag.getString("SourceItem"));
        if (tag.contains("TintRgb")) this.entityData.set(DATA_TINT_RGB, tag.getInt("TintRgb"));
        if (tag.contains("OriginChest")) this.entityData.set(DATA_ORIGIN_CHEST, BlockPos.of(tag.getLong("OriginChest")));
        if (tag.contains("InstanceId")) this.entityData.set(DATA_INSTANCE_ID, tag.getString("InstanceId"));
    }
}
