package com.darkworld;

import com.darkworld.analysis.BlockExceptionRegistry;
import com.darkworld.config.DarkWorldConfig;
import com.darkworld.network.ModNetwork;
import com.darkworld.registry.ModBlockEntities;
import com.darkworld.registry.ModBlocks;
import com.darkworld.registry.ModEntities;
import com.darkworld.registry.ModItems;
import com.darkworld.registry.ModParticles;
import com.darkworld.registry.ModSounds;
import com.darkworld.registry.ModWorldGen;
import com.darkworld.world.biome.DarkBiomeRegistry;
import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

@Mod(DarkWorldMod.MOD_ID)
public class DarkWorldMod {
    public static final String MOD_ID = "darkworld";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final RegistryObject<CreativeModeTab> DARK_WORLD_TAB = CREATIVE_TABS.register(
            "dark_world_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.darkworld"))
                    .icon(() -> new ItemStack(ModItems.DARK_FOUNTAIN_ITEM.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.DARK_FOUNTAIN_ITEM.get());
                        output.accept(ModItems.FOUNTAIN_SEAL.get());
                        output.accept(ModItems.DARK_SHARD.get());
                        output.accept(ModItems.DARKNER_CHARM.get());
                        output.accept(ModItems.DARK_SOIL_ITEM.get());
                        output.accept(ModItems.DARK_TURF_ITEM.get());
                        output.accept(ModItems.DARK_STONE_ITEM.get());
                        output.accept(ModItems.DARK_LOG_ITEM.get());
                        output.accept(ModItems.DARK_LEAVES_ITEM.get());
                        output.accept(ModItems.DARK_SAND_ITEM.get());
                        output.accept(ModItems.DARK_CRYSTAL_ITEM.get());
                        output.accept(ModItems.DARK_BRICK_ITEM.get());
                        output.accept(ModItems.DARK_METAL_PLATE_ITEM.get());
                        output.accept(ModItems.DARK_PILLAR_ITEM.get());
                    })
                    .build()
    );

    public DarkWorldMod(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();

        ModBlocks.BLOCKS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);
        ModParticles.PARTICLES.register(modEventBus);
        ModSounds.SOUNDS.register(modEventBus);
        ModWorldGen.CHUNK_GENERATORS.register(modEventBus);
        ModWorldGen.BIOME_SOURCES.register(modEventBus);
        CREATIVE_TABS.register(modEventBus);

        modEventBus.addListener(this::onCommonSetup);
        modEventBus.addListener(this::onEntityAttributes);

        context.registerConfig(ModConfig.Type.COMMON, DarkWorldConfig.SPEC);

        MinecraftForge.EVENT_BUS.addListener(this::onAddReloadListeners);
    }

    private void onCommonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
        LOGGER.info("Procedural Dark Worlds initialized.");
    }

    private void onEntityAttributes(final EntityAttributeCreationEvent event) {
        event.put(ModEntities.DARKNER.get(), com.darkworld.darkner.DarknerEntity.createAttributes().build());
    }

    private void onAddReloadListeners(final AddReloadListenerEvent event) {
        event.addListener(BlockExceptionRegistry.INSTANCE);
        event.addListener(DarkBiomeRegistry.INSTANCE);
    }
}
