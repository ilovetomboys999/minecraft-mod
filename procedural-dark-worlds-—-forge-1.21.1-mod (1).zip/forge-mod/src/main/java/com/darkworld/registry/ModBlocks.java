package com.darkworld.registry;

import com.darkworld.DarkWorldMod;
import com.darkworld.block.DarkFountainBlock;
import com.darkworld.block.DarkPortalBeamBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, DarkWorldMod.MOD_ID);

    public static final RegistryObject<Block> DARK_FOUNTAIN = BLOCKS.register("dark_fountain",
            () -> new DarkFountainBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .strength(4.5F, 1200.0F)
                    .sound(SoundType.AMETHYST)
                    .lightLevel(state -> state.getValue(DarkFountainBlock.ACTIVE) ? 14 : 4)
                    .noOcclusion()));

    public static final RegistryObject<Block> DARK_PORTAL_BEAM = BLOCKS.register("dark_portal_beam",
            () -> new DarkPortalBeamBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE)
                    .noCollission()
                    .strength(-1.0F, 3600000.0F)
                    .lightLevel(state -> 12)
                    .noLootTable()));

    public static final RegistryObject<Block> DARK_SOIL = BLOCKS.register("dark_soil",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .strength(0.6F)
                    .sound(SoundType.GRAVEL)));

    public static final RegistryObject<Block> DARK_TURF = BLOCKS.register("dark_turf",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_CYAN)
                    .strength(0.7F)
                    .sound(SoundType.GRASS)));

    public static final RegistryObject<Block> DARK_STONE = BLOCKS.register("dark_stone",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DEEPSLATE)
                    .requiresCorrectToolForDrops()
                    .strength(2.2F, 6.0F)
                    .sound(SoundType.DEEPSLATE)));

    public static final RegistryObject<Block> DARK_LOG = BLOCKS.register("dark_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLUE)
                    .strength(2.0F)
                    .sound(SoundType.WOOD)));

    public static final RegistryObject<Block> DARK_LEAVES = BLOCKS.register("dark_leaves",
            () -> new LeavesBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES)
                    .mapColor(MapColor.COLOR_MAGENTA)
                    .lightLevel(state -> 3)));

    public static final RegistryObject<Block> DARK_SAND = BLOCKS.register("dark_sand",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_GRAY)
                    .strength(0.6F)
                    .sound(SoundType.SAND)));

    public static final RegistryObject<Block> DARK_CRYSTAL = BLOCKS.register("dark_crystal",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .strength(1.8F)
                    .sound(SoundType.AMETHYST)
                    .lightLevel(state -> 9)));

    public static final RegistryObject<Block> DARK_BRICK = BLOCKS.register("dark_brick",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE)
                    .requiresCorrectToolForDrops()
                    .strength(2.5F, 8.0F)
                    .sound(SoundType.NETHER_BRICKS)));

    public static final RegistryObject<Block> DARK_METAL_PLATE = BLOCKS.register("dark_metal_plate",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL)
                    .requiresCorrectToolForDrops()
                    .strength(3.5F, 10.0F)
                    .sound(SoundType.NETHERITE_BLOCK)));

    public static final RegistryObject<Block> DARK_PILLAR = BLOCKS.register("dark_pillar",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.QUARTZ)
                    .requiresCorrectToolForDrops()
                    .strength(2.4F, 7.0F)
                    .sound(SoundType.STONE)
                    .lightLevel(state -> 4)));
}
