package com.darkworld.registry;

import com.darkworld.DarkWorldMod;
import com.darkworld.darkner.DarknerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DarkWorldMod.MOD_ID);

    public static final RegistryObject<EntityType<DarknerEntity>> DARKNER = ENTITIES.register("darkner",
            () -> EntityType.Builder.<DarknerEntity>of(DarknerEntity::new, MobCategory.CREATURE)
                    .sized(0.65F, 1.75F)
                    .clientTrackingRange(10)
                    .build("darkner"));
}
