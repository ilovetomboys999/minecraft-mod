package com.darkworld.registry;

import com.darkworld.DarkWorldMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

public class ModTags {
    public static class Items {
        public static final TagKey<Item> POINTED_ITEMS =
                ItemTags.create(ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "pointed_items"));
    }

    public static class Blocks {
        public static final TagKey<Block> ANALYSIS_EXCLUDED =
                BlockTags.create(ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "analysis_excluded"));
        public static final TagKey<Block> INVENTORY_CONTAINERS =
                BlockTags.create(ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "inventory_containers"));

        public static final TagKey<Block> MAT_STONE = matTag("stone");
        public static final TagKey<Block> MAT_DIRT = matTag("dirt");
        public static final TagKey<Block> MAT_GRASS = matTag("grass");
        public static final TagKey<Block> MAT_WOOD = matTag("wood");
        public static final TagKey<Block> MAT_LEAVES = matTag("leaves");
        public static final TagKey<Block> MAT_SAND = matTag("sand");
        public static final TagKey<Block> MAT_GLASS = matTag("glass");
        public static final TagKey<Block> MAT_METAL = matTag("metal");
        public static final TagKey<Block> MAT_CRYSTAL = matTag("crystal");
        public static final TagKey<Block> MAT_WATER = matTag("water");
        public static final TagKey<Block> MAT_ICE = matTag("ice");
        public static final TagKey<Block> MAT_SNOW = matTag("snow");
        public static final TagKey<Block> MAT_NETHER = matTag("nether");
        public static final TagKey<Block> MAT_END = matTag("end");
        public static final TagKey<Block> MAT_ORGANIC = matTag("organic");
        public static final TagKey<Block> MAT_DECORATIVE = matTag("decorative");
        public static final TagKey<Block> MAT_BRICKS = matTag("bricks");
        public static final TagKey<Block> MAT_CONCRETE = matTag("concrete");

        private static TagKey<Block> matTag(String name) {
            return BlockTags.create(ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "materials/" + name));
        }
    }
}
