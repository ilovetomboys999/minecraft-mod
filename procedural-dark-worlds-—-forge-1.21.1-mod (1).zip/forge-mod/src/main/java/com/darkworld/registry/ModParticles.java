package com.darkworld.registry;

import com.darkworld.DarkWorldMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, DarkWorldMod.MOD_ID);

    public static final RegistryObject<SimpleParticleType> DARK_FOUNTAIN_PLUME =
            PARTICLES.register("dark_fountain_plume", () -> new SimpleParticleType(true));

    public static final RegistryObject<SimpleParticleType> DARK_SPARK =
            PARTICLES.register("dark_spark", () -> new SimpleParticleType(false));
}
