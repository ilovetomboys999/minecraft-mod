package com.darkworld.registry;

import com.darkworld.DarkWorldMod;
import com.darkworld.item.DarknerCharmItem;
import com.darkworld.item.FountainSealItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, DarkWorldMod.MOD_ID);

    public static final RegistryObject<Item> DARK_FOUNTAIN_ITEM = ITEMS.register("dark_fountain",
            () -> new BlockItem(ModBlocks.DARK_FOUNTAIN.get(), new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> FOUNTAIN_SEAL = ITEMS.register("fountain_seal",
            () -> new FountainSealItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> DARK_SHARD = ITEMS.register("dark_shard",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> DARKNER_CHARM = ITEMS.register("darkner_charm",
            () -> new DarknerCharmItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> DARK_SOIL_ITEM = blockItem("dark_soil", ModBlocks.DARK_SOIL);
    public static final RegistryObject<Item> DARK_TURF_ITEM = blockItem("dark_turf", ModBlocks.DARK_TURF);
    public static final RegistryObject<Item> DARK_STONE_ITEM = blockItem("dark_stone", ModBlocks.DARK_STONE);
    public static final RegistryObject<Item> DARK_LOG_ITEM = blockItem("dark_log", ModBlocks.DARK_LOG);
    public static final RegistryObject<Item> DARK_LEAVES_ITEM = blockItem("dark_leaves", ModBlocks.DARK_LEAVES);
    public static final RegistryObject<Item> DARK_SAND_ITEM = blockItem("dark_sand", ModBlocks.DARK_SAND);
    public static final RegistryObject<Item> DARK_CRYSTAL_ITEM = blockItem("dark_crystal", ModBlocks.DARK_CRYSTAL);
    public static final RegistryObject<Item> DARK_BRICK_ITEM = blockItem("dark_brick", ModBlocks.DARK_BRICK);
    public static final RegistryObject<Item> DARK_METAL_PLATE_ITEM = blockItem("dark_metal_plate", ModBlocks.DARK_METAL_PLATE);
    public static final RegistryObject<Item> DARK_PILLAR_ITEM = blockItem("dark_pillar", ModBlocks.DARK_PILLAR);

    private static RegistryObject<Item> blockItem(String name, RegistryObject<net.minecraft.world.level.block.Block> block) {
        return ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }
}
