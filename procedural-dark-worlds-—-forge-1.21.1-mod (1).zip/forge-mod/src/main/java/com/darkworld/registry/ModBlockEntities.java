package com.darkworld.registry;

import com.darkworld.DarkWorldMod;
import com.darkworld.block.DarkFountainBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, DarkWorldMod.MOD_ID);

    public static final RegistryObject<BlockEntityType<DarkFountainBlockEntity>> DARK_FOUNTAIN_BE =
            BLOCK_ENTITIES.register("dark_fountain", () ->
                    BlockEntityType.Builder.of(DarkFountainBlockEntity::new, ModBlocks.DARK_FOUNTAIN.get()).build(null));
}
