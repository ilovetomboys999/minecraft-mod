package com.darkworld.registry;

import com.darkworld.DarkWorldMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, DarkWorldMod.MOD_ID);

    public static final RegistryObject<SoundEvent> FOUNTAIN_ERUPT = register("fountain_erupt");
    public static final RegistryObject<SoundEvent> FOUNTAIN_HUM = register("fountain_hum");
    public static final RegistryObject<SoundEvent> DARK_WORLD_ENTER = register("dark_world_enter");
    public static final RegistryObject<SoundEvent> DARKNER_CHIME = register("darkner_chime");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, name)));
    }
}
