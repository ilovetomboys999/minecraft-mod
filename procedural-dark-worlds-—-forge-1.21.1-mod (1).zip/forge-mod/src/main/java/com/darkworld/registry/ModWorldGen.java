package com.darkworld.registry;

import com.darkworld.DarkWorldMod;
import com.darkworld.world.gen.DarkWorldBiomeSource;
import com.darkworld.world.gen.DarkWorldChunkGenerator;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModWorldGen {
    public static final ResourceKey<Level> DARK_WORLD_DIMENSION = ResourceKey.create(
            Registries.DIMENSION,
            ResourceLocation.fromNamespaceAndPath(DarkWorldMod.MOD_ID, "dark_world")
    );

    public static final DeferredRegister<MapCodec<? extends ChunkGenerator>> CHUNK_GENERATORS =
            DeferredRegister.create(Registries.CHUNK_GENERATOR, DarkWorldMod.MOD_ID);

    public static final DeferredRegister<MapCodec<? extends BiomeSource>> BIOME_SOURCES =
            DeferredRegister.create(Registries.BIOME_SOURCE, DarkWorldMod.MOD_ID);

    public static final RegistryObject<MapCodec<DarkWorldChunkGenerator>> DARK_WORLD_CHUNK_GENERATOR =
            CHUNK_GENERATORS.register("dark_world", () -> DarkWorldChunkGenerator.CODEC);

    public static final RegistryObject<MapCodec<DarkWorldBiomeSource>> DARK_WORLD_BIOME_SOURCE =
            BIOME_SOURCES.register("dark_world_biomes", () -> DarkWorldBiomeSource.CODEC);
}
