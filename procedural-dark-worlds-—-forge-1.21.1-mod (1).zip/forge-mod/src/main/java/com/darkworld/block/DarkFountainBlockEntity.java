package com.darkworld.block;

import com.darkworld.registry.ModBlockEntities;
import com.darkworld.registry.ModParticles;
import com.darkworld.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class DarkFountainBlockEntity extends BlockEntity {
    private String instanceId = "";
    private int hueRgb = 0x7A42F5;
    private int eruptionTicks = 0;

    public DarkFountainBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.DARK_FOUNTAIN_BE.get(), pos, state);
    }

    public String getInstanceId() { return instanceId; }
    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
        setChanged();
    }

    public int getHueRgb() { return hueRgb; }
    public void setHueRgb(int hueRgb) {
        this.hueRgb = hueRgb;
        setChanged();
    }

    public void triggerEruptionAnimation() {
        this.eruptionTicks = 60;
        setChanged();
    }

    public static void tick(Level level, BlockPos pos, BlockState state, DarkFountainBlockEntity be) {
        if (!state.getValue(DarkFountainBlock.ACTIVE)) return;

        if (level.isClientSide) {
            int count = be.eruptionTicks > 0 ? 5 : 2;
            for (int i = 0; i < count; i++) {
                double ox = (level.random.nextDouble() - 0.5D) * 0.55D;
                double oz = (level.random.nextDouble() - 0.5D) * 0.55D;
                double vy = 0.08D + level.random.nextDouble() * 0.14D;
                level.addParticle(
                        ModParticles.DARK_FOUNTAIN_PLUME.get(),
                        pos.getX() + 0.5D + ox,
                        pos.getY() + 0.9D,
                        pos.getZ() + 0.5D + oz,
                        0.0D, vy, 0.0D
                );
            }
            if (be.eruptionTicks > 0) {
                be.eruptionTicks--;
            }
        } else {
            if (be.eruptionTicks > 0) {
                be.eruptionTicks--;
            }
            if (level.getGameTime() % 80L == 0L) {
                level.playSound(null, pos, ModSounds.FOUNTAIN_HUM.get(), SoundSource.BLOCKS, 0.35F, 0.9F);
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putString("InstanceId", instanceId);
        tag.putInt("HueRgb", hueRgb);
        tag.putInt("EruptionTicks", eruptionTicks);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        instanceId = tag.getString("InstanceId");
        hueRgb = tag.contains("HueRgb") ? tag.getInt("HueRgb") : 0x7A42F5;
        eruptionTicks = tag.getInt("EruptionTicks");
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
