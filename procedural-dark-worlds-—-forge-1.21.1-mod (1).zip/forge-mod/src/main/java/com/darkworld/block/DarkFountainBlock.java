package com.darkworld.block;

import com.darkworld.registry.ModBlockEntities;
import com.darkworld.world.DarkWorldInstance;
import com.darkworld.world.DarkWorldManagerSavedData;
import com.darkworld.world.DarkWorldTeleporter;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class DarkFountainBlock extends BaseEntityBlock {
    public static final MapCodec<DarkFountainBlock> CODEC = simpleCodec(DarkFountainBlock::new);
    public static final BooleanProperty ACTIVE = BooleanProperty.create("active");
    public static final BooleanProperty RETURN_ANCHOR = BooleanProperty.create("return_anchor");

    private static final VoxelShape SHAPE = Block.box(2.0D, 0.0D, 2.0D, 14.0D, 14.0D, 14.0D);

    public DarkFountainBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(ACTIVE, false)
                .setValue(RETURN_ANCHOR, false));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ACTIVE, RETURN_ANCHOR);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new DarkFountainBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, ModBlockEntities.DARK_FOUNTAIN_BE.get(), DarkFountainBlockEntity::tick);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            if (state.getValue(RETURN_ANCHOR)) {
                DarkWorldTeleporter.returnToOrigin(serverPlayer);
                return InteractionResult.CONSUME;
            }
            if (state.getValue(ACTIVE) && level.getBlockEntity(pos) instanceof DarkFountainBlockEntity be) {
                DarkWorldManagerSavedData data = DarkWorldManagerSavedData.get(serverPlayer.serverLevel().getServer());
                DarkWorldInstance instance = data.getById(be.getInstanceId());
                if (instance != null) {
                    DarkWorldTeleporter.enterDarkWorld(serverPlayer, instance);
                } else {
                    serverPlayer.displayClientMessage(Component.translatable("message.darkworld.fountain_unlinked"), true);
                }
                return InteractionResult.CONSUME;
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
