package com.darkworld.block;

import com.darkworld.world.DarkWorldInstance;
import com.darkworld.world.DarkWorldManagerSavedData;
import com.darkworld.world.DarkWorldTeleporter;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class DarkPortalBeamBlock extends Block {
    private static final VoxelShape SHAPE = Block.box(4.0D, 0.0D, 4.0D, 12.0D, 16.0D, 12.0D);

    public DarkPortalBeamBlock(Properties properties) {
        super(properties);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    protected void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer player && level.getGameTime() % 15 == 0) {
            BlockPos scan = pos;
            for (int i = 0; i < 12; i++) {
                scan = scan.below();
                BlockState belowState = level.getBlockState(scan);
                if (belowState.getBlock() instanceof DarkFountainBlock) {
                    if (belowState.getValue(DarkFountainBlock.RETURN_ANCHOR)) {
                        DarkWorldTeleporter.returnToOrigin(player);
                        return;
                    }
                    if (level.getBlockEntity(scan) instanceof DarkFountainBlockEntity be) {
                        DarkWorldInstance inst = DarkWorldManagerSavedData.get(player.serverLevel().getServer())
                                .getById(be.getInstanceId());
                        if (inst != null) {
                            DarkWorldTeleporter.enterDarkWorld(player, inst);
                        }
                    }
                    return;
                }
            }
        }
    }
}
