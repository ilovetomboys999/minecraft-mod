import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const MOD_ROOT = path.resolve(__dirname, 'forge-mod');

function collectFiles(dir: string, baseDir: string): string[] {
  const results: string[] = [];
  if (!fs.existsSync(dir)) return results;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...collectFiles(full, baseDir));
    } else {
      results.push(path.relative(baseDir, full).replace(/\\/g, '/'));
    }
  }
  return results.sort();
}

function classifyFile(relPath: string): string {
  if (
    relPath === 'gradlew' ||
    relPath === 'gradlew.bat' ||
    relPath.startsWith('gradle/') ||
    relPath.endsWith('.gradle') ||
    relPath.endsWith('.properties') ||
    relPath.endsWith('mods.toml') ||
    relPath.endsWith('pack.mcmeta') ||
    relPath.endsWith('.md')
  ) {
    return 'Build & Config';
  }
  if (relPath.includes('/analysis/')) return 'Enclosed Space & Materials';
  if (relPath.includes('/world/')) return 'WorldGen & Finite Instances';
  if (relPath.includes('/darkner/')) return 'Darkner Population';
  if (relPath.includes('/network/') || relPath.includes('/block/') || relPath.includes('/item/')) return 'Fountain & Networking';
  if (relPath.includes('/client/')) return 'Client Rendering & UI';
  if (relPath.includes('/registry/') || relPath.endsWith('DarkWorldMod.java') || relPath.includes('/config/')) return 'Core & Registries';
  if (relPath.includes('/data/')) return 'Datapack JSONs';
  if (relPath.includes('/assets/')) return 'Resourcepack Assets';
  return 'Other';
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.get('/api/mod-files', (_req, res) => {
    try {
      const files = collectFiles(MOD_ROOT, MOD_ROOT).map((relPath) => {
        const fullPath = path.join(MOD_ROOT, relPath);
        const stat = fs.statSync(fullPath);
        const isBinary = relPath.endsWith('.png') || relPath.endsWith('.ogg') || relPath.endsWith('.jar');
        return {
          path: relPath,
          category: classifyFile(relPath),
          size: stat.size,
          isBinary,
        };
      });
      res.json({ files });
    } catch (err) {
      res.status(500).json({ error: 'Failed to enumerate mod files' });
    }
  });

  app.get('/api/mod-file', (req, res) => {
    const relPath = String(req.query.path || '');
    if (!relPath || relPath.includes('..')) {
      res.status(400).json({ error: 'Invalid path' });
      return;
    }
    const resolved = path.resolve(MOD_ROOT, relPath);
    if (!resolved.startsWith(MOD_ROOT + path.sep) || !fs.existsSync(resolved)) {
      res.status(404).json({ error: 'File not found' });
      return;
    }
    if (relPath.endsWith('.png')) {
      const dataUrl = `data:image/png;base64,${fs.readFileSync(resolved).toString('base64')}`;
      res.json({ path: relPath, isBinary: true, binaryKind: 'image', dataUrl });
      return;
    }
    if (relPath.endsWith('.jar')) {
      res.json({ path: relPath, isBinary: true, binaryKind: 'archive', size: fs.statSync(resolved).size });
      return;
    }
    res.json({
      path: relPath,
      isBinary: false,
      content: fs.readFileSync(resolved, 'utf-8'),
    });
  });

  app.get('/api/download-mod', async (_req, res) => {
    try {
      const zip = new JSZip();
      const files = collectFiles(MOD_ROOT, MOD_ROOT);
      for (const relPath of files) {
        const full = path.join(MOD_ROOT, relPath);
        zip.file(`procedural-dark-worlds-1.21.1/${relPath}`, fs.readFileSync(full), {
          unixPermissions: relPath === 'gradlew' ? '755' : undefined,
        });
      }
      const buffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        platform: 'UNIX',
      });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="procedural-dark-worlds-forge-1.21.1.zip"');
      res.send(buffer);
    } catch (err) {
      res.status(500).json({ error: 'Failed to package mod archive' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
